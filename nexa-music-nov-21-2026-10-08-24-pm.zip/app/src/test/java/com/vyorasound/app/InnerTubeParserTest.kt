package com.vyorasound.app

import com.vyorasound.app.data.parser.InnerTubeJsonParser
import com.vyorasound.app.domain.model.MediaShelfItem
import com.vyorasound.app.utils.ImageUrlUtils
import com.vyorasound.app.utils.TimeUtils
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class InnerTubeParserTest {

    @Test
    fun `parsePlaybackStream selects audio mp4 stream and ignores thumbnail`() {
        val json = """
            {
              "playabilityStatus": { "status": "OK" },
              "streamingData": {
                "expiresInSeconds": "21540",
                "adaptiveFormats": [
                  {
                    "itag": 137,
                    "mimeType": "video/mp4; codecs=\"avc1.640028\"",
                    "bitrate": 2400000,
                    "url": "https://rr1---sn.googlevideo.com/videoplayback?itag=137"
                  },
                  {
                    "itag": 251,
                    "mimeType": "audio/webm; codecs=\"opus\"",
                    "bitrate": 132000,
                    "url": "https://rr1---sn.googlevideo.com/videoplayback?itag=251"
                  },
                  {
                    "itag": 140,
                    "mimeType": "audio/mp4; codecs=\"mp4a.40.2\"",
                    "bitrate": 129000,
                    "url": "https://rr1---sn.googlevideo.com/videoplayback?itag=140"
                  }
                ]
              }
            }
        """.trimIndent()

        val stream = InnerTubeJsonParser.parsePlaybackStream("vid123", "TestAgent", json)
        assertNotNull(stream)
        assertEquals("https://rr1---sn.googlevideo.com/videoplayback?itag=140", stream?.streamUrl)
        assertEquals("audio/mp4", stream?.mimeType)
        assertFalse(stream?.isHls ?: true)
    }

    @Test
    fun `parseHomeFeed extracts carousel shelf items and continuation`() {
        val json = """
            {
              "contents": {
                "singleColumnBrowseResultsRenderer": {
                  "tabs": [{
                    "tabRenderer": {
                      "content": {
                        "sectionListRenderer": {
                          "contents": [{
                            "musicCarouselShelfRenderer": {
                              "header": {
                                "musicCarouselShelfBasicHeaderRenderer": {
                                  "title": { "runs": [{ "text": "Quick picks" }] }
                                }
                              },
                              "contents": [{
                                "musicTwoRowItemRenderer": {
                                  "title": {
                                    "runs": [{
                                      "text": "Midnight City",
                                      "navigationEndpoint": {
                                        "watchEndpoint": { "videoId": "dX3k_QDnzHE" }
                                      }
                                    }]
                                  },
                                  "subtitle": {
                                    "runs": [{
                                      "text": "M83",
                                      "navigationEndpoint": {
                                        "browseEndpoint": {
                                          "browseId": "UC12345",
                                          "browseEndpointContextSupportedConfigs": {
                                            "browseEndpointContextMusicConfig": {
                                              "pageType": "MUSIC_PAGE_TYPE_ARTIST"
                                            }
                                          }
                                        }
                                      }
                                    }]
                                  },
                                  "thumbnailRenderer": {
                                    "musicThumbnailRenderer": {
                                      "thumbnail": {
                                        "thumbnails": [{ "url": "https://lh3.googleusercontent.com/abc=w120-h120", "width": 120 }]
                                      }
                                    }
                                  },
                                  "navigationEndpoint": {
                                    "watchEndpoint": { "videoId": "dX3k_QDnzHE" }
                                  }
                                }
                              }]
                            }
                          }],
                          "continuations": [{
                            "nextContinuationData": { "continuation": "CONT_TOKEN_1" }
                          }]
                        }
                      }
                    }
                  }]
                }
              }
            }
        """.trimIndent()

        val feed = InnerTubeJsonParser.parseHomeFeed(json)
        assertEquals(1, feed.sections.size)
        assertEquals("Quick picks", feed.sections[0].title)
        assertEquals("CONT_TOKEN_1", feed.continuation)
        val songItem = feed.sections[0].items.first() as MediaShelfItem.SongItem
        assertEquals("dX3k_QDnzHE", songItem.song.id)
        assertEquals("Midnight City", songItem.song.title)
        assertEquals("M83", songItem.song.artist)
        assertTrue(songItem.song.thumbnailUrl.contains("w544-h544"))
    }

    @Test
    fun `parseSearchSuggestions extracts query and media suggestions`() {
        val json = """
            {
              "contents": [{
                "searchSuggestionsSectionRenderer": {
                  "contents": [
                    {
                      "searchSuggestionRenderer": {
                        "suggestion": { "runs": [{ "text": "daft punk" }] }
                      }
                    }
                  ]
                }
              }]
            }
        """.trimIndent()

        val suggestions = InnerTubeJsonParser.parseSearchSuggestions(json)
        assertEquals(1, suggestions.size)
    }

    @Test
    fun `time and image helpers format accurately`() {
        assertEquals("3:45", TimeUtils.formatDuration(225_000L))
        assertEquals(225_000L, TimeUtils.parseDurationTextToMs("3:45"))
        assertEquals(
            "https://lh3.googleusercontent.com/art=w544-h544-l90-rj",
            ImageUrlUtils.enhanceThumbnailUrl("//lh3.googleusercontent.com/art=w120-h120-l90-rj")
        )
    }

    @Test
    fun `indonesian discovery contains all 12 categories and extracts query`() {
        val titles = com.vyorasound.app.domain.model.IndonesianDiscovery.categories.map { it.title }
        assertEquals(12, titles.size)
        assertTrue(titles.contains("Pop Indonesia"))
        assertTrue(titles.contains("Indie Indonesia"))
        assertTrue(titles.contains("Dangdut"))
        assertTrue(titles.contains("Pop Jawa"))
        assertTrue(titles.contains("Lagu Galau"))
        assertTrue(titles.contains("Soundtrack Indonesia"))

        val firstBrowseId = com.vyorasound.app.domain.model.IndonesianDiscovery.categories.first().browseId
        val extracted = com.vyorasound.app.domain.model.IndonesianDiscovery.extractCategoryQuery(firstBrowseId)
        assertNotNull(extracted)
    }
}
