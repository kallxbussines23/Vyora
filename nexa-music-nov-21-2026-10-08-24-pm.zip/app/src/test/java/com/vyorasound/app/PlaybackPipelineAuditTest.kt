package com.vyorasound.app

import androidx.media3.common.MimeTypes
import com.vyorasound.app.data.dto.BrowseRequestDto
import com.vyorasound.app.data.dto.NextRequestDto
import com.vyorasound.app.data.dto.PlayerRequestDto
import com.vyorasound.app.data.dto.SearchRequestDto
import com.vyorasound.app.data.dto.SearchSuggestionsRequestDto
import com.vyorasound.app.data.dto.VisitorIdRequestDto
import com.vyorasound.app.data.parser.InnerTubeJsonParser
import com.vyorasound.app.domain.model.Song
import com.vyorasound.app.domain.model.UrlAvailability
import com.vyorasound.app.network.InnerTubeApiService
import com.vyorasound.app.player.PlaybackDiagnostics
import com.vyorasound.app.repository.InnerTubeMusicRepository
import com.vyorasound.app.repository.NoLoginFallbackResolver
import com.vyorasound.app.repository.NoOpNoLoginFallbackResolver
import com.vyorasound.app.repository.PublicApiNoLoginFallbackResolver
import com.vyorasound.app.repository.StreamProbeResult
import com.vyorasound.app.repository.StreamProber
import com.vyorasound.app.service.PlaybackService
import kotlinx.coroutines.test.runTest
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.ResponseBody
import okhttp3.ResponseBody.Companion.toResponseBody
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.Robolectric
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import retrofit2.Response

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class PlaybackPipelineAuditTest {

    @After
    fun tearDown() {
        PlaybackDiagnostics.logSink = null
    }

    @Test
    fun `audit ranks default non-DRC audio mp4 and webm formats and excludes DRM or thumbnail URLs`() {
        val json = """
            {
              "responseContext": { "visitorData": "CgtWaXNpdG9yMTIz" },
              "playabilityStatus": { "status": "OK" },
              "streamingData": {
                "expiresInSeconds": "21540",
                "adaptiveFormats": [
                  {
                    "itag": 140,
                    "mimeType": "audio/mp4; codecs=\"mp4a.40.2\"",
                    "bitrate": 129000,
                    "audioQuality": "AUDIO_QUALITY_MEDIUM",
                    "contentLength": "3450000",
                    "drmFamilies": ["WIDEVINE"],
                    "url": "https://rr1---sn.googlevideo.com/videoplayback?itag=140&sig=SECRET_DRM"
                  },
                  {
                    "itag": 251,
                    "mimeType": "audio/webm; codecs=\"opus\"",
                    "bitrate": 140000,
                    "audioQuality": "AUDIO_QUALITY_MEDIUM",
                    "contentLength": "3650000",
                    "audioTrack": { "audioIsDefault": true },
                    "url": "https://rr1---sn.googlevideo.com/videoplayback?itag=251&sig=SECRET_OPUS"
                  },
                  {
                    "itag": 141,
                    "mimeType": "audio/mp4; codecs=\"mp4a.40.2\"",
                    "bitrate": 256000,
                    "audioQuality": "AUDIO_QUALITY_HIGH",
                    "url": "https://i.ytimg.com/vi/abc/hqdefault.jpg"
                  },
                  {
                    "itag": 139,
                    "mimeType": "audio/mp4; codecs=\"mp4a.40.5\"",
                    "bitrate": 48000,
                    "audioQuality": "AUDIO_QUALITY_LOW",
                    "audioTrack": { "audioIsDefault": true },
                    "url": "https://rr1---sn.googlevideo.com/videoplayback?itag=139&sig=SECRET_LOW"
                  }
                ]
              }
            }
        """.trimIndent()

        assertEquals("CgtWaXNpdG9yMTIz", InnerTubeJsonParser.extractVisitorData(json))

        val audit = InnerTubeJsonParser.auditAndSelectPlaybackStreams(
            videoId = "indonesian_vid_1",
            userAgent = "TestAgent",
            jsonString = json,
            clientName = "ANDROID_VR"
        )

        assertEquals("OK", audit.playabilityStatus)
        assertTrue(audit.hasStreamingData)
        assertEquals(2, audit.rankedPlayableStreams.size)
        // itag 140 had DRM, itag 141 had thumbnail host -> excluded!
        // itag 139 is audio/mp4 (ranked first over audio/webm), itag 251 is second
        assertEquals(139, audit.rankedPlayableStreams[0].itag)
        assertEquals(251, audit.rankedPlayableStreams[1].itag)
    }

    @Test
    fun `audit identifies root causes for LOGIN_REQUIRED, signatureCipher-only, and SABR-only responses`() {
        val loginRequiredJson = """
            {
              "playabilityStatus": {
                "status": "LOGIN_REQUIRED",
                "reason": "Sign in to confirm you're not a bot"
              }
            }
        """.trimIndent()
        val loginAudit = InnerTubeJsonParser.auditAndSelectPlaybackStreams("v1", "UA", loginRequiredJson, "IOS")
        assertTrue(loginAudit.rankedPlayableStreams.isEmpty())
        assertTrue(loginAudit.rootCauseHint!!.contains("LOGIN_REQUIRED"))

        val cipherOnlyJson = """
            {
              "playabilityStatus": { "status": "OK" },
              "streamingData": {
                "adaptiveFormats": [
                  {
                    "itag": 251,
                    "mimeType": "audio/webm; codecs=\"opus\"",
                    "bitrate": 128000,
                    "signatureCipher": "s=abc&url=https%3A%2F%2Fexample.com"
                  }
                ]
              }
            }
        """.trimIndent()
        val cipherAudit = InnerTubeJsonParser.auditAndSelectPlaybackStreams("v2", "UA", cipherOnlyJson, "WEB_REMIX")
        assertTrue(cipherAudit.rankedPlayableStreams.isEmpty())
        assertEquals(UrlAvailability.SIGNATURE_CIPHER, cipherAudit.audioCandidates.single().urlAvailability)
        assertTrue(cipherAudit.rootCauseHint!!.contains("signatureCipher"))

        val sabrOnlyJson = """
            {
              "playabilityStatus": { "status": "OK" },
              "streamingData": {
                "serverAbrStreamingUrl": "https://rr1.googlevideo.com/videoplayback?sabr=1"
              }
            }
        """.trimIndent()
        val sabrAudit = InnerTubeJsonParser.auditAndSelectPlaybackStreams("v3", "UA", sabrOnlyJson, "WEB_REMIX")
        assertTrue(sabrAudit.rankedPlayableStreams.isEmpty())
        assertTrue(sabrAudit.hasServerAbrStreamingUrl)
        assertTrue(sabrAudit.rootCauseHint!!.contains("SABR"))
    }

    @Test
    fun `repository rejects HTTP 403 stream, falls back across clients, propagates visitorData, and redacts tokens in logs`() = runTest {
        val capturedLogs = mutableListOf<String>()
        PlaybackDiagnostics.logSink = { _, msg, _ -> capturedLogs.add(msg) }

        val recordedRequests = mutableListOf<Pair<String, String?>>()

        val fakeApi = object : InnerTubeApiService {
            override suspend fun browse(
                headers: Map<String, String>,
                body: BrowseRequestDto,
                continuation: String?
            ): Response<ResponseBody> {
                val browseJson = """{ "responseContext": { "visitorData": "VISITOR_ABC_123" } }"""
                return Response.success(browseJson.toResponseBody("application/json".toMediaType()))
            }

            override suspend fun search(
                headers: Map<String, String>,
                body: SearchRequestDto,
                continuation: String?
            ): Response<ResponseBody> = error("unused")

            override suspend fun getSearchSuggestions(
                headers: Map<String, String>,
                body: SearchSuggestionsRequestDto
            ): Response<ResponseBody> = error("unused")

            override suspend fun next(
                headers: Map<String, String>,
                body: NextRequestDto
            ): Response<ResponseBody> = error("unused")

            override suspend fun player(
                headers: Map<String, String>,
                body: PlayerRequestDto
            ): Response<ResponseBody> = error("unused")

            override suspend fun visitorIdAtUrl(
                url: String,
                headers: Map<String, String>,
                body: VisitorIdRequestDto
            ): Response<ResponseBody> {
                val json = """{ "responseContext": { "visitorData": "NATIVE_VISITOR_123" } }"""
                return Response.success(json.toResponseBody("application/json".toMediaType()))
            }

            override suspend fun playerAtUrl(
                url: String,
                headers: Map<String, String>,
                body: PlayerRequestDto
            ): Response<ResponseBody> {
                val client = body.context.client.clientName
                recordedRequests.add(client to headers["X-Goog-Visitor-Id"])
                val json = when (client) {
                    "ANDROID_VR" -> """
                        {
                          "playabilityStatus": { "status": "OK" },
                          "streamingData": {
                            "expiresInSeconds": "21540",
                            "adaptiveFormats": [
                              {
                                "itag": 140,
                                "mimeType": "audio/mp4; codecs=\"mp4a.40.2\"",
                                "bitrate": 129000,
                                "url": "https://rr1---sn.googlevideo.com/videoplayback?itag=140&sig=TOP_SECRET_TOKEN_1"
                              }
                            ]
                          }
                        }
                    """.trimIndent()
                    "ANDROID" -> """
                        {
                          "playabilityStatus": { "status": "OK" },
                          "streamingData": {
                            "expiresInSeconds": "21540",
                            "adaptiveFormats": [
                              {
                                "itag": 251,
                                "mimeType": "audio/webm; codecs=\"opus\"",
                                "bitrate": 136000,
                                "url": "https://rr2---sn.googlevideo.com/videoplayback?itag=251&sig=TOP_SECRET_TOKEN_2"
                              }
                            ]
                          }
                        }
                    """.trimIndent()
                    else -> """{ "playabilityStatus": { "status": "LOGIN_REQUIRED" } }"""
                }
                return Response.success(json.toResponseBody("application/json".toMediaType()))
            }
        }

        // First URL (ANDROID_VR) fails HTTP probe with 403; second working client (ANDROID) succeeds with 206 Partial Content
        val fakeProber = StreamProber { stream ->
            if (stream.clientName == "ANDROID_VR") {
                StreamProbeResult(isPlayable = false, httpStatus = 403, errorDetail = "HTTP 403 Forbidden")
            } else {
                StreamProbeResult(isPlayable = true, httpStatus = 206)
            }
        }

        val repo = InnerTubeMusicRepository(fakeApi, fakeProber, NoOpNoLoginFallbackResolver)
        repo.registerSongTitle("ind_song_01", "Evaluasi - Hindia")

        val result = repo.getPlaybackStream("ind_song_01")
        assertTrue(result.isSuccess)
        val stream = result.getOrThrow()
        assertEquals("ANDROID", stream.clientName)
        assertEquals(251, stream.itag)
        assertEquals("audio/webm", stream.mimeType)

        // Verify native vs web visitorData isolation across clients
        val byClient = recordedRequests.toMap()
        assertEquals("NATIVE_VISITOR_123", byClient["ANDROID_VR"])
        assertEquals("VISITOR_ABC_123", byClient["TVHTML5"])
        assertEquals("NATIVE_VISITOR_123", byClient["ANDROID"])

        // Verify diagnostic logging contains title, videoId, and NEVER leaks secret token
        assertTrue(capturedLogs.any { it.contains("Evaluasi - Hindia") && it.contains("ind_song_01") })
        assertTrue(capturedLogs.any { it.contains("httpStatus=403") })
        assertTrue(capturedLogs.any { it.contains("httpStatus=206") })
        assertFalse(capturedLogs.any { it.contains("TOP_SECRET_TOKEN") })

        // Verify cache invalidation removes entry cleanly
        assertNotNull(repo.getCachedStream("ind_song_01"))
        repo.invalidateStreamCache("ind_song_01")
        assertNull(repo.getCachedStream("ind_song_01"))
    }

    @Test
    fun `PlaybackService initializes MediaSession and builds valid MediaItems for progressive and HLS streams`() {
        val song = Song(
            id = "intl_song_01",
            title = "Midnight City",
            artist = "M83",
            durationMs = 243_000L
        )
        val progressiveItem = PlaybackService.buildMediaItem(song, null)
        assertEquals("vyora://stream/intl_song_01", progressiveItem.localConfiguration?.uri.toString())
        assertNull(progressiveItem.localConfiguration?.mimeType)

        val hlsStream = com.vyorasound.app.domain.model.PlaybackStream(
            videoId = "intl_song_01",
            streamUrl = "https://manifest.googlevideo.com/api/manifest/hls_playlist/index.m3u8",
            mimeType = MimeTypes.APPLICATION_M3U8,
            userAgent = "TestUA",
            expiresAtMs = System.currentTimeMillis() + 60_000L,
            isHls = true
        )
        val hlsItem = PlaybackService.buildMediaItem(song, hlsStream)
        assertEquals(MimeTypes.APPLICATION_M3U8, hlsItem.localConfiguration?.mimeType)

        val controller = Robolectric.buildService(PlaybackService::class.java).create()
        val service = controller.get()
        assertNotNull(service)
        controller.destroy()
    }

    @Test
    fun `ExoPlayer resolves vyora stream via ResolvingDataSource and reaches STATE_READY then pauses and resumes`() {
        val wavBytes = buildSilentWavBytes(durationMs = 10_000)
        val mockStreamClient = okhttp3.OkHttpClient.Builder()
            .addInterceptor { chain ->
                val req = chain.request()
                val rangeHeader = req.header("Range")
                if (req.url.host == "rr-dead.googlevideo.com") {
                    okhttp3.Response.Builder()
                        .request(req)
                        .protocol(okhttp3.Protocol.HTTP_1_1)
                        .code(403)
                        .message("Forbidden")
                        .body("".toResponseBody("text/plain".toMediaType()))
                        .build()
                } else {
                    val isPartial = rangeHeader != null
                    val bodyBytes = if (rangeHeader == "bytes=0-1") wavBytes.copyOfRange(0, 2) else wavBytes
                    okhttp3.Response.Builder()
                        .request(req)
                        .protocol(okhttp3.Protocol.HTTP_1_1)
                        .code(if (isPartial) 206 else 200)
                        .message(if (isPartial) "Partial Content" else "OK")
                        .header("Content-Type", "audio/wav")
                        .header("Accept-Ranges", "bytes")
                        .apply {
                            if (isPartial) {
                                header("Content-Range", "bytes 0-${bodyBytes.lastIndex}/${wavBytes.size}")
                            }
                        }
                        .body(bodyBytes.toResponseBody("audio/wav".toMediaType()))
                        .build()
                }
            }
            .build()

        val fakeApi = object : InnerTubeApiService {
            override suspend fun browse(
                headers: Map<String, String>,
                body: BrowseRequestDto,
                continuation: String?
            ): Response<ResponseBody> =
                Response.success("""{"responseContext":{"visitorData":"VISITOR_EXO_1"}}""".toResponseBody("application/json".toMediaType()))

            override suspend fun search(
                headers: Map<String, String>,
                body: SearchRequestDto,
                continuation: String?
            ): Response<ResponseBody> = error("unused")

            override suspend fun getSearchSuggestions(
                headers: Map<String, String>,
                body: SearchSuggestionsRequestDto
            ): Response<ResponseBody> = error("unused")

            override suspend fun next(
                headers: Map<String, String>,
                body: NextRequestDto
            ): Response<ResponseBody> = error("unused")

            override suspend fun player(
                headers: Map<String, String>,
                body: PlayerRequestDto
            ): Response<ResponseBody> = error("unused")

            override suspend fun visitorIdAtUrl(
                url: String,
                headers: Map<String, String>,
                body: VisitorIdRequestDto
            ): Response<ResponseBody> =
                Response.success("""{"responseContext":{"visitorData":"NATIVE_VISITOR_EXO"}}""".toResponseBody("application/json".toMediaType()))

            override suspend fun playerAtUrl(
                url: String,
                headers: Map<String, String>,
                body: PlayerRequestDto
            ): Response<ResponseBody> {
                val json = if (body.context.client.clientName == "ANDROID_VR") {
                    """
                    {
                      "playabilityStatus": { "status": "OK" },
                      "streamingData": {
                        "expiresInSeconds": "21540",
                        "adaptiveFormats": [
                          {
                            "itag": 140,
                            "mimeType": "audio/mp4; codecs=\"mp4a.40.2\"",
                            "bitrate": 129000,
                            "url": "https://rr-dead.googlevideo.com/videoplayback?itag=140"
                          }
                        ]
                      }
                    }
                    """.trimIndent()
                } else {
                    """
                    {
                      "playabilityStatus": { "status": "OK" },
                      "streamingData": {
                        "expiresInSeconds": "21540",
                        "adaptiveFormats": [
                          {
                            "itag": 251,
                            "mimeType": "audio/webm; codecs=\"opus\"",
                            "bitrate": 132000,
                            "url": "https://rr-live.googlevideo.com/videoplayback?itag=251"
                          }
                        ]
                      }
                    }
                    """.trimIndent()
                }
                return Response.success(json.toResponseBody("application/json".toMediaType()))
            }
        }

        val repo = InnerTubeMusicRepository(
            apiService = fakeApi,
            streamProber = com.vyorasound.app.repository.OkHttpStreamProber(mockStreamClient),
            noLoginFallbackResolver = NoOpNoLoginFallbackResolver
        )
        repo.registerSongTitle("exo_vid_1", "Sial - Mahalini")

        val context = androidx.test.core.app.ApplicationProvider.getApplicationContext<android.content.Context>()
        val upstream = androidx.media3.datasource.okhttp.OkHttpDataSource.Factory(mockStreamClient)
        val resolvingFactory = androidx.media3.datasource.ResolvingDataSource.Factory(
            upstream,
            object : androidx.media3.datasource.ResolvingDataSource.Resolver {
                override fun resolveDataSpec(dataSpec: androidx.media3.datasource.DataSpec): androidx.media3.datasource.DataSpec {
                    val videoId = dataSpec.uri.lastPathSegment!!
                    val stream = repo.getPlaybackStreamDetailedBlocking(videoId).getOrThrow()
                    val headers = HashMap(dataSpec.httpRequestHeaders).apply {
                        put("User-Agent", stream.userAgent)
                    }
                    return dataSpec.buildUpon()
                        .setUri(android.net.Uri.parse(stream.streamUrl))
                        .setHttpRequestHeaders(headers)
                        .build()
                }
            }
        )

        val testLogs = mutableListOf<String>()
        PlaybackDiagnostics.logSink = { level, msg, _ ->
            testLogs.add("[$level] $msg")
        }

        val player = androidx.media3.exoplayer.ExoPlayer.Builder(context)
            .setMediaSourceFactory(androidx.media3.exoplayer.source.DefaultMediaSourceFactory(resolvingFactory))
            .build()

        var reachedReady = false
        var playbackError: Throwable? = null
        player.addListener(object : androidx.media3.common.Player.Listener {
            override fun onPlaybackStateChanged(playbackState: Int) {
                if (playbackState == androidx.media3.common.Player.STATE_READY) {
                    reachedReady = true
                }
            }

            override fun onPlayerError(error: androidx.media3.common.PlaybackException) {
                playbackError = error
            }
        })

        val song = Song(id = "exo_vid_1", title = "Sial", artist = "Mahalini")
        player.setMediaItem(PlaybackService.buildMediaItem(song))
        player.prepare()
        player.play()

        val mainLooper = org.robolectric.Shadows.shadowOf(android.os.Looper.getMainLooper())
        val playbackLooper = org.robolectric.Shadows.shadowOf(player.playbackLooper)
        val startWallMs = System.currentTimeMillis()
        while (!reachedReady && playbackError == null && System.currentTimeMillis() - startWallMs < 5_000L) {
            playbackLooper.idleFor(10L, java.util.concurrent.TimeUnit.MILLISECONDS)
            mainLooper.idleFor(10L, java.util.concurrent.TimeUnit.MILLISECONDS)
            if (!reachedReady) Thread.sleep(10L)
        }

        assertNull("Unexpected ExoPlayer error: ${playbackError?.message} | logs=$testLogs", playbackError)
        assertTrue(
            "ExoPlayer should reach STATE_READY (current=${player.playbackState}) | logs=$testLogs",
            reachedReady
        )
        assertEquals(androidx.media3.common.Player.STATE_READY, player.playbackState)
        assertTrue(player.playWhenReady)

        // Verify pause and resume state transitions
        player.pause()
        mainLooper.idle()
        assertFalse(player.playWhenReady)

        player.play()
        mainLooper.idle()
        assertTrue(player.playWhenReady)

        player.release()
    }

    private fun buildSilentWavBytes(durationMs: Int, sampleRate: Int = 8000): ByteArray {
        val numSamples = (sampleRate * durationMs) / 1000
        val dataSize = numSamples * 2 // 16-bit mono PCM
        val totalSize = 44 + dataSize
        val out = java.io.ByteArrayOutputStream(totalSize)
        fun writeAscii(s: String) = out.write(s.toByteArray(Charsets.US_ASCII))
        fun writeIntLE(v: Int) {
            out.write(v and 0xFF)
            out.write((v shr 8) and 0xFF)
            out.write((v shr 16) and 0xFF)
            out.write((v shr 24) and 0xFF)
        }
        fun writeShortLE(v: Int) {
            out.write(v and 0xFF)
            out.write((v shr 8) and 0xFF)
        }
        writeAscii("RIFF")
        writeIntLE(36 + dataSize)
        writeAscii("WAVE")
        writeAscii("fmt ")
        writeIntLE(16) // PCM chunk size
        writeShortLE(1) // PCM format
        writeShortLE(1) // mono
        writeIntLE(sampleRate)
        writeIntLE(sampleRate * 2)
        writeShortLE(2) // block align
        writeShortLE(16) // bits per sample
        writeAscii("data")
        writeIntLE(dataSize)
        out.write(ByteArray(dataSize))
        return out.toByteArray()
    }

    @Test
    fun `repository falls back to no-login public stream resolver when all InnerTube clients return LOGIN_REQUIRED`() = runTest {
        val loginOnlyApi = object : InnerTubeApiService {
            override suspend fun browse(
                headers: Map<String, String>,
                body: BrowseRequestDto,
                continuation: String?
            ): Response<ResponseBody> =
                Response.success("""{"responseContext":{"visitorData":"WEB_V"}}""".toResponseBody("application/json".toMediaType()))

            override suspend fun search(
                headers: Map<String, String>,
                body: SearchRequestDto,
                continuation: String?
            ): Response<ResponseBody> = error("unused")

            override suspend fun getSearchSuggestions(
                headers: Map<String, String>,
                body: SearchSuggestionsRequestDto
            ): Response<ResponseBody> = error("unused")

            override suspend fun next(
                headers: Map<String, String>,
                body: NextRequestDto
            ): Response<ResponseBody> = error("unused")

            override suspend fun player(
                headers: Map<String, String>,
                body: PlayerRequestDto
            ): Response<ResponseBody> = error("unused")

            override suspend fun visitorIdAtUrl(
                url: String,
                headers: Map<String, String>,
                body: VisitorIdRequestDto
            ): Response<ResponseBody> =
                Response.success("""{"responseContext":{"visitorData":"NAT_V"}}""".toResponseBody("application/json".toMediaType()))

            override suspend fun playerAtUrl(
                url: String,
                headers: Map<String, String>,
                body: PlayerRequestDto
            ): Response<ResponseBody> =
                Response.success(
                    """{"playabilityStatus":{"status":"LOGIN_REQUIRED","reason":"Sign in to confirm you're not a bot"}}"""
                        .toResponseBody("application/json".toMediaType())
                )
        }

        val fallbackParser = PublicApiNoLoginFallbackResolver()
        val pipedJson = """
            {
              "audioStreams": [
                {
                  "url": "https://pipedproxy.example.org/videoplayback?itag=140",
                  "mimeType": "audio/mp4",
                  "codec": "mp4a.40.2",
                  "bitrate": 129000,
                  "quality": "129 kbps",
                  "videoOnly": false
                }
              ]
            }
        """.trimIndent()
        val parsedPiped = fallbackParser.parsePipedStreamsJson("https://pipedapi.example.org", "v_no_login", pipedJson)
        assertEquals(1, parsedPiped.size)
        assertEquals("audio/mp4", parsedPiped[0].mimeType)

        val invidiousJson = """
            {
              "adaptiveFormats": [
                {
                  "itag": "140",
                  "type": "audio/mp4; codecs=\"mp4a.40.2\"",
                  "bitrate": "129000",
                  "clen": "3200000",
                  "url": "https://rr1.googlevideo.com/videoplayback?itag=140"
                }
              ]
            }
        """.trimIndent()
        val parsedInvidious = fallbackParser.parseInvidiousStreamsJson("https://inv.example.org", "v_no_login", invidiousJson)
        assertEquals(2, parsedInvidious.size)
        assertEquals("https://inv.example.org/latest_version?id=v_no_login&itag=140&local=true", parsedInvidious[0].streamUrl)

        val noLoginResolver = object : NoLoginFallbackResolver {
            override suspend fun resolvePlayableStream(
                videoId: String,
                songTitle: String?,
                streamProber: StreamProber
            ) = parsedPiped.first()
        }

        val repo = InnerTubeMusicRepository(
            apiService = loginOnlyApi,
            streamProber = StreamProber { StreamProbeResult(true, 206) },
            noLoginFallbackResolver = noLoginResolver
        )
        repo.registerSongTitle("v_no_login", "Komang - Raim Laode")

        val streamResult = repo.getPlaybackStream("v_no_login")
        assertTrue(streamResult.isSuccess)
        assertEquals("https://pipedproxy.example.org/videoplayback?itag=140", streamResult.getOrThrow().streamUrl)
    }

    @Test
    fun `unauthenticated exhaustion returns LoginRequiredPlaybackException and authenticated provider prioritizes WEB_REMIX with SAPISIDHASH`() = runTest {
        val capturedHeadersByClient = mutableListOf<Pair<String, Map<String, String>>>()

        val apiWithAuthCheck = object : InnerTubeApiService {
            override suspend fun browse(
                headers: Map<String, String>,
                body: BrowseRequestDto,
                continuation: String?
            ): Response<ResponseBody> =
                Response.success("""{"responseContext":{"visitorData":"WEB_V"}}""".toResponseBody("application/json".toMediaType()))

            override suspend fun search(
                headers: Map<String, String>,
                body: SearchRequestDto,
                continuation: String?
            ): Response<ResponseBody> = error("unused")

            override suspend fun getSearchSuggestions(
                headers: Map<String, String>,
                body: SearchSuggestionsRequestDto
            ): Response<ResponseBody> = error("unused")

            override suspend fun next(
                headers: Map<String, String>,
                body: NextRequestDto
            ): Response<ResponseBody> = error("unused")

            override suspend fun player(
                headers: Map<String, String>,
                body: PlayerRequestDto
            ): Response<ResponseBody> = error("unused")

            override suspend fun visitorIdAtUrl(
                url: String,
                headers: Map<String, String>,
                body: VisitorIdRequestDto
            ): Response<ResponseBody> =
                Response.success("""{"responseContext":{"visitorData":"NAT_V"}}""".toResponseBody("application/json".toMediaType()))

            override suspend fun playerAtUrl(
                url: String,
                headers: Map<String, String>,
                body: PlayerRequestDto
            ): Response<ResponseBody> {
                val client = body.context.client.clientName
                capturedHeadersByClient.add(client to headers)
                val hasAuth = headers["Authorization"]?.startsWith("SAPISIDHASH ") == true
                val json = if (client == "WEB_REMIX" && hasAuth) {
                    """
                    {
                      "playabilityStatus": { "status": "OK" },
                      "streamingData": {
                        "expiresInSeconds": "21540",
                        "adaptiveFormats": [
                          {
                            "itag": 140,
                            "mimeType": "audio/mp4; codecs=\"mp4a.40.2\"",
                            "bitrate": 129000,
                            "url": "https://rr1---sn.googlevideo.com/videoplayback?itag=140"
                          }
                        ]
                      }
                    }
                    """.trimIndent()
                } else {
                    """{"playabilityStatus":{"status":"LOGIN_REQUIRED","reason":"Login untuk mengonfirmasi bahwa Anda bukan bot"}}"""
                }
                return Response.success(json.toResponseBody("application/json".toMediaType()))
            }
        }

        val unauthRepo = InnerTubeMusicRepository(
            apiService = apiWithAuthCheck,
            streamProber = StreamProber { StreamProbeResult(true, 206) },
            noLoginFallbackResolver = NoOpNoLoginFallbackResolver
        )
        val unauthResult = unauthRepo.getPlaybackStream("cyu1Sg_QDbs")
        assertTrue(unauthResult.isFailure)
        assertTrue(unauthResult.exceptionOrNull() is com.vyorasound.app.repository.LoginRequiredPlaybackException)

        capturedHeadersByClient.clear()
        val fakeSignedInProvider = object : com.vyorasound.app.network.YouTubeAuthProvider {
            override val isSignedIn = kotlinx.coroutines.flow.MutableStateFlow(true)
            override fun refreshSessionState(): Boolean = true
            override fun buildAuthHeaders(origin: String): Map<String, String> = mapOf(
                "Cookie" to "SAPISID=FAKE_SAPISID",
                "Authorization" to "SAPISIDHASH 1700000000_abcdef0123456789",
                "X-Origin" to origin,
                "X-Goog-AuthUser" to "0"
            )
            override fun signOut() = Unit
        }

        val authRepo = InnerTubeMusicRepository(
            apiService = apiWithAuthCheck,
            streamProber = StreamProber { StreamProbeResult(true, 206) },
            noLoginFallbackResolver = NoOpNoLoginFallbackResolver,
            authProvider = fakeSignedInProvider
        )
        val authResult = authRepo.getPlaybackStream("cyu1Sg_QDbs")
        assertTrue(authResult.isSuccess)
        assertEquals("WEB_REMIX", authResult.getOrThrow().clientName)
        assertEquals("WEB_REMIX", capturedHeadersByClient.first().first)
        assertTrue(capturedHeadersByClient.first().second["Authorization"]?.startsWith("SAPISIDHASH ") == true)

        // Verify Invidious formatStreams muxed itag 18 fallback parsing
        val invidiousMuxedOnly = """
            {
              "formatStreams": [
                {
                  "itag": "18",
                  "type": "video/mp4; codecs=\"avc1.42001E, mp4a.40.2\"",
                  "url": "https://inv.example.org/latest_version?id=v_mux&itag=18&local=true"
                }
              ]
            }
        """.trimIndent()
        val parsedMuxed = PublicApiNoLoginFallbackResolver().parseInvidiousStreamsJson(
            "https://inv.example.org",
            "v_mux",
            invidiousMuxedOnly
        )
        assertEquals(1, parsedMuxed.size)
        assertEquals(18, parsedMuxed[0].itag)
        assertEquals("video/mp4", parsedMuxed[0].mimeType)
    }
}
