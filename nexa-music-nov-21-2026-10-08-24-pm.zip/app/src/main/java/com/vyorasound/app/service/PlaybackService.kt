package com.vyorasound.app.service

import android.app.PendingIntent
import android.content.Intent
import android.net.Uri
import androidx.annotation.OptIn
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.MimeTypes
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.Tracks
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.DataSpec
import androidx.media3.datasource.HttpDataSource
import androidx.media3.datasource.ResolvingDataSource
import androidx.media3.datasource.okhttp.OkHttpDataSource
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.session.DefaultMediaNotificationProvider
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService
import com.vyorasound.app.MainActivity
import com.vyorasound.app.R
import com.vyorasound.app.VyoraApplication
import com.vyorasound.app.domain.model.PlaybackStream
import com.vyorasound.app.domain.model.Song
import com.vyorasound.app.network.NetworkModule
import com.vyorasound.app.player.PlaybackDiagnostics
import java.io.IOException
import java.util.concurrent.ConcurrentHashMap

@OptIn(UnstableApi::class)
class PlaybackService : MediaSessionService() {

    private var mediaSession: MediaSession? = null
    private var exoPlayer: ExoPlayer? = null
    private val autoRetriedVideoIds = ConcurrentHashMap.newKeySet<String>()

    override fun onCreate() {
        super.onCreate()
        val app = application as VyoraApplication
        val musicRepository = app.container.musicRepository

        val upstreamFactory = OkHttpDataSource.Factory(NetworkModule.streamOkHttpClient)
        val resolvingFactory = ResolvingDataSource.Factory(
            upstreamFactory,
            object : ResolvingDataSource.Resolver {
                override fun resolveDataSpec(dataSpec: DataSpec): DataSpec {
                    val scheme = dataSpec.uri.scheme
                    if ((scheme == SCHEME_VYORA || scheme == SCHEME_NEXA) && dataSpec.uri.host == HOST_STREAM) {
                        val videoId = dataSpec.uri.lastPathSegment
                            ?: throw IOException("Missing videoId in stream URI")

                        val streamResult = musicRepository.getPlaybackStreamDetailedBlocking(videoId)
                        val stream = streamResult.getOrElse { err ->
                            if (err is com.vyorasound.app.repository.LoginRequiredPlaybackException) {
                                PlaybackDiagnostics.w(
                                    "ResolveDataSpecLoginRequired | videoId=$videoId | rootCause=${err.message}"
                                )
                            } else {
                                PlaybackDiagnostics.e(
                                    "ResolveDataSpecFAILED | videoId=$videoId | rootCause=${err.message}",
                                    err
                                )
                            }
                            throw IOException(err.message ?: "Unable to resolve playable audio source", err)
                        }

                        val resolvedUri = Uri.parse(stream.streamUrl)
                        val uriScheme = resolvedUri.scheme?.lowercase()
                        if ((uriScheme != "https" && uriScheme != "http") || resolvedUri.host.isNullOrBlank()) {
                            PlaybackDiagnostics.e(
                                "InvalidResolvedUri | videoId=$videoId | url=${PlaybackDiagnostics.redactStreamUrl(stream.streamUrl)}"
                            )
                            musicRepository.invalidateStreamCache(videoId)
                            throw IOException("Invalid stream URI resolved for $videoId")
                        }

                        val headers = HashMap(dataSpec.httpRequestHeaders).apply {
                            put("User-Agent", stream.userAgent)
                        }

                        PlaybackDiagnostics.i(
                            "ResolveDataSpecOK | videoId=$videoId | client=${stream.clientName} | " +
                                "itag=${stream.itag} | mime=${stream.mimeType} | bitrate=${stream.bitrate} | " +
                                "isHls=${stream.isHls} | host=${resolvedUri.host}"
                        )

                        return dataSpec.buildUpon()
                            .setUri(resolvedUri)
                            .setHttpRequestHeaders(headers)
                            .build()
                    }
                    return dataSpec
                }
            }
        )

        val audioAttributes = AudioAttributes.Builder()
            .setUsage(C.USAGE_MEDIA)
            .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC)
            .build()

        val player = ExoPlayer.Builder(this)
            .setMediaSourceFactory(DefaultMediaSourceFactory(resolvingFactory))
            .setAudioAttributes(audioAttributes, true)
            .setHandleAudioBecomingNoisy(true)
            .setWakeMode(C.WAKE_MODE_NETWORK)
            .build()

        player.addListener(object : Player.Listener {
            override fun onPlaybackStateChanged(playbackState: Int) {
                val item = player.currentMediaItem
                val title = item?.mediaMetadata?.title?.toString() ?: "-"
                val videoId = item?.mediaId ?: "-"
                val stateLabel = when (playbackState) {
                    Player.STATE_IDLE -> "STATE_IDLE"
                    Player.STATE_BUFFERING -> "STATE_BUFFERING"
                    Player.STATE_READY -> "STATE_READY"
                    Player.STATE_ENDED -> "STATE_ENDED"
                    else -> "STATE_$playbackState"
                }
                PlaybackDiagnostics.i(
                    "ExoState | title=\"$title\" | videoId=$videoId | state=$stateLabel | " +
                        "playWhenReady=${player.playWhenReady} | durationMs=${player.duration}"
                )
                if (playbackState == Player.STATE_READY && videoId != "-") {
                    autoRetriedVideoIds.remove(videoId)
                }
            }

            override fun onIsPlayingChanged(isPlaying: Boolean) {
                val item = player.currentMediaItem
                val title = item?.mediaMetadata?.title?.toString() ?: "-"
                val videoId = item?.mediaId ?: "-"
                PlaybackDiagnostics.i("ExoPlaying | title=\"$title\" | videoId=$videoId | isPlaying=$isPlaying")
            }

            override fun onTracksChanged(tracks: Tracks) {
                val selectedAudio = tracks.groups
                    .filter { it.type == C.TRACK_TYPE_AUDIO && it.isSelected }
                    .flatMap { group ->
                        (0 until group.length).mapNotNull { idx ->
                            if (group.isTrackSelected(idx)) group.getTrackFormat(idx) else null
                        }
                    }
                    .firstOrNull()
                if (selectedAudio != null) {
                    PlaybackDiagnostics.i(
                        "ExoAudioTrack | mime=${selectedAudio.sampleMimeType} | " +
                            "codecs=${selectedAudio.codecs ?: "-"} | bitrate=${selectedAudio.bitrate} | " +
                            "sampleRate=${selectedAudio.sampleRate} | channels=${selectedAudio.channelCount}"
                    )
                }
            }

            override fun onPlayerError(error: PlaybackException) {
                val item = player.currentMediaItem
                val videoId = item?.mediaId
                val title = item?.mediaMetadata?.title?.toString() ?: "-"
                val httpCode = findHttpStatusCode(error)
                val cached = videoId?.let { musicRepository.getCachedStream(it) }

                PlaybackDiagnostics.e(
                    "ExoPlayerError | title=\"$title\" | videoId=${videoId ?: "-"} | " +
                        "errorCode=${error.errorCode} (${error.errorCodeName}) | " +
                        "httpStatus=${httpCode ?: -1} | rootCause=${error.cause?.message ?: error.message}",
                    error
                )

                // If stream resolved to HLS manifest but MediaItem had no HLS mimeType, swap to HLS MediaSource seamlessly
                if (videoId != null && cached?.isHls == true &&
                    item.localConfiguration?.mimeType != MimeTypes.APPLICATION_M3U8 &&
                    (error.errorCode == PlaybackException.ERROR_CODE_PARSING_CONTAINER_UNSUPPORTED ||
                        error.errorCode == PlaybackException.ERROR_CODE_PARSING_CONTAINER_MALFORMED)
                ) {
                    val idx = player.currentMediaItemIndex
                    if (idx in 0 until player.mediaItemCount) {
                        PlaybackDiagnostics.i("ExoHlsRecovery | videoId=$videoId | switching MediaItem to HLS MIME")
                        val hlsItem = item.buildUpon()
                            .setMimeType(MimeTypes.APPLICATION_M3U8)
                            .build()
                        player.replaceMediaItem(idx, hlsItem)
                        player.prepare()
                        player.play()
                        return
                    }
                }

                // On HTTP 403/404/410 or expired stream, invalidate cache and retry once with next InnerTube client
                if (videoId != null && (httpCode == 403 || httpCode == 404 || httpCode == 410) &&
                    autoRetriedVideoIds.add(videoId)
                ) {
                    PlaybackDiagnostics.w(
                        "ExoHttpFallbackRetry | title=\"$title\" | videoId=$videoId | httpStatus=$httpCode"
                    )
                    musicRepository.invalidateStreamCache(videoId)
                    player.prepare()
                    player.play()
                }
            }
        })

        val sessionActivityIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val sessionActivityPendingIntent = PendingIntent.getActivity(
            this,
            0,
            sessionActivityIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        setMediaNotificationProvider(
            DefaultMediaNotificationProvider.Builder(this)
                .build()
                .apply {
                    setSmallIcon(R.drawable.ic_launcher_foreground)
                }
        )

        exoPlayer = player
        mediaSession = MediaSession.Builder(this, player)
            .setSessionActivity(sessionActivityPendingIntent)
            .build()
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaSession? {
        return mediaSession
    }

    override fun onTaskRemoved(rootIntent: Intent?) {
        val player = mediaSession?.player
        if (player == null || !player.playWhenReady || player.mediaItemCount == 0 ||
            player.playbackState == Player.STATE_ENDED
        ) {
            stopSelf()
        }
    }

    override fun onDestroy() {
        mediaSession?.run {
            player.release()
            release()
            mediaSession = null
        }
        exoPlayer = null
        super.onDestroy()
    }

    private fun findHttpStatusCode(error: Throwable?): Int? {
        var current: Throwable? = error
        var depth = 0
        while (current != null && depth < 10) {
            if (current is HttpDataSource.InvalidResponseCodeException) {
                return current.responseCode
            }
            current = current.cause
            depth++
        }
        return null
    }

    companion object {
        const val SCHEME_VYORA = "vyora"
        const val SCHEME_NEXA = "nexa"
        const val HOST_STREAM = "stream"

        fun buildMediaItem(song: Song, cachedStream: PlaybackStream? = null): MediaItem {
            val extras = android.os.Bundle().apply {
                putString("song_id", song.id)
                putString("artist_id", song.artistId)
                putString("album_id", song.albumId)
                putString("duration_text", song.durationText)
                putLong("duration_ms", song.durationMs)
                putBoolean("is_explicit", song.isExplicit)
            }
            val metadata = MediaMetadata.Builder()
                .setTitle(song.title)
                .setArtist(song.artist)
                .setAlbumTitle(song.album)
                .setArtworkUri(song.thumbnailUrl.takeIf { it.isNotBlank() }?.let(Uri::parse))
                .setIsPlayable(true)
                .setMediaType(MediaMetadata.MEDIA_TYPE_MUSIC)
                .setExtras(extras)
                .build()

            val builder = MediaItem.Builder()
                .setMediaId(song.id)
                .setUri("$SCHEME_VYORA://$HOST_STREAM/${song.id}")
                .setMediaMetadata(metadata)

            if (cachedStream?.isHls == true) {
                builder.setMimeType(MimeTypes.APPLICATION_M3U8)
            }
            return builder.build()
        }
    }
}
