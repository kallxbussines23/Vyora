package com.vyorasound.app.presentation.theme

import androidx.compose.ui.graphics.Color

object NexaColors {
    val Background = Color(0xFF080A10)
    val BackgroundElevated = Color(0xFF0D101B)
    val Surface = Color(0xFF141824)
    val SurfaceHigh = Color(0xFF1B2030)
    val Glass = Color(0x12FFFFFF)
    val GlassStrong = Color(0x1FFFFFFF)
    val GlassBorder = Color(0x28FFFFFF)
    val GlassBorderSubtle = Color(0x14FFFFFF)
    val Primary = Color(0xFFB69CFF)
    val Accent = Color(0xFF8D75E8)
    val OnPrimary = Color(0xFF110A26)
    val TextPrimary = Color(0xFFFFFFFF)
    val TextSecondary = Color(0xFF9296A8)
    val Error = Color(0xFFFF6B8B)
    val Success = Color(0xFF5EEAD4)
}
