package com.vyorasound.app.presentation.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.PlaylistAdd
import androidx.compose.material.icons.automirrored.rounded.QueueMusic
import androidx.compose.material.icons.rounded.Album
import androidx.compose.material.icons.rounded.Explicit
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.rounded.FavoriteBorder
import androidx.compose.material.icons.rounded.GraphicEq
import androidx.compose.material.icons.rounded.MoreVert
import androidx.compose.material.icons.rounded.Person
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.SkipNext
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.vyorasound.app.R
import com.vyorasound.app.domain.model.Album
import com.vyorasound.app.domain.model.Artist
import com.vyorasound.app.domain.model.MediaShelfItem
import com.vyorasound.app.domain.model.MoodCategory
import com.vyorasound.app.domain.model.Playlist
import com.vyorasound.app.domain.model.Song
import com.vyorasound.app.presentation.theme.GlassCard
import com.vyorasound.app.presentation.theme.NexaColors

@Composable
fun NexaArtwork(
    url: String,
    contentDescription: String,
    modifier: Modifier = Modifier,
    shape: Shape = RoundedCornerShape(16.dp)
) {
    val context = LocalContext.current
    val model = remember(url) {
        if (url.isBlank()) R.drawable.img_vyora_ambient_hero
        else ImageRequest.Builder(context)
            .data(url)
            .crossfade(true)
            .build()
    }
    Box(
        modifier = modifier
            .clip(shape)
            .background(NexaColors.SurfaceHigh)
            .border(0.75.dp, NexaColors.GlassBorderSubtle, shape)
    ) {
        AsyncImage(
            model = model,
            contentDescription = contentDescription,
            placeholder = painterResource(R.drawable.img_vyora_ambient_hero),
            error = painterResource(R.drawable.img_vyora_ambient_hero),
            contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize()
        )
    }
}

@Composable
fun SectionHeader(
    title: String,
    subtitle: String? = null,
    actionLabel: String? = null,
    onActionClick: (() -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            if (!subtitle.isNullOrBlank()) {
                Text(
                    text = subtitle.uppercase(),
                    style = MaterialTheme.typography.labelSmall,
                    color = NexaColors.Primary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
            Text(
                text = title,
                style = MaterialTheme.typography.headlineSmall,
                color = NexaColors.TextPrimary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
        if (actionLabel != null && onActionClick != null) {
            Text(
                text = actionLabel,
                style = MaterialTheme.typography.labelLarge,
                color = NexaColors.Primary,
                modifier = Modifier
                    .clip(RoundedCornerShape(50))
                    .clickable(onClick = onActionClick)
                    .padding(horizontal = 12.dp, vertical = 8.dp)
            )
        }
    }
}

@Composable
fun ShelfMediaCard(
    item: MediaShelfItem,
    onSongClick: (Song) -> Unit,
    onAlbumClick: (Album) -> Unit,
    onArtistClick: (Artist) -> Unit,
    onPlaylistClick: (Playlist) -> Unit,
    onMoodClick: (MoodCategory) -> Unit,
    cardWidth: Dp = 152.dp
) {
    when (item) {
        is MediaShelfItem.SongItem -> {
            SquareMediaCard(
                title = item.song.title,
                subtitle = item.song.artist,
                thumbnailUrl = item.song.thumbnailUrl,
                width = cardWidth,
                isRound = false,
                showPlayBadge = true,
                onClick = { onSongClick(item.song) }
            )
        }
        is MediaShelfItem.AlbumItem -> {
            SquareMediaCard(
                title = item.album.title,
                subtitle = listOfNotNull(item.album.artist.takeIf { it.isNotBlank() }, item.album.year)
                    .joinToString(" • "),
                thumbnailUrl = item.album.thumbnailUrl,
                width = cardWidth,
                isRound = false,
                showPlayBadge = false,
                onClick = { onAlbumClick(item.album) }
            )
        }
        is MediaShelfItem.ArtistItem -> {
            SquareMediaCard(
                title = item.artist.name,
                subtitle = item.artist.subtitle.ifBlank { "Artis" },
                thumbnailUrl = item.artist.thumbnailUrl,
                width = cardWidth,
                isRound = true,
                showPlayBadge = false,
                onClick = { onArtistClick(item.artist) }
            )
        }
        is MediaShelfItem.PlaylistItem -> {
            SquareMediaCard(
                title = item.playlist.title,
                subtitle = item.playlist.author.ifBlank { item.playlist.trackCountText }.ifBlank { "Playlist" },
                thumbnailUrl = item.playlist.thumbnailUrl,
                width = cardWidth,
                isRound = false,
                showPlayBadge = false,
                onClick = { onPlaylistClick(item.playlist) }
            )
        }
        is MediaShelfItem.MoodItem -> {
            MoodCategoryCard(
                mood = item.mood,
                onClick = { onMoodClick(item.mood) },
                modifier = Modifier.width(cardWidth)
            )
        }
    }
}

@Composable
fun SquareMediaCard(
    title: String,
    subtitle: String,
    thumbnailUrl: String,
    width: Dp = 152.dp,
    isRound: Boolean = false,
    showPlayBadge: Boolean = false,
    onClick: () -> Unit
) {
    val shape = if (isRound) CircleShape else RoundedCornerShape(18.dp)
    GlassCard(
        modifier = Modifier.width(width),
        shape = RoundedCornerShape(20.dp),
        backgroundAlpha = 0.45f,
        onClick = onClick
    ) {
        Column(
            modifier = Modifier.padding(10.dp),
            horizontalAlignment = if (isRound) Alignment.CenterHorizontally else Alignment.Start
        ) {
            Box(modifier = Modifier.size(width - 20.dp)) {
                NexaArtwork(
                    url = thumbnailUrl,
                    contentDescription = title,
                    shape = shape,
                    modifier = Modifier.fillMaxSize()
                )
                if (showPlayBadge) {
                    Box(
                        modifier = Modifier
                            .align(Alignment.BottomEnd)
                            .padding(6.dp)
                            .size(32.dp)
                            .clip(CircleShape)
                            .background(NexaColors.Primary.copy(alpha = 0.92f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.PlayArrow,
                            contentDescription = "Play $title",
                            tint = NexaColors.OnPrimary,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }
            }
            Spacer(modifier = Modifier.height(10.dp))
            Text(
                text = title,
                style = MaterialTheme.typography.titleSmall,
                color = NexaColors.TextPrimary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            if (subtitle.isNotBlank()) {
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.bodySmall,
                    color = NexaColors.TextSecondary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
    }
}

@Composable
fun MoodCategoryCard(
    mood: MoodCategory,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val accent = Color(mood.accentColor or 0xFF000000L).let {
        if (it == Color.Black) NexaColors.Accent else it
    }
    GlassCard(
        modifier = modifier.height(68.dp),
        shape = RoundedCornerShape(18.dp),
        backgroundAlpha = 0.6f,
        onClick = onClick
    ) {
        Row(
            modifier = Modifier.fillMaxSize(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .width(6.dp)
                    .height(68.dp)
                    .background(
                        Brush.verticalGradient(listOf(accent, NexaColors.Primary))
                    )
            )
            Text(
                text = mood.title,
                style = MaterialTheme.typography.titleSmall,
                color = NexaColors.TextPrimary,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.padding(horizontal = 14.dp)
            )
        }
    }
}

@Composable
fun SongRowItem(
    song: Song,
    isPlaying: Boolean,
    isLiked: Boolean,
    onClick: () -> Unit,
    onToggleLike: () -> Unit,
    onPlayNext: () -> Unit,
    onAddToQueue: () -> Unit,
    onAddToPlaylist: () -> Unit,
    onOpenArtist: ((String) -> Unit)? = null,
    onOpenAlbum: ((String) -> Unit)? = null,
    modifier: Modifier = Modifier,
    indexBadge: Int? = null
) {
    var menuExpanded by remember { mutableStateOf(false) }

    GlassCard(
        modifier = modifier
            .fillMaxWidth()
            .testTag("song_row_${song.id}"),
        shape = RoundedCornerShape(18.dp),
        backgroundAlpha = if (isPlaying) 0.72f else 0.38f,
        onClick = onClick
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (indexBadge != null) {
                Text(
                    text = indexBadge.toString(),
                    style = MaterialTheme.typography.labelLarge,
                    color = if (isPlaying) NexaColors.Primary else NexaColors.TextSecondary,
                    modifier = Modifier.width(26.dp)
                )
            }

            Box(modifier = Modifier.size(52.dp)) {
                NexaArtwork(
                    url = song.thumbnailUrl,
                    contentDescription = song.title,
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxSize()
                )
                if (isPlaying) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .clip(RoundedCornerShape(12.dp))
                            .background(Color.Black.copy(alpha = 0.55f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.GraphicEq,
                            contentDescription = "Now playing",
                            tint = NexaColors.Primary,
                            modifier = Modifier.size(22.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.width(12.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = song.title,
                    style = MaterialTheme.typography.titleMedium,
                    color = if (isPlaying) NexaColors.Primary else NexaColors.TextPrimary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Spacer(modifier = Modifier.height(2.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    if (song.isExplicit) {
                        Icon(
                            imageVector = Icons.Rounded.Explicit,
                            contentDescription = "Explicit",
                            tint = NexaColors.TextSecondary,
                            modifier = Modifier
                                .size(14.dp)
                                .padding(end = 3.dp)
                        )
                    }
                    val meta = buildString {
                        append(song.artist)
                        if (song.durationText.isNotBlank()) {
                            append(" • ")
                            append(song.durationText)
                        }
                    }
                    Text(
                        text = meta,
                        style = MaterialTheme.typography.bodySmall,
                        color = NexaColors.TextSecondary,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }

            IconButton(
                onClick = onToggleLike,
                modifier = Modifier.size(48.dp)
            ) {
                Icon(
                    imageVector = if (isLiked) Icons.Rounded.Favorite else Icons.Rounded.FavoriteBorder,
                    contentDescription = if (isLiked) "Remove from liked" else "Like song",
                    tint = if (isLiked) NexaColors.Primary else NexaColors.TextSecondary,
                    modifier = Modifier.size(20.dp)
                )
            }

            Box {
                IconButton(
                    onClick = { menuExpanded = true },
                    modifier = Modifier.size(48.dp)
                ) {
                    Icon(
                        imageVector = Icons.Rounded.MoreVert,
                        contentDescription = "More options",
                        tint = NexaColors.TextSecondary,
                        modifier = Modifier.size(20.dp)
                    )
                }

                DropdownMenu(
                    expanded = menuExpanded,
                    onDismissRequest = { menuExpanded = false },
                    containerColor = NexaColors.SurfaceHigh
                ) {
                    DropdownMenuItem(
                        text = { Text("Putar berikutnya", color = NexaColors.TextPrimary) },
                        leadingIcon = {
                            Icon(Icons.Rounded.SkipNext, contentDescription = null, tint = NexaColors.Primary)
                        },
                        onClick = {
                            menuExpanded = false
                            onPlayNext()
                        }
                    )
                    DropdownMenuItem(
                        text = { Text("Tambah ke antrean", color = NexaColors.TextPrimary) },
                        leadingIcon = {
                            Icon(Icons.AutoMirrored.Rounded.QueueMusic, contentDescription = null, tint = NexaColors.Primary)
                        },
                        onClick = {
                            menuExpanded = false
                            onAddToQueue()
                        }
                    )
                    DropdownMenuItem(
                        text = { Text("Tambah ke playlist", color = NexaColors.TextPrimary) },
                        leadingIcon = {
                            Icon(Icons.AutoMirrored.Rounded.PlaylistAdd, contentDescription = null, tint = NexaColors.Primary)
                        },
                        onClick = {
                            menuExpanded = false
                            onAddToPlaylist()
                        }
                    )
                    if (!song.artistId.isNullOrBlank() && onOpenArtist != null) {
                        DropdownMenuItem(
                            text = { Text("Lihat artis", color = NexaColors.TextPrimary) },
                            leadingIcon = {
                                Icon(Icons.Rounded.Person, contentDescription = null, tint = NexaColors.TextSecondary)
                            },
                            onClick = {
                                menuExpanded = false
                                onOpenArtist(song.artistId)
                            }
                        )
                    }
                    if (!song.albumId.isNullOrBlank() && onOpenAlbum != null) {
                        DropdownMenuItem(
                            text = { Text("Lihat album", color = NexaColors.TextPrimary) },
                            leadingIcon = {
                                Icon(Icons.Rounded.Album, contentDescription = null, tint = NexaColors.TextSecondary)
                            },
                            onClick = {
                                menuExpanded = false
                                onOpenAlbum(song.albumId)
                            }
                        )
                    }
                }
            }
        }
    }
}
