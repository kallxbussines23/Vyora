package com.vyorasound.app.presentation.detail

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Bookmark
import androidx.compose.material.icons.rounded.BookmarkBorder
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Shuffle
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.vyorasound.app.domain.model.Album
import com.vyorasound.app.domain.model.Artist
import com.vyorasound.app.domain.model.MediaShelfItem
import com.vyorasound.app.domain.model.MoodCategory
import com.vyorasound.app.domain.model.Playlist
import com.vyorasound.app.domain.model.Song
import com.vyorasound.app.presentation.components.NexaArtwork
import com.vyorasound.app.presentation.components.SectionHeader
import com.vyorasound.app.presentation.components.ShelfMediaCard
import com.vyorasound.app.presentation.components.SongRowItem
import com.vyorasound.app.presentation.theme.EmptyStateCard
import com.vyorasound.app.presentation.theme.ErrorStateCard
import com.vyorasound.app.presentation.theme.GlassBottomSpacer
import com.vyorasound.app.presentation.theme.HomeFeedSkeleton
import com.vyorasound.app.presentation.theme.NexaColors

@Composable
fun DetailScreen(
    viewModel: DetailViewModel,
    currentSongId: String?,
    onBack: () -> Unit,
    onPlaySong: (Song, List<Song>?) -> Unit,
    onPlayNext: (Song) -> Unit,
    onAddToQueue: (Song) -> Unit,
    onToggleLike: (Song) -> Unit,
    onAddToPlaylist: (Song) -> Unit,
    onOpenAlbum: (Album) -> Unit,
    onOpenArtist: (Artist) -> Unit,
    onOpenPlaylist: (Playlist) -> Unit,
    onOpenMood: (MoodCategory) -> Unit
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val likedIds by viewModel.likedSongIds.collectAsStateWithLifecycle()
    val isSaved by viewModel.isSaved.collectAsStateWithLifecycle()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .statusBarsPadding()
    ) {
        // Top Navigation Bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(
                onClick = onBack,
                modifier = Modifier
                    .size(48.dp)
                    .clip(CircleShape)
                    .background(NexaColors.Glass)
            ) {
                Icon(
                    imageVector = Icons.AutoMirrored.Rounded.ArrowBack,
                    contentDescription = "Back",
                    tint = NexaColors.TextPrimary
                )
            }

            val showSave = uiState.payload is DetailPayload.ArtistContent ||
                uiState.payload is DetailPayload.AlbumContent ||
                (uiState.payload as? DetailPayload.PlaylistContent)?.isUserCreated == false

            if (showSave) {
                IconButton(
                    onClick = viewModel::toggleSave,
                    modifier = Modifier
                        .size(48.dp)
                        .clip(CircleShape)
                        .background(NexaColors.Glass)
                ) {
                    Icon(
                        imageVector = if (isSaved) Icons.Rounded.Bookmark else Icons.Rounded.BookmarkBorder,
                        contentDescription = if (isSaved) "Saved" else "Save to library",
                        tint = if (isSaved) NexaColors.Primary else NexaColors.TextPrimary
                    )
                }
            }
        }

        when {
            uiState.isLoading -> {
                HomeFeedSkeleton()
            }

            uiState.errorMessage != null -> {
                ErrorStateCard(
                    message = uiState.errorMessage ?: "Unable to load details.",
                    onRetry = viewModel::loadDetail
                )
            }

            else -> {
                when (val payload = uiState.payload) {
                    is DetailPayload.ArtistContent -> {
                        val artist = payload.detail
                        LazyColumn(
                            modifier = Modifier.fillMaxSize(),
                            contentPadding = PaddingValues(vertical = 8.dp),
                            verticalArrangement = Arrangement.spacedBy(20.dp)
                        ) {
                            item(key = "artist_header") {
                                Column(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(horizontal = 20.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                    verticalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    NexaArtwork(
                                        url = artist.thumbnailUrl,
                                        contentDescription = artist.name,
                                        shape = CircleShape,
                                        modifier = Modifier.size(164.dp)
                                    )
                                    Text(
                                        text = artist.name,
                                        style = MaterialTheme.typography.displaySmall,
                                        color = NexaColors.TextPrimary,
                                        textAlign = TextAlign.Center
                                    )
                                    if (artist.subscriberCount.isNotBlank()) {
                                        Text(
                                            text = artist.subscriberCount,
                                            style = MaterialTheme.typography.bodyMedium,
                                            color = NexaColors.Primary
                                        )
                                    }
                                    if (artist.description.isNotBlank()) {
                                        Text(
                                            text = artist.description,
                                            style = MaterialTheme.typography.bodySmall,
                                            color = NexaColors.TextSecondary,
                                            maxLines = 3,
                                            overflow = TextOverflow.Ellipsis,
                                            textAlign = TextAlign.Center
                                        )
                                    }
                                    if (artist.topSongs.isNotEmpty()) {
                                        DetailActionButtons(
                                            onPlayAll = { onPlaySong(artist.topSongs.first(), artist.topSongs) },
                                            onShuffle = {
                                                val s = artist.topSongs.shuffled()
                                                onPlaySong(s.first(), s)
                                            }
                                        )
                                    }
                                }
                            }

                            if (artist.topSongs.isNotEmpty()) {
                                item(key = "artist_songs_hdr") {
                                    SectionHeader(title = "Lagu Terpopuler")
                                }
                                itemsIndexed(artist.topSongs, key = { idx, s -> "art_s_${idx}_${s.id}" }) { index, song ->
                                    SongRowItem(
                                        song = song,
                                        isPlaying = song.id == currentSongId,
                                        isLiked = song.id in likedIds,
                                        indexBadge = index + 1,
                                        onClick = { onPlaySong(song, artist.topSongs) },
                                        onToggleLike = { onToggleLike(song) },
                                        onPlayNext = { onPlayNext(song) },
                                        onAddToQueue = { onAddToQueue(song) },
                                        onAddToPlaylist = { onAddToPlaylist(song) },
                                        modifier = Modifier.padding(horizontal = 20.dp)
                                    )
                                }
                            }

                            if (artist.albums.isNotEmpty()) {
                                item(key = "artist_albums") {
                                    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                                        SectionHeader(title = "Albums")
                                        LazyRow(
                                            contentPadding = PaddingValues(horizontal = 20.dp),
                                            horizontalArrangement = Arrangement.spacedBy(14.dp)
                                        ) {
                                            items(artist.albums, key = { "aa_${it.browseId}" }) { album ->
                                                ShelfMediaCard(
                                                    item = MediaShelfItem.AlbumItem(album),
                                                    onSongClick = {},
                                                    onAlbumClick = onOpenAlbum,
                                                    onArtistClick = onOpenArtist,
                                                    onPlaylistClick = onOpenPlaylist,
                                                    onMoodClick = onOpenMood
                                                )
                                            }
                                        }
                                    }
                                }
                            }

                            if (artist.singles.isNotEmpty()) {
                                item(key = "artist_singles") {
                                    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                                        SectionHeader(title = "Single & EP")
                                        LazyRow(
                                            contentPadding = PaddingValues(horizontal = 20.dp),
                                            horizontalArrangement = Arrangement.spacedBy(14.dp)
                                        ) {
                                            items(artist.singles, key = { "as_${it.browseId}" }) { album ->
                                                ShelfMediaCard(
                                                    item = MediaShelfItem.AlbumItem(album),
                                                    onSongClick = {},
                                                    onAlbumClick = onOpenAlbum,
                                                    onArtistClick = onOpenArtist,
                                                    onPlaylistClick = onOpenPlaylist,
                                                    onMoodClick = onOpenMood
                                                )
                                            }
                                        }
                                    }
                                }
                            }

                            if (artist.relatedArtists.isNotEmpty()) {
                                item(key = "artist_related") {
                                    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                                        SectionHeader(title = "Artis Serupa")
                                        LazyRow(
                                            contentPadding = PaddingValues(horizontal = 20.dp),
                                            horizontalArrangement = Arrangement.spacedBy(14.dp)
                                        ) {
                                            items(artist.relatedArtists, key = { "ar_${it.browseId}" }) { rel ->
                                                ShelfMediaCard(
                                                    item = MediaShelfItem.ArtistItem(rel),
                                                    onSongClick = {},
                                                    onAlbumClick = onOpenAlbum,
                                                    onArtistClick = onOpenArtist,
                                                    onPlaylistClick = onOpenPlaylist,
                                                    onMoodClick = onOpenMood
                                                )
                                            }
                                        }
                                    }
                                }
                            }

                            item { GlassBottomSpacer() }
                        }
                    }

                    is DetailPayload.AlbumContent -> {
                        val album = payload.detail
                        LazyColumn(
                            modifier = Modifier.fillMaxSize(),
                            contentPadding = PaddingValues(vertical = 8.dp),
                            verticalArrangement = Arrangement.spacedBy(14.dp)
                        ) {
                            item(key = "album_header") {
                                DetailArtworkHeader(
                                    title = album.title,
                                    subtitle = listOfNotNull(album.artist, album.year, album.durationText.takeIf { it.isNotBlank() })
                                        .joinToString(" • "),
                                    description = album.description,
                                    thumbnailUrl = album.thumbnailUrl,
                                    hasSongs = album.songs.isNotEmpty(),
                                    onPlayAll = { onPlaySong(album.songs.first(), album.songs) },
                                    onShuffle = {
                                        val s = album.songs.shuffled()
                                        onPlaySong(s.first(), s)
                                    }
                                )
                            }
                            itemsIndexed(album.songs, key = { idx, s -> "alb_${idx}_${s.id}" }) { index, song ->
                                SongRowItem(
                                    song = song,
                                    isPlaying = song.id == currentSongId,
                                    isLiked = song.id in likedIds,
                                    indexBadge = index + 1,
                                    onClick = { onPlaySong(song, album.songs) },
                                    onToggleLike = { onToggleLike(song) },
                                    onPlayNext = { onPlayNext(song) },
                                    onAddToQueue = { onAddToQueue(song) },
                                    onAddToPlaylist = { onAddToPlaylist(song) },
                                    onOpenArtist = { id -> onOpenArtist(Artist(id = id, name = song.artist)) },
                                    modifier = Modifier.padding(horizontal = 20.dp)
                                )
                            }
                            item { GlassBottomSpacer() }
                        }
                    }

                    is DetailPayload.PlaylistContent -> {
                        val playlist = payload.detail
                        LazyColumn(
                            modifier = Modifier.fillMaxSize(),
                            contentPadding = PaddingValues(vertical = 8.dp),
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            item(key = "playlist_header") {
                                DetailArtworkHeader(
                                    title = playlist.title,
                                    subtitle = listOfNotNull(
                                        playlist.author.takeIf { it.isNotBlank() },
                                        playlist.trackCountText.takeIf { it.isNotBlank() }
                                    ).joinToString(" • "),
                                    description = playlist.description,
                                    thumbnailUrl = playlist.thumbnailUrl,
                                    hasSongs = playlist.songs.isNotEmpty(),
                                    onPlayAll = { onPlaySong(playlist.songs.first(), playlist.songs) },
                                    onShuffle = {
                                        val s = playlist.songs.shuffled()
                                        onPlaySong(s.first(), s)
                                    }
                                )
                            }

                            if (playlist.songs.isEmpty()) {
                                item {
                                    EmptyStateCard(
                                        icon = Icons.Rounded.MusicNote,
                                        title = "Playlist masih kosong",
                                        subtitle = "Gunakan menu titik tiga pada lagu mana saja untuk menambahkannya ke playlist ini."
                                    )
                                }
                            } else {
                                itemsIndexed(playlist.songs, key = { idx, s -> "pl_${idx}_${s.id}" }) { index, song ->
                                    SongRowItem(
                                        song = song,
                                        isPlaying = song.id == currentSongId,
                                        isLiked = song.id in likedIds,
                                        indexBadge = index + 1,
                                        onClick = { onPlaySong(song, playlist.songs) },
                                        onToggleLike = { onToggleLike(song) },
                                        onPlayNext = { onPlayNext(song) },
                                        onAddToQueue = { onAddToQueue(song) },
                                        onAddToPlaylist = { onAddToPlaylist(song) },
                                        onOpenArtist = { id -> onOpenArtist(Artist(id = id, name = song.artist)) },
                                        onOpenAlbum = { id -> onOpenAlbum(Album(id = id, title = song.album.orEmpty(), artist = song.artist)) },
                                        modifier = Modifier.padding(horizontal = 20.dp)
                                    )
                                }
                            }

                            if (playlist.continuation != null) {
                                item(key = "pl_load_more") {
                                    Box(
                                        modifier = Modifier.fillMaxWidth(),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Button(
                                            onClick = viewModel::loadMorePlaylistTracks,
                                            enabled = !uiState.isLoadingMore,
                                            colors = ButtonDefaults.buttonColors(
                                                containerColor = NexaColors.GlassStrong,
                                                contentColor = NexaColors.Primary
                                            ),
                                            shape = RoundedCornerShape(50)
                                        ) {
                                            if (uiState.isLoadingMore) {
                                                CircularProgressIndicator(
                                                    color = NexaColors.Primary,
                                                    strokeWidth = 2.dp,
                                                    modifier = Modifier.size(18.dp)
                                                )
                                                Spacer(modifier = Modifier.width(8.dp))
                                            }
                                            Text("Muat lagu lainnya")
                                        }
                                    }
                                }
                            }

                            item { GlassBottomSpacer() }
                        }
                    }

                    is DetailPayload.CategoryContent -> {
                        LazyColumn(
                            modifier = Modifier.fillMaxSize(),
                            contentPadding = PaddingValues(vertical = 8.dp),
                            verticalArrangement = Arrangement.spacedBy(22.dp)
                        ) {
                            item(key = "cat_title") {
                                Text(
                                    text = payload.title,
                                    style = MaterialTheme.typography.displaySmall,
                                    color = NexaColors.TextPrimary,
                                    modifier = Modifier.padding(horizontal = 20.dp)
                                )
                            }
                            itemsIndexed(payload.sections, key = { idx, sec -> "cat_${idx}_${sec.title}" }) { _, section ->
                                val songsInSec = section.items.filterIsInstance<MediaShelfItem.SongItem>().map { it.song }
                                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                                    SectionHeader(title = section.title, subtitle = section.subtitle)
                                    LazyRow(
                                        contentPadding = PaddingValues(horizontal = 20.dp),
                                        horizontalArrangement = Arrangement.spacedBy(14.dp)
                                    ) {
                                        items(section.items, key = { "${section.title}_${it.stableId}" }) { item ->
                                            ShelfMediaCard(
                                                item = item,
                                                onSongClick = { s -> onPlaySong(s, songsInSec.ifEmpty { listOf(s) }) },
                                                onAlbumClick = onOpenAlbum,
                                                onArtistClick = onOpenArtist,
                                                onPlaylistClick = onOpenPlaylist,
                                                onMoodClick = onOpenMood
                                            )
                                        }
                                    }
                                }
                            }
                            item { GlassBottomSpacer() }
                        }
                    }

                    null -> Unit
                }
            }
        }
    }
}

@Composable
private fun DetailArtworkHeader(
    title: String,
    subtitle: String,
    description: String,
    thumbnailUrl: String,
    hasSongs: Boolean,
    onPlayAll: () -> Unit,
    onShuffle: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Box(
            modifier = Modifier
                .size(204.dp)
                .background(
                    Brush.radialGradient(
                        listOf(NexaColors.Primary.copy(alpha = 0.25f), Color.Transparent)
                    ),
                    CircleShape
                ),
            contentAlignment = Alignment.Center
        ) {
            NexaArtwork(
                url = thumbnailUrl,
                contentDescription = title,
                shape = RoundedCornerShape(24.dp),
                modifier = Modifier.size(188.dp)
            )
        }
        Text(
            text = title,
            style = MaterialTheme.typography.headlineMedium,
            color = NexaColors.TextPrimary,
            textAlign = TextAlign.Center
        )
        if (subtitle.isNotBlank()) {
            Text(
                text = subtitle,
                style = MaterialTheme.typography.bodyMedium,
                color = NexaColors.TextSecondary,
                textAlign = TextAlign.Center
            )
        }
        if (description.isNotBlank()) {
            Text(
                text = description,
                style = MaterialTheme.typography.bodySmall,
                color = NexaColors.TextSecondary,
                maxLines = 3,
                overflow = TextOverflow.Ellipsis,
                textAlign = TextAlign.Center
            )
        }
        if (hasSongs) {
            DetailActionButtons(onPlayAll = onPlayAll, onShuffle = onShuffle)
        }
    }
}

@Composable
private fun DetailActionButtons(
    onPlayAll: () -> Unit,
    onShuffle: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(top = 4.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Button(
            onClick = onPlayAll,
            colors = ButtonDefaults.buttonColors(
                containerColor = NexaColors.Primary,
                contentColor = NexaColors.OnPrimary
            ),
            shape = RoundedCornerShape(50),
            modifier = Modifier
                .weight(1f)
                .height(48.dp)
        ) {
            Icon(Icons.Rounded.PlayArrow, contentDescription = null, modifier = Modifier.size(20.dp))
            Spacer(modifier = Modifier.width(6.dp))
            Text("Putar Semua")
        }
        OutlinedButton(
            onClick = onShuffle,
            shape = RoundedCornerShape(50),
            colors = ButtonDefaults.outlinedButtonColors(contentColor = NexaColors.Primary),
            modifier = Modifier
                .weight(1f)
                .height(48.dp)
        ) {
            Icon(Icons.Rounded.Shuffle, contentDescription = null, modifier = Modifier.size(18.dp))
            Spacer(modifier = Modifier.width(6.dp))
            Text("Acak")
        }
    }
}
