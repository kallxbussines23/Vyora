package com.vyorasound.app.presentation.theme

import android.os.Build
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.WifiOff
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

@Composable
fun NexaAmbientBackground(
    modifier: Modifier = Modifier,
    content: @Composable BoxScope.() -> Unit
) {
    Box(
        modifier = modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(
                        NexaColors.BackgroundElevated,
                        NexaColors.Background,
                        Color(0xFF06070C)
                    )
                )
            )
    ) {
        // Subtle ambient orbs (hardware-accelerated radial gradients + blur on API 31+)
        val blurModifier = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            Modifier.blur(90.dp)
        } else {
            Modifier
        }

        Box(
            modifier = Modifier
                .size(280.dp)
                .offset(x = (-60).dp, y = (-50).dp)
                .then(blurModifier)
                .background(
                    Brush.radialGradient(
                        colors = listOf(
                            NexaColors.Accent.copy(alpha = 0.24f),
                            Color.Transparent
                        )
                    ),
                    shape = CircleShape
                )
        )

        Box(
            modifier = Modifier
                .size(260.dp)
                .align(Alignment.TopEnd)
                .offset(x = 80.dp, y = 140.dp)
                .then(blurModifier)
                .background(
                    Brush.radialGradient(
                        colors = listOf(
                            NexaColors.Primary.copy(alpha = 0.14f),
                            Color.Transparent
                        )
                    ),
                    shape = CircleShape
                )
        )

        content()
    }
}

@Composable
fun GlassCard(
    modifier: Modifier = Modifier,
    shape: Shape = RoundedCornerShape(20.dp),
    backgroundAlpha: Float = 0.65f,
    onClick: (() -> Unit)? = null,
    content: @Composable BoxScope.() -> Unit
) {
    val glassBrush = Brush.linearGradient(
        colors = listOf(
            NexaColors.SurfaceHigh.copy(alpha = backgroundAlpha),
            NexaColors.Surface.copy(alpha = backgroundAlpha * 0.85f)
        )
    )
    val borderBrush = Brush.linearGradient(
        colors = listOf(
            NexaColors.GlassBorder,
            NexaColors.GlassBorderSubtle
        )
    )

    val baseModifier = modifier
        .shadow(
            elevation = 12.dp,
            shape = shape,
            ambientColor = Color.Black.copy(alpha = 0.45f),
            spotColor = NexaColors.Accent.copy(alpha = 0.12f)
        )
        .clip(shape)
        .background(glassBrush)
        .background(NexaColors.Glass)
        .border(BorderStroke(1.dp, borderBrush), shape)
        .let { if (onClick != null) it.clickable(onClick = onClick) else it }

    Box(modifier = baseModifier, content = content)
}

@Composable
fun GlassPill(
    selected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    content: @Composable BoxScope.() -> Unit
) {
    val shape = RoundedCornerShape(50)
    val bgColor = if (selected) {
        Brush.horizontalGradient(
            listOf(
                NexaColors.Primary.copy(alpha = 0.30f),
                NexaColors.Accent.copy(alpha = 0.25f)
            )
        )
    } else {
        Brush.horizontalGradient(
            listOf(NexaColors.Glass, NexaColors.Surface.copy(alpha = 0.55f))
        )
    }
    val borderColor = if (selected) NexaColors.Primary.copy(alpha = 0.7f) else NexaColors.GlassBorderSubtle

    Box(
        modifier = modifier
            .clip(shape)
            .background(bgColor)
            .border(1.dp, borderColor, shape)
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 10.dp),
        contentAlignment = Alignment.Center,
        content = content
    )
}

@Composable
fun ShimmerBox(
    modifier: Modifier = Modifier,
    shape: Shape = RoundedCornerShape(14.dp)
) {
    val transition = rememberInfiniteTransition(label = "shimmer")
    val shift by transition.animateFloat(
        initialValue = 0f,
        targetValue = 1000f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 1200, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "shimmer_shift"
    )
    val brush = Brush.linearGradient(
        colors = listOf(
            NexaColors.Surface.copy(alpha = 0.75f),
            NexaColors.SurfaceHigh.copy(alpha = 0.95f),
            NexaColors.Surface.copy(alpha = 0.75f)
        ),
        start = Offset(shift - 300f, 0f),
        end = Offset(shift, 300f)
    )
    Box(
        modifier = modifier
            .clip(shape)
            .background(brush)
    )
}

@Composable
fun HomeFeedSkeleton(modifier: Modifier = Modifier) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp),
        verticalArrangement = Arrangement.spacedBy(24.dp)
    ) {
        ShimmerBox(modifier = Modifier.fillMaxWidth().height(110.dp), shape = RoundedCornerShape(22.dp))
        repeat(3) {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                ShimmerBox(modifier = Modifier.width(170.dp).height(22.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                    repeat(3) {
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            ShimmerBox(modifier = Modifier.size(144.dp), shape = RoundedCornerShape(18.dp))
                            ShimmerBox(modifier = Modifier.width(120.dp).height(14.dp))
                            ShimmerBox(modifier = Modifier.width(84.dp).height(12.dp))
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun EmptyStateCard(
    icon: ImageVector,
    title: String,
    subtitle: String,
    modifier: Modifier = Modifier,
    actionLabel: String? = null,
    onAction: (() -> Unit)? = null
) {
    GlassCard(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp, vertical = 12.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 24.dp, vertical = 32.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Surface(
                modifier = Modifier.size(56.dp),
                shape = CircleShape,
                color = NexaColors.Primary.copy(alpha = 0.16f)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        imageVector = icon,
                        contentDescription = null,
                        tint = NexaColors.Primary,
                        modifier = Modifier.size(28.dp)
                    )
                }
            }
            Text(
                text = title,
                style = MaterialTheme.typography.titleLarge,
                color = NexaColors.TextPrimary,
                textAlign = TextAlign.Center
            )
            Text(
                text = subtitle,
                style = MaterialTheme.typography.bodyMedium,
                color = NexaColors.TextSecondary,
                textAlign = TextAlign.Center
            )
            if (actionLabel != null && onAction != null) {
                Spacer(modifier = Modifier.height(4.dp))
                Button(
                    onClick = onAction,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = NexaColors.Primary,
                        contentColor = NexaColors.OnPrimary
                    ),
                    shape = RoundedCornerShape(50)
                ) {
                    Text(actionLabel, style = MaterialTheme.typography.labelLarge)
                }
            }
        }
    }
}

@Composable
fun ErrorStateCard(
    message: String,
    onRetry: () -> Unit,
    modifier: Modifier = Modifier
) {
    GlassCard(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp, vertical = 16.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Icon(
                imageVector = Icons.Rounded.WifiOff,
                contentDescription = "Error",
                tint = NexaColors.Error,
                modifier = Modifier.size(36.dp)
            )
            Text(
                text = "Tidak dapat memuat musik",
                style = MaterialTheme.typography.titleLarge,
                color = NexaColors.TextPrimary
            )
            Text(
                text = message,
                style = MaterialTheme.typography.bodyMedium,
                color = NexaColors.TextSecondary,
                textAlign = TextAlign.Center
            )
            Button(
                onClick = onRetry,
                colors = ButtonDefaults.buttonColors(
                    containerColor = NexaColors.Primary,
                    contentColor = NexaColors.OnPrimary
                ),
                shape = RoundedCornerShape(50)
            ) {
                Icon(
                    imageVector = Icons.Rounded.Refresh,
                    contentDescription = null,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text("Coba Lagi", style = MaterialTheme.typography.labelLarge)
            }
        }
    }
}

@Composable
fun GlassBottomSpacer(height: Dp = 160.dp) {
    Spacer(modifier = Modifier.height(height))
}
