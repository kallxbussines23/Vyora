package com.vyorasound.app.presentation.search

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.vyorasound.app.domain.model.SearchFilter
import com.vyorasound.app.domain.model.SearchResults
import com.vyorasound.app.domain.model.SearchSuggestionItem
import com.vyorasound.app.domain.repository.LibraryRepository
import com.vyorasound.app.domain.repository.MusicRepository
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class SearchUiState(
    val query: String = "",
    val selectedFilter: SearchFilter = SearchFilter.SONGS,
    val isSearching: Boolean = false,
    val isLoadingMore: Boolean = false,
    val hasSearched: Boolean = false,
    val suggestions: List<SearchSuggestionItem> = emptyList(),
    val results: SearchResults = SearchResults(),
    val errorMessage: String? = null
)

class SearchViewModel(
    private val musicRepository: MusicRepository,
    private val libraryRepository: LibraryRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow(SearchUiState())
    val uiState: StateFlow<SearchUiState> = _uiState.asStateFlow()

    val searchHistory: StateFlow<List<String>> = libraryRepository.searchHistory
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    val likedSongIds: StateFlow<Set<String>> = MutableStateFlow<Set<String>>(emptySet()).also { flow ->
        viewModelScope.launch {
            libraryRepository.likedSongs.collect { songs ->
                flow.value = songs.map { it.id }.toSet()
            }
        }
    }

    private var suggestionJob: Job? = null
    private var searchJob: Job? = null

    fun onQueryChange(newQuery: String) {
        _uiState.update {
            it.copy(
                query = newQuery,
                hasSearched = if (newQuery.isBlank()) false else it.hasSearched,
                errorMessage = null
            )
        }
        suggestionJob?.cancel()
        if (newQuery.isBlank()) {
            _uiState.update { it.copy(suggestions = emptyList(), results = SearchResults(), hasSearched = false) }
            return
        }
        suggestionJob = viewModelScope.launch {
            delay(260L)
            musicRepository.getSearchSuggestions(newQuery)
                .onSuccess { items ->
                    _uiState.update { it.copy(suggestions = items) }
                }
        }
    }

    fun selectFilter(filter: SearchFilter) {
        if (_uiState.value.selectedFilter == filter) return
        _uiState.update { it.copy(selectedFilter = filter) }
        val q = _uiState.value.query.trim()
        if (q.isNotBlank() && _uiState.value.hasSearched) {
            executeSearch(q, filter, recordHistory = false)
        }
    }

    fun submitSearch(queryOverride: String? = null) {
        val q = (queryOverride ?: _uiState.value.query).trim()
        if (q.isBlank()) return
        _uiState.update { it.copy(query = q) }
        executeSearch(q, _uiState.value.selectedFilter, recordHistory = true)
    }

    private fun executeSearch(query: String, filter: SearchFilter, recordHistory: Boolean) {
        searchJob?.cancel()
        searchJob = viewModelScope.launch {
            _uiState.update {
                it.copy(
                    isSearching = true,
                    hasSearched = true,
                    errorMessage = null
                )
            }
            if (recordHistory) {
                libraryRepository.addSearchHistory(query)
            }
            musicRepository.search(query, filter)
                .onSuccess { res ->
                    _uiState.update {
                        it.copy(
                            isSearching = false,
                            results = res,
                            errorMessage = null
                        )
                    }
                }
                .onFailure { err ->
                    _uiState.update {
                        it.copy(
                            isSearching = false,
                            errorMessage = err.localizedMessage ?: "Search request failed."
                        )
                    }
                }
        }
    }

    fun loadMoreResults() {
        val token = _uiState.value.results.continuation ?: return
        if (_uiState.value.isLoadingMore) return
        viewModelScope.launch {
            _uiState.update { it.copy(isLoadingMore = true) }
            musicRepository.search(
                query = _uiState.value.query,
                filter = _uiState.value.selectedFilter,
                continuation = token
            ).onSuccess { next ->
                _uiState.update { state ->
                    state.copy(
                        isLoadingMore = false,
                        results = SearchResults(
                            songs = (state.results.songs + next.songs).distinctBy { it.id },
                            albums = (state.results.albums + next.albums).distinctBy { it.browseId },
                            artists = (state.results.artists + next.artists).distinctBy { it.browseId },
                            playlists = (state.results.playlists + next.playlists).distinctBy { it.browseId },
                            continuation = next.continuation
                        )
                    )
                }
            }.onFailure {
                _uiState.update { it.copy(isLoadingMore = false) }
            }
        }
    }

    fun removeHistoryItem(query: String) {
        viewModelScope.launch {
            libraryRepository.removeSearchHistoryItem(query)
        }
    }

    fun clearHistory() {
        viewModelScope.launch {
            libraryRepository.clearSearchHistory()
        }
    }

    class Factory(
        private val musicRepository: MusicRepository,
        private val libraryRepository: LibraryRepository
    ) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return SearchViewModel(musicRepository, libraryRepository) as T
        }
    }
}
