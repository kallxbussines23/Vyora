package com.vyorasound.app.presentation.navigation

import android.Manifest
import android.net.Uri
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.vyorasound.app.AppContainer
import com.vyorasound.app.domain.model.Album
import com.vyorasound.app.domain.model.Artist
import com.vyorasound.app.domain.model.MoodCategory
import com.vyorasound.app.domain.model.Playlist
import com.vyorasound.app.domain.model.Song
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import com.vyorasound.app.presentation.components.AddToPlaylistSheet
import com.vyorasound.app.presentation.components.FloatingGlassBottomBar
import com.vyorasound.app.presentation.components.MiniPlayer
import com.vyorasound.app.presentation.components.NexaTab
import com.vyorasound.app.presentation.components.YouTubeSignInDialog
import com.vyorasound.app.presentation.detail.DetailScreen
import com.vyorasound.app.presentation.detail.DetailViewModel
import com.vyorasound.app.presentation.explore.ExploreScreen
import com.vyorasound.app.presentation.explore.ExploreViewModel
import com.vyorasound.app.presentation.home.HomeScreen
import com.vyorasound.app.presentation.home.HomeViewModel
import com.vyorasound.app.presentation.library.LibraryScreen
import com.vyorasound.app.presentation.library.LibraryViewModel
import com.vyorasound.app.presentation.player.NowPlayingScreen
import com.vyorasound.app.presentation.search.SearchScreen
import com.vyorasound.app.presentation.search.SearchViewModel
import com.vyorasound.app.presentation.theme.NexaAmbientBackground
import com.vyorasound.app.presentation.theme.NexaColors
import kotlinx.coroutines.launch

object NexaRoutes {
    const val DETAIL = "detail/{type}/{id}?title={title}&params={params}"

    fun detailRoute(
        type: String,
        id: String,
        title: String? = null,
        params: String? = null
    ): String {
        val encId = Uri.encode(id)
        val encTitle = Uri.encode(title.orEmpty())
        val encParams = Uri.encode(params.orEmpty())
        return "detail/$type/$encId?title=$encTitle&params=$encParams"
    }
}

@Composable
fun NexaAppShell(container: AppContainer) {
    val navController = rememberNavController()
    val backStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = backStackEntry?.destination?.route

    val playerState by container.playerController.uiState.collectAsStateWithLifecycle()
    val savedPlaylists by container.libraryRepository.savedPlaylists.collectAsStateWithLifecycle(initialValue = emptyList())
    val likedSongs by container.libraryRepository.likedSongs.collectAsStateWithLifecycle(initialValue = emptyList())
    val isYouTubeSignedIn by container.youTubeSessionManager.isSignedIn.collectAsStateWithLifecycle()

    val scope = rememberCoroutineScope()
    var nowPlayingOpen by remember { mutableStateOf(false) }
    var songForPlaylistSheet by remember { mutableStateOf<Song?>(null) }
    var showYouTubeSignIn by remember { mutableStateOf(false) }
    var showYouTubeDisconnectConfirm by remember { mutableStateOf(false) }

    // Request notification permission on Android 13+ for foreground playback media controls
    val notificationPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { }

    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    val homeViewModel: HomeViewModel = viewModel(
        factory = HomeViewModel.Factory(container.musicRepository, container.libraryRepository)
    )
    val exploreViewModel: ExploreViewModel = viewModel(
        factory = ExploreViewModel.Factory(container.musicRepository, container.libraryRepository)
    )
    val searchViewModel: SearchViewModel = viewModel(
        factory = SearchViewModel.Factory(container.musicRepository, container.libraryRepository)
    )
    val libraryViewModel: LibraryViewModel = viewModel(
        factory = LibraryViewModel.Factory(container.libraryRepository)
    )

    val onPlaySong: (Song, List<Song>?) -> Unit = { song, queue ->
        container.playerController.playSong(song, queue)
    }
    val onToggleLike: (Song) -> Unit = { song ->
        scope.launch { container.libraryRepository.toggleLikeSong(song) }
    }
    val onOpenAlbum: (Album) -> Unit = { album ->
        navController.navigate(NexaRoutes.detailRoute("album", album.browseId, album.title))
    }
    val onOpenArtist: (Artist) -> Unit = { artist ->
        navController.navigate(NexaRoutes.detailRoute("artist", artist.browseId, artist.name))
    }
    val onOpenPlaylist: (Playlist) -> Unit = { playlist ->
        navController.navigate(NexaRoutes.detailRoute("playlist", playlist.browseId, playlist.title))
    }
    val onOpenMood: (MoodCategory) -> Unit = { mood ->
        navController.navigate(NexaRoutes.detailRoute("category", mood.browseId, mood.title, mood.params))
    }

    NexaAmbientBackground {
        Box(modifier = Modifier.fillMaxSize()) {
            NavHost(
                navController = navController,
                startDestination = NexaTab.HOME.route,
                modifier = Modifier.fillMaxSize()
            ) {
                composable(NexaTab.HOME.route) {
                    HomeScreen(
                        viewModel = homeViewModel,
                        currentSongId = playerState.currentSong?.id,
                        onPlaySong = onPlaySong,
                        onPlayNext = container.playerController::playNext,
                        onAddToQueue = container.playerController::addToQueue,
                        onToggleLike = onToggleLike,
                        onAddToPlaylist = { songForPlaylistSheet = it },
                        onOpenAlbum = onOpenAlbum,
                        onOpenArtist = onOpenArtist,
                        onOpenPlaylist = onOpenPlaylist,
                        onOpenMood = onOpenMood,
                        onOpenBrowseSection = { title, browseId, params ->
                            navController.navigate(NexaRoutes.detailRoute("category", browseId, title, params))
                        }
                    )
                }

                composable(NexaTab.EXPLORE.route) {
                    ExploreScreen(
                        viewModel = exploreViewModel,
                        currentSongId = playerState.currentSong?.id,
                        onPlaySong = onPlaySong,
                        onPlayNext = container.playerController::playNext,
                        onAddToQueue = container.playerController::addToQueue,
                        onToggleLike = onToggleLike,
                        onAddToPlaylist = { songForPlaylistSheet = it },
                        onOpenAlbum = onOpenAlbum,
                        onOpenArtist = onOpenArtist,
                        onOpenPlaylist = onOpenPlaylist,
                        onOpenMood = onOpenMood
                    )
                }

                composable(NexaTab.SEARCH.route) {
                    SearchScreen(
                        viewModel = searchViewModel,
                        currentSongId = playerState.currentSong?.id,
                        onPlaySong = onPlaySong,
                        onPlayNext = container.playerController::playNext,
                        onAddToQueue = container.playerController::addToQueue,
                        onToggleLike = onToggleLike,
                        onAddToPlaylist = { songForPlaylistSheet = it },
                        onOpenAlbum = onOpenAlbum,
                        onOpenArtist = onOpenArtist,
                        onOpenPlaylist = onOpenPlaylist
                    )
                }

                composable(NexaTab.LIBRARY.route) {
                    LibraryScreen(
                        viewModel = libraryViewModel,
                        currentSongId = playerState.currentSong?.id,
                        onPlaySong = onPlaySong,
                        onPlayNext = container.playerController::playNext,
                        onAddToQueue = container.playerController::addToQueue,
                        onToggleLike = onToggleLike,
                        onAddToPlaylist = { songForPlaylistSheet = it },
                        onOpenAlbum = onOpenAlbum,
                        onOpenArtist = onOpenArtist,
                        onOpenPlaylist = onOpenPlaylist,
                        onNavigateToSearch = {
                            navController.navigate(NexaTab.SEARCH.route) {
                                popUpTo(navController.graph.findStartDestination().id) { saveState = true }
                                launchSingleTop = true
                                restoreState = true
                            }
                        },
                        isYouTubeSignedIn = isYouTubeSignedIn,
                        onYouTubeAccountClick = {
                            if (isYouTubeSignedIn) {
                                showYouTubeDisconnectConfirm = true
                            } else {
                                showYouTubeSignIn = true
                            }
                        }
                    )
                }

                composable(
                    route = NexaRoutes.DETAIL,
                    arguments = listOf(
                        navArgument("type") { type = NavType.StringType },
                        navArgument("id") { type = NavType.StringType },
                        navArgument("title") {
                            type = NavType.StringType
                            nullable = true
                            defaultValue = null
                        },
                        navArgument("params") {
                            type = NavType.StringType
                            nullable = true
                            defaultValue = null
                        }
                    )
                ) { entry ->
                    val type = entry.arguments?.getString("type").orEmpty()
                    val id = entry.arguments?.getString("id").orEmpty()
                    val title = entry.arguments?.getString("title")?.takeIf { it.isNotBlank() }
                    val params = entry.arguments?.getString("params")?.takeIf { it.isNotBlank() }

                    val detailViewModel: DetailViewModel = viewModel(
                        key = "detail_${type}_${id}_${params.orEmpty()}",
                        factory = DetailViewModel.Factory(
                            type = type,
                            id = id,
                            titleHint = title,
                            params = params,
                            musicRepository = container.musicRepository,
                            libraryRepository = container.libraryRepository
                        )
                    )

                    DetailScreen(
                        viewModel = detailViewModel,
                        currentSongId = playerState.currentSong?.id,
                        onBack = { navController.popBackStack() },
                        onPlaySong = onPlaySong,
                        onPlayNext = container.playerController::playNext,
                        onAddToQueue = container.playerController::addToQueue,
                        onToggleLike = onToggleLike,
                        onAddToPlaylist = { songForPlaylistSheet = it },
                        onOpenAlbum = onOpenAlbum,
                        onOpenArtist = onOpenArtist,
                        onOpenPlaylist = onOpenPlaylist,
                        onOpenMood = onOpenMood
                    )
                }
            }

            // Floating Mini Player + Floating Glass Bottom Bar
            Column(
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .fillMaxWidth()
            ) {
                MiniPlayer(
                    playerState = playerState,
                    onOpenNowPlaying = { nowPlayingOpen = true },
                    onTogglePlayPause = container.playerController::togglePlayPause,
                    onSkipNext = container.playerController::skipToNext,
                    onRetry = container.playerController::retryCurrent,
                    modifier = Modifier.padding(horizontal = 16.dp)
                )

                FloatingGlassBottomBar(
                    currentRoute = currentRoute,
                    onTabSelected = { tab ->
                        navController.navigate(tab.route) {
                            popUpTo(navController.graph.findStartDestination().id) {
                                saveState = true
                            }
                            launchSingleTop = true
                            restoreState = true
                        }
                    }
                )
            }

            // Full-Screen Now Playing Overlay
            AnimatedVisibility(
                visible = nowPlayingOpen,
                enter = slideInVertically(initialOffsetY = { it }) + fadeIn(),
                exit = slideOutVertically(targetOffsetY = { it }) + fadeOut()
            ) {
                val isCurrentLiked = playerState.currentSong?.id?.let { id ->
                    likedSongs.any { it.id == id }
                } ?: false

                NowPlayingScreen(
                    playerState = playerState,
                    isLiked = isCurrentLiked,
                    onClose = { nowPlayingOpen = false },
                    onTogglePlayPause = container.playerController::togglePlayPause,
                    onSkipNext = container.playerController::skipToNext,
                    onSkipPrevious = container.playerController::skipToPrevious,
                    onSeekTo = container.playerController::seekTo,
                    onToggleShuffle = container.playerController::toggleShuffle,
                    onCycleRepeat = container.playerController::cycleRepeatMode,
                    onToggleLike = onToggleLike,
                    onAddToPlaylist = { songForPlaylistSheet = it },
                    onJumpToQueueIndex = container.playerController::jumpToQueueIndex,
                    onRemoveFromQueue = container.playerController::removeFromQueue,
                    onMoveQueueItem = container.playerController::moveQueueItem,
                    onOpenArtist = onOpenArtist,
                    onRetry = container.playerController::retryCurrent,
                    onSignInYouTube = { showYouTubeSignIn = true }
                )
            }

            songForPlaylistSheet?.let { song ->
                AddToPlaylistSheet(
                    song = song,
                    playlists = savedPlaylists,
                    onSelectPlaylist = { playlist ->
                        scope.launch {
                            container.libraryRepository.addSongToPlaylist(playlist.id, song)
                        }
                    },
                    onCreatePlaylist = { name ->
                        scope.launch {
                            container.libraryRepository.createPlaylist(name, initialSong = song)
                        }
                    },
                    onDismiss = { songForPlaylistSheet = null }
                )
            }

            if (showYouTubeSignIn) {
                YouTubeSignInDialog(
                    sessionManager = container.youTubeSessionManager,
                    onSignedIn = {
                        showYouTubeSignIn = false
                        container.playerController.retryCurrent()
                    },
                    onDismiss = { showYouTubeSignIn = false }
                )
            }

            if (showYouTubeDisconnectConfirm) {
                AlertDialog(
                    onDismissRequest = { showYouTubeDisconnectConfirm = false },
                    containerColor = NexaColors.SurfaceHigh,
                    title = {
                        Text("Akun YouTube Terhubung", color = NexaColors.TextPrimary)
                    },
                    text = {
                        Text(
                            text = "Sesi YouTube aktif untuk memutar musik saat jaringan membatasi mode anonim. Putuskan sesi jika ingin kembali ke mode tanpa login.",
                            color = NexaColors.TextSecondary
                        )
                    },
                    confirmButton = {
                        Button(
                            onClick = {
                                container.youTubeSessionManager.signOut()
                                showYouTubeDisconnectConfirm = false
                            },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = NexaColors.Primary,
                                contentColor = NexaColors.OnPrimary
                            )
                        ) {
                            Text("Putuskan")
                        }
                    },
                    dismissButton = {
                        TextButton(onClick = { showYouTubeDisconnectConfirm = false }) {
                            Text("Tutup", color = NexaColors.TextSecondary)
                        }
                    }
                )
            }
        }
    }
}
