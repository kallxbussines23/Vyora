package com.vyorasound.app.repository

import com.vyorasound.app.domain.model.PlaybackStream
import com.vyorasound.app.player.PlaybackDiagnostics
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

interface NoLoginFallbackResolver {
    suspend fun resolvePlayableStream(
        videoId: String,
        songTitle: String?,
        streamProber: StreamProber
    ): PlaybackStream?
}

object NoOpNoLoginFallbackResolver : NoLoginFallbackResolver {
    override suspend fun resolvePlayableStream(
        videoId: String,
        songTitle: String?,
        streamProber: StreamProber
    ): PlaybackStream? = null
}

class PublicApiNoLoginFallbackResolver(
    private val httpClient: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(4, TimeUnit.SECONDS)
        .readTimeout(6, TimeUnit.SECONDS)
        .followRedirects(true)
        .followSslRedirects(true)
        .build()
) : NoLoginFallbackResolver {

    private val curatedPipedInstances = listOf(
        "https://pipedapi.kavin.rocks",
        "https://pipedapi-libre.kavin.rocks",
        "https://api.piped.private.coffee",
        "https://pipedapi.r4fo.com",
        "https://pipedapi.darkness.services",
        "https://pipedapi.ducks.party"
    )

    private val curatedInvidiousInstances = listOf(
        "https://inv.nadeko.net",
        "https://invidious.nerdvpn.de",
        "https://invidious.perennialte.ch",
        "https://inv.tux.pizza",
        "https://invidious.jing.rocks",
        "https://iv.datura.network"
    )

    @Volatile
    private var cachedDynamicPiped: List<String> = emptyList()

    @Volatile
    private var cachedDynamicInvidious: List<String> = emptyList()

    @Volatile
    private var directoryFetchedAtMs: Long = 0L

    private val directoryTtlMs = 15 * 60 * 1000L

    private val fallbackUserAgent =
        "Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Mobile Safari/537.36"

    override suspend fun resolvePlayableStream(
        videoId: String,
        songTitle: String?,
        streamProber: StreamProber
    ): PlaybackStream? = withContext(Dispatchers.IO) {
        PlaybackDiagnostics.i(
            "NoLoginFallbackStart | title=\"${songTitle ?: "-"}\" | videoId=$videoId"
        )

        refreshDynamicInstanceDirectoriesIfNeeded()

        val pipedPool = (cachedDynamicPiped + curatedPipedInstances).distinct().take(10)
        val invidiousPool = (cachedDynamicInvidious + curatedInvidiousInstances).distinct().take(10)

        val winner = CompletableDeferred<PlaybackStream?>()
        coroutineScope {
            val jobs = buildList {
                pipedPool.forEach { baseUrl ->
                    add(
                        launch {
                            val candidates = fetchPipedCandidates(baseUrl, videoId)
                            for (candidate in candidates) {
                                if (winner.isCompleted) return@launch
                                val probe = streamProber.probe(candidate)
                                PlaybackDiagnostics.logStreamProbe(
                                    songTitle = songTitle,
                                    videoId = videoId,
                                    stream = candidate,
                                    httpStatus = probe.httpStatus,
                                    errorDetail = probe.errorDetail
                                )
                                if (probe.isPlayable) {
                                    winner.complete(candidate)
                                    return@launch
                                }
                            }
                        }
                    )
                }
                invidiousPool.forEach { baseUrl ->
                    add(
                        launch {
                            val candidates = fetchInvidiousCandidates(baseUrl, videoId)
                            for (candidate in candidates) {
                                if (winner.isCompleted) return@launch
                                val probe = streamProber.probe(candidate)
                                PlaybackDiagnostics.logStreamProbe(
                                    songTitle = songTitle,
                                    videoId = videoId,
                                    stream = candidate,
                                    httpStatus = probe.httpStatus,
                                    errorDetail = probe.errorDetail
                                )
                                if (probe.isPlayable) {
                                    winner.complete(candidate)
                                    return@launch
                                }
                            }
                        }
                    )
                }
            }

            // Wait until either one instance wins or all fail
            launch {
                jobs.forEach { it.join() }
                if (!winner.isCompleted) {
                    winner.complete(null)
                }
            }

            val resolved = winner.await()
            jobs.forEach { it.cancel() }
            if (resolved == null) {
                PlaybackDiagnostics.w(
                    "NoLoginFallbackExhausted | title=\"${songTitle ?: "-"}\" | videoId=$videoId | " +
                        "pipedChecked=${pipedPool.size} | invidiousChecked=${invidiousPool.size}"
                )
            }
            resolved
        }
    }

    private suspend fun refreshDynamicInstanceDirectoriesIfNeeded() {
        val now = System.currentTimeMillis()
        if (now - directoryFetchedAtMs < directoryTtlMs &&
            (cachedDynamicPiped.isNotEmpty() || cachedDynamicInvidious.isNotEmpty())
        ) {
            return
        }
        coroutineScope {
            val pipedDeferred = async { fetchPipedDirectory() }
            val invidiousDeferred = async { fetchInvidiousDirectory() }
            val piped = pipedDeferred.await()
            val invidious = invidiousDeferred.await()
            if (piped.isNotEmpty()) cachedDynamicPiped = piped
            if (invidious.isNotEmpty()) cachedDynamicInvidious = invidious
            directoryFetchedAtMs = System.currentTimeMillis()
            PlaybackDiagnostics.d(
                "NoLoginDirectoryRefresh | piped=${piped.size} | invidious=${invidious.size}"
            )
        }
    }

    private fun fetchPipedDirectory(): List<String> {
        return runCatching {
            val req = Request.Builder()
                .url("https://piped-instances.kavin.rocks/")
                .header("User-Agent", fallbackUserAgent)
                .get()
                .build()
            httpClient.newCall(req).execute().use { resp ->
                if (!resp.isSuccessful) return emptyList()
                val body = resp.body?.string() ?: return emptyList()
                val arr = JSONArray(body)
                buildList {
                    for (i in 0 until arr.length()) {
                        val apiUrl = arr.optJSONObject(i)?.optString("api_url")?.trim()
                        if (!apiUrl.isNullOrBlank() && apiUrl.startsWith("https://")) {
                            add(apiUrl.trimEnd('/'))
                        }
                    }
                }.take(8)
            }
        }.getOrDefault(emptyList())
    }

    private fun fetchInvidiousDirectory(): List<String> {
        return runCatching {
            val req = Request.Builder()
                .url("https://api.invidious.io/instances.json?sort_by=health")
                .header("User-Agent", fallbackUserAgent)
                .get()
                .build()
            httpClient.newCall(req).execute().use { resp ->
                if (!resp.isSuccessful) return emptyList()
                val body = resp.body?.string() ?: return emptyList()
                val arr = JSONArray(body)
                buildList {
                    for (i in 0 until arr.length()) {
                        val tuple = arr.optJSONArray(i) ?: continue
                        val meta = tuple.optJSONObject(1) ?: continue
                        val type = meta.optString("type")
                        val apiEnabled = meta.optBoolean("api", false)
                        val uri = meta.optString("uri").trim().trimEnd('/')
                        val down = meta.optJSONObject("monitor")?.optBoolean("down", false) ?: false
                        if (type == "https" && apiEnabled && !down && uri.startsWith("https://")) {
                            add(uri)
                        }
                    }
                }.take(8)
            }
        }.getOrDefault(emptyList())
    }

    internal fun fetchPipedCandidates(baseUrl: String, videoId: String): List<PlaybackStream> {
        return runCatching {
            val request = Request.Builder()
                .url("${baseUrl.trimEnd('/')}/streams/$videoId")
                .header("User-Agent", fallbackUserAgent)
                .header("Accept", "application/json")
                .get()
                .build()
            httpClient.newCall(request).execute().use { response ->
                val body = response.body?.string()
                PlaybackDiagnostics.d(
                    "PipedQuery | host=$baseUrl | videoId=$videoId | httpStatus=${response.code}"
                )
                if (!response.isSuccessful || body.isNullOrBlank()) return emptyList()
                parsePipedStreamsJson(baseUrl, videoId, body)
            }
        }.getOrElse { err ->
            PlaybackDiagnostics.d("PipedQueryErr | host=$baseUrl | err=${err.message}")
            emptyList()
        }
    }

    internal fun fetchInvidiousCandidates(baseUrl: String, videoId: String): List<PlaybackStream> {
        return runCatching {
            val request = Request.Builder()
                .url("${baseUrl.trimEnd('/')}/api/v1/videos/$videoId?local=true")
                .header("User-Agent", fallbackUserAgent)
                .header("Accept", "application/json")
                .get()
                .build()
            httpClient.newCall(request).execute().use { response ->
                val body = response.body?.string()
                PlaybackDiagnostics.d(
                    "InvidiousQuery | host=$baseUrl | videoId=$videoId | httpStatus=${response.code}"
                )
                if (!response.isSuccessful || body.isNullOrBlank()) return emptyList()
                parseInvidiousStreamsJson(baseUrl, videoId, body)
            }
        }.getOrElse { err ->
            PlaybackDiagnostics.d("InvidiousQueryErr | host=$baseUrl | err=${err.message}")
            emptyList()
        }
    }

    internal fun parsePipedStreamsJson(
        baseUrl: String,
        videoId: String,
        jsonString: String
    ): List<PlaybackStream> {
        val root = JSONObject(jsonString)
        val expiresAtMs = System.currentTimeMillis() + 50 * 60 * 1000L
        val audioArray = root.optJSONArray("audioStreams")
        val candidates = mutableListOf<PlaybackStream>()

        if (audioArray != null) {
            for (i in 0 until audioArray.length()) {
                val obj = audioArray.optJSONObject(i) ?: continue
                if (obj.optBoolean("videoOnly", false)) continue
                val rawUrl = obj.optString("url").takeIf { it.isNotBlank() } ?: continue
                val resolvedUrl = resolveAbsoluteUrl(baseUrl, rawUrl) ?: continue
                val mime = obj.optString("mimeType").substringBefore(";").trim()
                    .ifBlank { "audio/mp4" }
                if (!mime.startsWith("audio/", ignoreCase = true)) continue

                candidates.add(
                    PlaybackStream(
                        videoId = videoId,
                        streamUrl = resolvedUrl,
                        mimeType = mime,
                        bitrate = obj.optInt("bitrate", 0),
                        userAgent = fallbackUserAgent,
                        expiresAtMs = expiresAtMs,
                        isHls = false,
                        itag = obj.optInt("itag", 0),
                        codecs = obj.optString("codec").takeIf { it.isNotBlank() },
                        audioQuality = obj.optString("quality").takeIf { it.isNotBlank() },
                        contentLength = obj.optLong("contentLength", -1L).takeIf { it > 0L },
                        clientName = "PIPED($baseUrl)"
                    )
                )
            }
        }

        val ranked = candidates.sortedWith(
            compareByDescending<PlaybackStream> { it.mimeType.equals("audio/mp4", ignoreCase = true) }
                .thenByDescending { it.mimeType.equals("audio/webm", ignoreCase = true) }
                .thenByDescending { it.bitrate }
        ).toMutableList()

        root.optString("hls").takeIf { it.startsWith("https://") }?.let { hlsUrl ->
            ranked.add(
                PlaybackStream(
                    videoId = videoId,
                    streamUrl = hlsUrl,
                    mimeType = "application/x-mpegURL",
                    bitrate = 0,
                    userAgent = fallbackUserAgent,
                    expiresAtMs = expiresAtMs,
                    isHls = true,
                    audioQuality = "HLS",
                    clientName = "PIPED($baseUrl)"
                )
            )
        }

        return ranked
    }

    internal fun parseInvidiousStreamsJson(
        baseUrl: String,
        videoId: String,
        jsonString: String
    ): List<PlaybackStream> {
        val root = JSONObject(jsonString)
        val expiresAtMs = System.currentTimeMillis() + 50 * 60 * 1000L
        val adaptive = root.optJSONArray("adaptiveFormats")
        val formatStreams = root.optJSONArray("formatStreams")
        val cleanBase = baseUrl.trimEnd('/')
        val audioItems = mutableListOf<PlaybackStream>()

        if (adaptive != null) {
            for (i in 0 until adaptive.length()) {
                val obj = adaptive.optJSONObject(i) ?: continue
                val rawType = obj.optString("type")
                if (!rawType.startsWith("audio/", ignoreCase = true)) continue
                val baseMime = rawType.substringBefore(";").trim()
                val codecs = Regex("""codecs="([^"]+)"""").find(rawType)?.groupValues?.getOrNull(1)
                val itag = obj.optString("itag").toIntOrNull() ?: obj.optInt("itag", 0)
                val bitrate = obj.optString("bitrate").toIntOrNull() ?: obj.optInt("bitrate", 0)
                val contentLen = obj.optString("clen").toLongOrNull()
                val quality = obj.optString("audioQuality").takeIf { it.isNotBlank() }

                // Prefer proxied local=true endpoint first on Cloud/Emulator IPs, then direct URL
                if (itag > 0) {
                    audioItems.add(
                        PlaybackStream(
                            videoId = videoId,
                            streamUrl = "$cleanBase/latest_version?id=$videoId&itag=$itag&local=true",
                            mimeType = baseMime,
                            bitrate = bitrate,
                            userAgent = fallbackUserAgent,
                            expiresAtMs = expiresAtMs,
                            isHls = false,
                            itag = itag,
                            codecs = codecs,
                            audioQuality = quality,
                            contentLength = contentLen,
                            clientName = "INVIDIOUS_PROXY($cleanBase)"
                        )
                    )
                }

                val rawUrl = obj.optString("url").takeIf { it.isNotBlank() }
                val absUrl = rawUrl?.let { resolveAbsoluteUrl(cleanBase, it) }
                if (absUrl != null) {
                    audioItems.add(
                        PlaybackStream(
                            videoId = videoId,
                            streamUrl = absUrl,
                            mimeType = baseMime,
                            bitrate = bitrate,
                            userAgent = fallbackUserAgent,
                            expiresAtMs = expiresAtMs,
                            isHls = false,
                            itag = itag,
                            codecs = codecs,
                            audioQuality = quality,
                            contentLength = contentLen,
                            clientName = "INVIDIOUS($cleanBase)"
                        )
                    )
                }
            }
        }

        val ranked = audioItems.sortedWith(
            compareByDescending<PlaybackStream> { it.clientName.startsWith("INVIDIOUS_PROXY") }
                .thenByDescending { it.mimeType.equals("audio/mp4", ignoreCase = true) }
                .thenByDescending { it.bitrate }
        ).toMutableList()

        // Secondary fallback: muxed formatStreams (e.g. itag 18 audio+video MP4)
        if (formatStreams != null) {
            for (i in 0 until formatStreams.length()) {
                val obj = formatStreams.optJSONObject(i) ?: continue
                val itag = obj.optString("itag").toIntOrNull() ?: obj.optInt("itag", 0)
                val rawType = obj.optString("type").substringBefore(";").trim().ifBlank { "video/mp4" }
                if (itag > 0) {
                    ranked.add(
                        PlaybackStream(
                            videoId = videoId,
                            streamUrl = "$cleanBase/latest_version?id=$videoId&itag=$itag&local=true",
                            mimeType = rawType,
                            bitrate = 96000,
                            userAgent = fallbackUserAgent,
                            expiresAtMs = expiresAtMs,
                            isHls = false,
                            itag = itag,
                            audioQuality = "MUXED",
                            clientName = "INVIDIOUS_PROXY($cleanBase)"
                        )
                    )
                }
            }
        }

        root.optString("hlsUrl").takeIf { it.isNotBlank() }?.let { rawHls ->
            resolveAbsoluteUrl(cleanBase, rawHls)?.let { hlsUrl ->
                ranked.add(
                    PlaybackStream(
                        videoId = videoId,
                        streamUrl = hlsUrl,
                        mimeType = "application/x-mpegURL",
                        bitrate = 0,
                        userAgent = fallbackUserAgent,
                        expiresAtMs = expiresAtMs,
                        isHls = true,
                        audioQuality = "HLS",
                        clientName = "INVIDIOUS($cleanBase)"
                    )
                )
            }
        }

        return ranked
    }

    private fun resolveAbsoluteUrl(baseUrl: String, url: String): String? {
        val trimmed = url.trim()
        return when {
            trimmed.startsWith("https://") -> trimmed
            trimmed.startsWith("/") -> "${baseUrl.trimEnd('/')}$trimmed"
            else -> null
        }
    }
}
