package com.vyorasound.app.presentation.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.unit.dp

private val NexaDarkColorScheme = darkColorScheme(
    primary = NexaColors.Primary,
    onPrimary = NexaColors.OnPrimary,
    primaryContainer = NexaColors.Accent.copy(alpha = 0.25f),
    onPrimaryContainer = NexaColors.Primary,
    secondary = NexaColors.Accent,
    onSecondary = NexaColors.TextPrimary,
    background = NexaColors.Background,
    onBackground = NexaColors.TextPrimary,
    surface = NexaColors.Surface,
    onSurface = NexaColors.TextPrimary,
    surfaceVariant = NexaColors.SurfaceHigh,
    onSurfaceVariant = NexaColors.TextSecondary,
    outline = NexaColors.GlassBorder,
    error = NexaColors.Error,
    onError = NexaColors.TextPrimary
)

private val NexaShapes = Shapes(
    small = RoundedCornerShape(12.dp),
    medium = RoundedCornerShape(18.dp),
    large = RoundedCornerShape(24.dp),
    extraLarge = RoundedCornerShape(32.dp)
)

@Composable
fun NexaMusicTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = NexaDarkColorScheme,
        typography = NexaTypography,
        shapes = NexaShapes,
        content = content
    )
}
