package com.vyorasound.app.presentation.search

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.History
import androidx.compose.material.icons.rounded.NorthWest
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.SearchOff
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.vyorasound.app.domain.model.Album
import com.vyorasound.app.domain.model.Artist
import com.vyorasound.app.domain.model.IndonesianDiscovery
import com.vyorasound.app.domain.model.MediaShelfItem
import com.vyorasound.app.domain.model.Playlist
import com.vyorasound.app.domain.model.SearchFilter
import com.vyorasound.app.domain.model.SearchSuggestionItem
import com.vyorasound.app.domain.model.Song
import com.vyorasound.app.presentation.components.NexaArtwork
import com.vyorasound.app.presentation.components.SongRowItem
import com.vyorasound.app.presentation.theme.EmptyStateCard
import com.vyorasound.app.presentation.theme.ErrorStateCard
import com.vyorasound.app.presentation.theme.GlassBottomSpacer
import com.vyorasound.app.presentation.theme.GlassCard
import com.vyorasound.app.presentation.theme.GlassPill
import com.vyorasound.app.presentation.theme.NexaColors
import com.vyorasound.app.presentation.theme.ShimmerBox

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun SearchScreen(
    viewModel: SearchViewModel,
    currentSongId: String?,
    onPlaySong: (Song, List<Song>?) -> Unit,
    onPlayNext: (Song) -> Unit,
    onAddToQueue: (Song) -> Unit,
    onToggleLike: (Song) -> Unit,
    onAddToPlaylist: (Song) -> Unit,
    onOpenAlbum: (Album) -> Unit,
    onOpenArtist: (Artist) -> Unit,
    onOpenPlaylist: (Playlist) -> Unit
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val history by viewModel.searchHistory.collectAsStateWithLifecycle()
    val likedIds by viewModel.likedSongIds.collectAsStateWithLifecycle()
    val keyboard = LocalSoftwareKeyboardController.current

    val filterTabs = listOf(
        SearchFilter.SONGS,
        SearchFilter.ALBUMS,
        SearchFilter.ARTISTS,
        SearchFilter.PLAYLISTS,
        SearchFilter.ALL
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .testTag("search_screen")
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Column {
                Text(
                    text = "VYORA PENCARIAN",
                    style = MaterialTheme.typography.labelMedium,
                    color = NexaColors.Primary
                )
                Text(
                    text = "Cari Musik",
                    style = MaterialTheme.typography.displaySmall,
                    color = NexaColors.TextPrimary
                )
            }

            GlassCard(
                shape = RoundedCornerShape(22.dp),
                backgroundAlpha = 0.72f
            ) {
                OutlinedTextField(
                    value = uiState.query,
                    onValueChange = viewModel::onQueryChange,
                    placeholder = {
                        Text(
                            text = "Cari lagu, artis Indonesia atau dunia…",
                            color = NexaColors.TextSecondary,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    },
                    leadingIcon = {
                        Icon(
                            imageVector = Icons.Rounded.Search,
                            contentDescription = "Cari",
                            tint = NexaColors.Primary
                        )
                    },
                    trailingIcon = {
                        if (uiState.query.isNotEmpty()) {
                            IconButton(
                                onClick = { viewModel.onQueryChange("") },
                                modifier = Modifier.size(48.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.Close,
                                    contentDescription = "Hapus pencarian",
                                    tint = NexaColors.TextSecondary
                                )
                            }
                        }
                    },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                    keyboardActions = KeyboardActions(
                        onSearch = {
                            keyboard?.hide()
                            viewModel.submitSearch()
                        }
                    ),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = Color.Transparent,
                        unfocusedBorderColor = Color.Transparent,
                        focusedTextColor = NexaColors.TextPrimary,
                        unfocusedTextColor = NexaColors.TextPrimary,
                        cursorColor = NexaColors.Primary
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("search_input")
                )
            }
        }

        // Filter Tab
        LazyRow(
            contentPadding = PaddingValues(horizontal = 20.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            modifier = Modifier.padding(bottom = 8.dp)
        ) {
            items(filterTabs, key = { it.name }) { filter ->
                GlassPill(
                    selected = uiState.selectedFilter == filter,
                    onClick = {
                        keyboard?.hide()
                        viewModel.selectFilter(filter)
                    },
                    modifier = Modifier.testTag("search_tab_${filter.name.lowercase()}")
                ) {
                    Text(
                        text = filter.label,
                        style = MaterialTheme.typography.labelLarge,
                        color = if (uiState.selectedFilter == filter) NexaColors.Primary else NexaColors.TextSecondary
                    )
                }
            }
        }

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(horizontal = 20.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            when {
                // State awal -> Pencarian Populer Indonesia & Riwayat
                uiState.query.isBlank() -> {
                    item(key = "quick_chips") {
                        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            Text(
                                text = "Populer di Indonesia",
                                style = MaterialTheme.typography.titleLarge,
                                color = NexaColors.TextPrimary
                            )
                            FlowRow(
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                verticalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                IndonesianDiscovery.searchQuickChips.forEach { chipQuery ->
                                    GlassPill(
                                        selected = false,
                                        onClick = {
                                            keyboard?.hide()
                                            viewModel.submitSearch(chipQuery)
                                        }
                                    ) {
                                        Text(
                                            text = chipQuery,
                                            style = MaterialTheme.typography.labelLarge,
                                            color = NexaColors.TextPrimary
                                        )
                                    }
                                }
                            }
                        }
                    }

                    if (history.isEmpty()) {
                        item(key = "history_empty") {
                            EmptyStateCard(
                                icon = Icons.Rounded.Search,
                                title = "Temukan lagu favoritmu",
                                subtitle = "Cari lagu Indonesia seperti Hindia, Bernadya, Nadin Amizah, atau musik internasional favoritmu."
                            )
                        }
                    } else {
                        item(key = "history_header") {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(top = 6.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "Riwayat Pencarian",
                                    style = MaterialTheme.typography.titleLarge,
                                    color = NexaColors.TextPrimary
                                )
                                TextButton(onClick = viewModel::clearHistory) {
                                    Text("Hapus semua", color = NexaColors.Primary)
                                }
                            }
                        }
                        items(history, key = { "hist_$it" }) { item ->
                            GlassCard(
                                shape = RoundedCornerShape(16.dp),
                                backgroundAlpha = 0.4f,
                                onClick = {
                                    keyboard?.hide()
                                    viewModel.submitSearch(item)
                                }
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(horizontal = 14.dp, vertical = 6.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        imageVector = Icons.Rounded.History,
                                        contentDescription = null,
                                        tint = NexaColors.TextSecondary,
                                        modifier = Modifier.size(20.dp)
                                    )
                                    Spacer(modifier = Modifier.width(12.dp))
                                    Text(
                                        text = item,
                                        style = MaterialTheme.typography.bodyLarge,
                                        color = NexaColors.TextPrimary,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis,
                                        modifier = Modifier.weight(1f)
                                    )
                                    IconButton(
                                        onClick = { viewModel.removeHistoryItem(item) },
                                        modifier = Modifier.size(48.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Rounded.Close,
                                            contentDescription = "Hapus riwayat pencarian",
                                            tint = NexaColors.TextSecondary,
                                            modifier = Modifier.size(18.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }

                // Mengetik -> Saran Pencarian
                !uiState.hasSearched -> {
                    item(key = "search_prompt_row") {
                        GlassCard(
                            shape = RoundedCornerShape(16.dp),
                            backgroundAlpha = 0.55f,
                            onClick = {
                                keyboard?.hide()
                                viewModel.submitSearch()
                            }
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(14.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.Search,
                                    contentDescription = null,
                                    tint = NexaColors.Primary
                                )
                                Spacer(modifier = Modifier.width(12.dp))
                                Text(
                                    text = "Cari \"${uiState.query.trim()}\"",
                                    style = MaterialTheme.typography.titleMedium,
                                    color = NexaColors.Primary
                                )
                            }
                        }
                    }
                    items(
                        items = uiState.suggestions,
                        key = { item ->
                            when (item) {
                                is SearchSuggestionItem.QuerySuggestion -> "sug_q_${item.query}"
                                is SearchSuggestionItem.DirectMediaSuggestion -> "sug_m_${item.item.stableId}"
                            }
                        }
                    ) { suggestion ->
                        when (suggestion) {
                            is SearchSuggestionItem.QuerySuggestion -> {
                                GlassCard(
                                    shape = RoundedCornerShape(16.dp),
                                    backgroundAlpha = 0.35f,
                                    onClick = {
                                        keyboard?.hide()
                                        viewModel.submitSearch(suggestion.query)
                                    }
                                ) {
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(horizontal = 14.dp, vertical = 12.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Icon(
                                            imageVector = Icons.Rounded.Search,
                                            contentDescription = null,
                                            tint = NexaColors.TextSecondary,
                                            modifier = Modifier.size(20.dp)
                                        )
                                        Spacer(modifier = Modifier.width(12.dp))
                                        Text(
                                            text = suggestion.query,
                                            style = MaterialTheme.typography.bodyLarge,
                                            color = NexaColors.TextPrimary,
                                            modifier = Modifier.weight(1f)
                                        )
                                        Icon(
                                            imageVector = Icons.Rounded.NorthWest,
                                            contentDescription = "Isi pencarian",
                                            tint = NexaColors.TextSecondary,
                                            modifier = Modifier
                                                .size(20.dp)
                                                .clickable { viewModel.onQueryChange(suggestion.query) }
                                        )
                                    }
                                }
                            }
                            is SearchSuggestionItem.DirectMediaSuggestion -> {
                                when (val media = suggestion.item) {
                                    is MediaShelfItem.SongItem -> {
                                        SongRowItem(
                                            song = media.song,
                                            isPlaying = media.song.id == currentSongId,
                                            isLiked = media.song.id in likedIds,
                                            onClick = { onPlaySong(media.song, listOf(media.song)) },
                                            onToggleLike = { onToggleLike(media.song) },
                                            onPlayNext = { onPlayNext(media.song) },
                                            onAddToQueue = { onAddToQueue(media.song) },
                                            onAddToPlaylist = { onAddToPlaylist(media.song) }
                                        )
                                    }
                                    is MediaShelfItem.ArtistItem -> {
                                        EntitySearchRow(
                                            title = media.artist.name,
                                            subtitle = "Artis",
                                            thumbnailUrl = media.artist.thumbnailUrl,
                                            isRound = true,
                                            onClick = { onOpenArtist(media.artist) }
                                        )
                                    }
                                    is MediaShelfItem.AlbumItem -> {
                                        EntitySearchRow(
                                            title = media.album.title,
                                            subtitle = "Album • ${media.album.artist}",
                                            thumbnailUrl = media.album.thumbnailUrl,
                                            isRound = false,
                                            onClick = { onOpenAlbum(media.album) }
                                        )
                                    }
                                    is MediaShelfItem.PlaylistItem -> {
                                        EntitySearchRow(
                                            title = media.playlist.title,
                                            subtitle = "Playlist • ${media.playlist.author}",
                                            thumbnailUrl = media.playlist.thumbnailUrl,
                                            isRound = false,
                                            onClick = { onOpenPlaylist(media.playlist) }
                                        )
                                    }
                                    else -> Unit
                                }
                            }
                        }
                    }
                }

                // Skeleton loading
                uiState.isSearching -> {
                    items(6) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            ShimmerBox(modifier = Modifier.size(54.dp), shape = RoundedCornerShape(12.dp))
                            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                ShimmerBox(modifier = Modifier.width(200.dp).height(16.dp))
                                ShimmerBox(modifier = Modifier.width(130.dp).height(12.dp))
                            }
                        }
                    }
                }

                // Error
                uiState.errorMessage != null -> {
                    item(key = "search_error") {
                        ErrorStateCard(
                            message = uiState.errorMessage ?: "Pencarian gagal",
                            onRetry = { viewModel.submitSearch() }
                        )
                    }
                }

                // Kosong
                uiState.results.isEmpty -> {
                    item(key = "search_empty") {
                        EmptyStateCard(
                            icon = Icons.Rounded.SearchOff,
                            title = "Tidak ada hasil ditemukan",
                            subtitle = "Coba kata kunci lain atau ubah tab kategori di atas."
                        )
                    }
                }

                // Hasil pencarian langsung
                else -> {
                    val res = uiState.results
                    if (res.artists.isNotEmpty() &&
                        (uiState.selectedFilter == SearchFilter.ARTISTS || uiState.selectedFilter == SearchFilter.ALL)
                    ) {
                        items(res.artists, key = { "res_art_${it.browseId}" }) { artist ->
                            EntitySearchRow(
                                title = artist.name,
                                subtitle = artist.subtitle.ifBlank { "Artis" },
                                thumbnailUrl = artist.thumbnailUrl,
                                isRound = true,
                                onClick = { onOpenArtist(artist) }
                            )
                        }
                    }

                    if (res.songs.isNotEmpty() &&
                        (uiState.selectedFilter == SearchFilter.SONGS || uiState.selectedFilter == SearchFilter.ALL)
                    ) {
                        items(res.songs, key = { "res_song_${it.id}" }) { song ->
                            SongRowItem(
                                song = song,
                                isPlaying = song.id == currentSongId,
                                isLiked = song.id in likedIds,
                                onClick = { onPlaySong(song, res.songs) },
                                onToggleLike = { onToggleLike(song) },
                                onPlayNext = { onPlayNext(song) },
                                onAddToQueue = { onAddToQueue(song) },
                                onAddToPlaylist = { onAddToPlaylist(song) },
                                onOpenArtist = { id -> onOpenArtist(Artist(id = id, name = song.artist)) },
                                onOpenAlbum = { id -> onOpenAlbum(Album(id = id, title = song.album.orEmpty(), artist = song.artist)) }
                            )
                        }
                    }

                    if (res.albums.isNotEmpty() &&
                        (uiState.selectedFilter == SearchFilter.ALBUMS || uiState.selectedFilter == SearchFilter.ALL)
                    ) {
                        items(res.albums, key = { "res_alb_${it.browseId}" }) { album ->
                            EntitySearchRow(
                                title = album.title,
                                subtitle = listOfNotNull("Album", album.artist.takeIf { it.isNotBlank() }, album.year)
                                    .joinToString(" • "),
                                thumbnailUrl = album.thumbnailUrl,
                                isRound = false,
                                onClick = { onOpenAlbum(album) }
                            )
                        }
                    }

                    if (res.playlists.isNotEmpty() &&
                        (uiState.selectedFilter == SearchFilter.PLAYLISTS || uiState.selectedFilter == SearchFilter.ALL)
                    ) {
                        items(res.playlists, key = { "res_pl_${it.browseId}" }) { playlist ->
                            EntitySearchRow(
                                title = playlist.title,
                                subtitle = listOfNotNull("Playlist", playlist.author.takeIf { it.isNotBlank() }, playlist.trackCountText.takeIf { it.isNotBlank() })
                                    .joinToString(" • "),
                                thumbnailUrl = playlist.thumbnailUrl,
                                isRound = false,
                                onClick = { onOpenPlaylist(playlist) }
                            )
                        }
                    }

                    if (res.continuation != null) {
                        item(key = "search_load_more") {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 8.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Button(
                                    onClick = viewModel::loadMoreResults,
                                    enabled = !uiState.isLoadingMore,
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = NexaColors.GlassStrong,
                                        contentColor = NexaColors.Primary
                                    ),
                                    shape = RoundedCornerShape(50)
                                ) {
                                    if (uiState.isLoadingMore) {
                                        CircularProgressIndicator(
                                            color = NexaColors.Primary,
                                            strokeWidth = 2.dp,
                                            modifier = Modifier.size(18.dp)
                                        )
                                        Spacer(modifier = Modifier.width(8.dp))
                                    }
                                    Text("Muat hasil lainnya")
                                }
                            }
                        }
                    }
                }
            }

            item(key = "search_bottom_spacer") {
                GlassBottomSpacer()
            }
        }
    }
}

@Composable
private fun EntitySearchRow(
    title: String,
    subtitle: String,
    thumbnailUrl: String,
    isRound: Boolean,
    onClick: () -> Unit
) {
    GlassCard(
        shape = RoundedCornerShape(18.dp),
        backgroundAlpha = 0.42f,
        onClick = onClick
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            NexaArtwork(
                url = thumbnailUrl,
                contentDescription = title,
                shape = if (isRound) CircleShape else RoundedCornerShape(14.dp),
                modifier = Modifier.size(56.dp)
            )
            Spacer(modifier = Modifier.width(14.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleMedium,
                    color = NexaColors.TextPrimary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                if (subtitle.isNotBlank()) {
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = subtitle,
                        style = MaterialTheme.typography.bodySmall,
                        color = NexaColors.TextSecondary,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
        }
    }
}
