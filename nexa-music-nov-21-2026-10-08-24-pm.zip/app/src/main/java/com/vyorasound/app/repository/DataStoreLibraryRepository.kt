package com.vyorasound.app.repository

import com.vyorasound.app.database.VyoraDataStore
import com.vyorasound.app.domain.model.Album
import com.vyorasound.app.domain.model.Artist
import com.vyorasound.app.domain.model.Playlist
import com.vyorasound.app.domain.model.RepeatMode
import com.vyorasound.app.domain.model.Song
import com.vyorasound.app.domain.repository.LibraryRepository
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import java.util.UUID

class DataStoreLibraryRepository(
    private val dataStore: VyoraDataStore
) : LibraryRepository {

    override val likedSongs: Flow<List<Song>> = dataStore.likedSongsFlow
    override val recentlyPlayed: Flow<List<Song>> = dataStore.recentlyPlayedFlow
    override val savedAlbums: Flow<List<Album>> = dataStore.savedAlbumsFlow
    override val savedArtists: Flow<List<Artist>> = dataStore.savedArtistsFlow
    override val savedPlaylists: Flow<List<Playlist>> = dataStore.savedPlaylistsFlow
    override val searchHistory: Flow<List<String>> = dataStore.searchHistoryFlow
    override val shuffleEnabled: Flow<Boolean> = dataStore.shuffleEnabledFlow
    override val repeatMode: Flow<RepeatMode> = dataStore.repeatModeFlow

    override suspend fun toggleLikeSong(song: Song): Boolean {
        var nowLiked = false
        dataStore.updateLikedSongs { list ->
            val exists = list.any { it.id == song.id }
            if (exists) {
                nowLiked = false
                list.filterNot { it.id == song.id }
            } else {
                nowLiked = true
                listOf(song) + list
            }
        }
        return nowLiked
    }

    override suspend fun isSongLiked(songId: String): Boolean {
        return likedSongs.first().any { it.id == songId }
    }

    override suspend fun recordRecentlyPlayed(song: Song) {
        if (song.id.isBlank()) return
        dataStore.updateRecentlyPlayed { list ->
            listOf(song) + list.filterNot { it.id == song.id }
        }
    }

    override suspend fun toggleSaveAlbum(album: Album): Boolean {
        var nowSaved = false
        dataStore.updateSavedAlbums { list ->
            val exists = list.any { it.browseId == album.browseId }
            if (exists) {
                nowSaved = false
                list.filterNot { it.browseId == album.browseId }
            } else {
                nowSaved = true
                listOf(album) + list
            }
        }
        return nowSaved
    }

    override suspend fun toggleSaveArtist(artist: Artist): Boolean {
        var nowSaved = false
        dataStore.updateSavedArtists { list ->
            val exists = list.any { it.browseId == artist.browseId }
            if (exists) {
                nowSaved = false
                list.filterNot { it.browseId == artist.browseId }
            } else {
                nowSaved = true
                listOf(artist) + list
            }
        }
        return nowSaved
    }

    override suspend fun toggleSavePlaylist(playlist: Playlist): Boolean {
        var nowSaved = false
        dataStore.updateSavedPlaylists { list ->
            val exists = list.any { it.browseId == playlist.browseId }
            if (exists) {
                nowSaved = false
                list.filterNot { it.browseId == playlist.browseId }
            } else {
                nowSaved = true
                listOf(playlist) + list
            }
        }
        return nowSaved
    }

    override suspend fun createPlaylist(name: String, initialSong: Song?): Playlist {
        val cleanName = name.trim().ifBlank { "Playlist Saya" }
        val id = "local_${UUID.randomUUID()}"
        val songs = if (initialSong != null) listOf(initialSong) else emptyList()
        val created = Playlist(
            id = id,
            title = cleanName,
            author = "Kamu",
            trackCountText = "${songs.size} lagu",
            thumbnailUrl = initialSong?.thumbnailUrl.orEmpty(),
            browseId = id,
            isUserCreated = true,
            songs = songs
        )
        dataStore.updateSavedPlaylists { list -> listOf(created) + list }
        return created
    }

    override suspend fun addSongToPlaylist(playlistId: String, song: Song) {
        dataStore.updateSavedPlaylists { list ->
            list.map { pl ->
                if (pl.id == playlistId || pl.browseId == playlistId) {
                    val updatedSongs = if (pl.songs.any { it.id == song.id }) {
                        pl.songs
                    } else {
                        pl.songs + song
                    }
                    pl.copy(
                        songs = updatedSongs,
                        trackCountText = "${updatedSongs.size} lagu",
                        thumbnailUrl = pl.thumbnailUrl.ifBlank { song.thumbnailUrl }
                    )
                } else {
                    pl
                }
            }
        }
    }

    override suspend fun removeSongFromPlaylist(playlistId: String, songId: String) {
        dataStore.updateSavedPlaylists { list ->
            list.map { pl ->
                if (pl.id == playlistId || pl.browseId == playlistId) {
                    val updatedSongs = pl.songs.filterNot { it.id == songId }
                    pl.copy(
                        songs = updatedSongs,
                        trackCountText = "${updatedSongs.size} lagu"
                    )
                } else {
                    pl
                }
            }
        }
    }

    override suspend fun deletePlaylist(playlistId: String) {
        dataStore.updateSavedPlaylists { list ->
            list.filterNot { it.id == playlistId || it.browseId == playlistId }
        }
    }

    override suspend fun addSearchHistory(query: String) {
        val trimmed = query.trim()
        if (trimmed.isBlank()) return
        dataStore.updateSearchHistory { history ->
            listOf(trimmed) + history.filterNot { it.equals(trimmed, ignoreCase = true) }
        }
    }

    override suspend fun removeSearchHistoryItem(query: String) {
        dataStore.updateSearchHistory { history ->
            history.filterNot { it == query }
        }
    }

    override suspend fun clearSearchHistory() {
        dataStore.updateSearchHistory { emptyList() }
    }

    override suspend fun setShuffleEnabled(enabled: Boolean) {
        dataStore.setShuffleEnabled(enabled)
    }

    override suspend fun setRepeatMode(mode: RepeatMode) {
        dataStore.setRepeatMode(mode)
    }
}
