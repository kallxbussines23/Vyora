package com.vyorasound.app.utils

object ImageUrlUtils {
    private val googleUserContentSizeRegex = Regex("""=w\d+-h\d+[^&\s]*""")
    private val yt3AvatarSizeRegex = Regex("""=s\d+[^&\s]*""")

    fun enhanceThumbnailUrl(url: String?, targetSize: Int = 544): String {
        if (url.isNullOrBlank()) return ""
        val normalized = if (url.startsWith("//")) "https:$url" else url
        return when {
            normalized.contains("lh3.googleusercontent.com") -> {
                if (googleUserContentSizeRegex.containsMatchIn(normalized)) {
                    normalized.replace(
                        googleUserContentSizeRegex,
                        "=w$targetSize-h$targetSize-l90-rj"
                    )
                } else {
                    normalized
                }
            }
            normalized.contains("yt3.ggpht.com") || normalized.contains("yt3.googleusercontent.com") -> {
                if (yt3AvatarSizeRegex.containsMatchIn(normalized)) {
                    normalized.replace(yt3AvatarSizeRegex, "=s$targetSize-c-k-c0x00ffffff-no-rj")
                } else {
                    normalized
                }
            }
            else -> normalized
        }
    }
}
