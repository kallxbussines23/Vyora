package com.vyorasound.app.presentation.home

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.vyorasound.app.R
import com.vyorasound.app.domain.model.Album
import com.vyorasound.app.domain.model.Artist
import com.vyorasound.app.domain.model.IndonesianDiscovery
import com.vyorasound.app.domain.model.MediaShelfItem
import com.vyorasound.app.domain.model.MoodCategory
import com.vyorasound.app.domain.model.Playlist
import com.vyorasound.app.domain.model.Song
import com.vyorasound.app.presentation.components.MoodCategoryCard
import com.vyorasound.app.presentation.components.NexaArtwork
import com.vyorasound.app.presentation.components.SectionHeader
import com.vyorasound.app.presentation.components.ShelfMediaCard
import com.vyorasound.app.presentation.components.SongRowItem
import com.vyorasound.app.presentation.theme.EmptyStateCard
import com.vyorasound.app.presentation.theme.ErrorStateCard
import com.vyorasound.app.presentation.theme.GlassBottomSpacer
import com.vyorasound.app.presentation.theme.GlassCard
import com.vyorasound.app.presentation.theme.HomeFeedSkeleton
import com.vyorasound.app.presentation.theme.NexaColors
import com.vyorasound.app.utils.TimeUtils

@Composable
fun HomeScreen(
    viewModel: HomeViewModel,
    currentSongId: String?,
    onPlaySong: (Song, List<Song>?) -> Unit,
    onPlayNext: (Song) -> Unit,
    onAddToQueue: (Song) -> Unit,
    onToggleLike: (Song) -> Unit,
    onAddToPlaylist: (Song) -> Unit,
    onOpenAlbum: (Album) -> Unit,
    onOpenArtist: (Artist) -> Unit,
    onOpenPlaylist: (Playlist) -> Unit,
    onOpenMood: (MoodCategory) -> Unit,
    onOpenBrowseSection: (String, String, String?) -> Unit
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val recentlyPlayed by viewModel.recentlyPlayed.collectAsStateWithLifecycle()
    val likedIds by viewModel.likedSongIds.collectAsStateWithLifecycle()
    val greeting = remember { TimeUtils.getGreeting() }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .testTag("home_screen"),
        contentPadding = PaddingValues(top = 12.dp, bottom = 16.dp),
        verticalArrangement = Arrangement.spacedBy(24.dp)
    ) {
        // Greeting & VYORA Hero Header
        item(key = "home_header") {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "VYORA",
                            style = MaterialTheme.typography.labelMedium,
                            color = NexaColors.Primary
                        )
                        Text(
                            text = greeting,
                            style = MaterialTheme.typography.displaySmall,
                            color = NexaColors.TextPrimary
                        )
                    }
                    IconButton(
                        onClick = { viewModel.loadHome(isRefresh = true) },
                        modifier = Modifier
                            .size(48.dp)
                            .clip(CircleShape)
                            .background(NexaColors.Glass)
                    ) {
                        if (uiState.isRefreshing) {
                            CircularProgressIndicator(
                                color = NexaColors.Primary,
                                strokeWidth = 2.dp,
                                modifier = Modifier.size(20.dp)
                            )
                        } else {
                            Icon(
                                imageVector = Icons.Rounded.Refresh,
                                contentDescription = "Muat ulang Beranda",
                                tint = NexaColors.TextPrimary
                            )
                        }
                    }
                }

                // Ambient Hero Banner / Quick Resume
                GlassCard(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(24.dp),
                    backgroundAlpha = 0.55f,
                    onClick = {
                        val resumeTarget = recentlyPlayed.firstOrNull()
                        if (resumeTarget != null) {
                            onPlaySong(resumeTarget, recentlyPlayed)
                        }
                    }
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(118.dp)
                    ) {
                        Image(
                            painter = painterResource(R.drawable.img_vyora_ambient_hero),
                            contentDescription = "Latar gelombang audio VYORA",
                            contentScale = ContentScale.Crop,
                            modifier = Modifier
                                .fillMaxSize()
                                .alpha(0.5f)
                        )
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .background(
                                    Brush.horizontalGradient(
                                        listOf(
                                            NexaColors.Background.copy(alpha = 0.88f),
                                            NexaColors.Background.copy(alpha = 0.35f)
                                        )
                                    )
                                )
                        )
                        Row(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(16.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            val quickSong = recentlyPlayed.firstOrNull()
                            if (quickSong != null) {
                                NexaArtwork(
                                    url = quickSong.thumbnailUrl,
                                    contentDescription = quickSong.title,
                                    shape = RoundedCornerShape(16.dp),
                                    modifier = Modifier.size(72.dp)
                                )
                                Spacer(modifier = Modifier.width(14.dp))
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = "LANJUTKAN MENDENGARKAN",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = NexaColors.Primary
                                    )
                                    Text(
                                        text = quickSong.title,
                                        style = MaterialTheme.typography.titleLarge,
                                        color = NexaColors.TextPrimary,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    Text(
                                        text = quickSong.artist,
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = NexaColors.TextSecondary,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                                Box(
                                    modifier = Modifier
                                        .size(44.dp)
                                        .clip(CircleShape)
                                        .background(NexaColors.Primary),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Rounded.PlayArrow,
                                        contentDescription = "Putar ulang",
                                        tint = NexaColors.OnPrimary,
                                        modifier = Modifier.size(26.dp)
                                    )
                                }
                            } else {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = "MUSIK INDONESIA & DUNIA",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = NexaColors.Primary
                                    )
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        text = "Suara Tanpa Batas di VYORA",
                                        style = MaterialTheme.typography.titleLarge,
                                        color = NexaColors.TextPrimary
                                    )
                                    Text(
                                        text = "Pilih lagu favoritmu untuk mulai mendengarkan sekarang",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = NexaColors.TextSecondary
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // Kategori Musik Indonesia Cepat
        item(key = "home_indo_categories") {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                SectionHeader(
                    title = "Nuansa Musik Indonesia",
                    subtitle = "Jelajahi Genre"
                )
                LazyRow(
                    contentPadding = PaddingValues(horizontal = 20.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(IndonesianDiscovery.categories, key = { "home_cat_${it.title}" }) { category ->
                        MoodCategoryCard(
                            mood = category,
                            onClick = { onOpenMood(category) },
                            modifier = Modifier.width(172.dp)
                        )
                    }
                }
            }
        }

        // Baru Diputar
        if (recentlyPlayed.isNotEmpty()) {
            item(key = "recently_played_section") {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    SectionHeader(
                        title = "Baru Diputar",
                        subtitle = "Riwayat Kamu"
                    )
                    LazyRow(
                        contentPadding = PaddingValues(horizontal = 20.dp),
                        horizontalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        items(recentlyPlayed.take(15), key = { "recent_${it.id}" }) { song ->
                            ShelfMediaCard(
                                item = MediaShelfItem.SongItem(song),
                                onSongClick = { onPlaySong(song, recentlyPlayed) },
                                onAlbumClick = onOpenAlbum,
                                onArtistClick = onOpenArtist,
                                onPlaylistClick = onOpenPlaylist,
                                onMoodClick = onOpenMood
                            )
                        }
                    }
                }
            }
        }

        // Loading / Error / Empty / Live Sections
        when {
            uiState.isLoading -> {
                item(key = "home_skeleton") {
                    HomeFeedSkeleton()
                }
            }

            uiState.errorMessage != null && uiState.sections.isEmpty() -> {
                item(key = "home_error") {
                    ErrorStateCard(
                        message = uiState.errorMessage ?: "Gagal terhubung ke YouTube Music.",
                        onRetry = { viewModel.loadHome(isRefresh = true) }
                    )
                }
            }

            uiState.sections.isEmpty() -> {
                item(key = "home_empty") {
                    EmptyStateCard(
                        icon = Icons.Rounded.MusicNote,
                        title = "Belum ada daftar musik",
                        subtitle = "Periksa koneksi internet kamu dan ketuk muat ulang untuk mengambil lagu terbaru.",
                        actionLabel = "Muat Ulang",
                        onAction = { viewModel.loadHome(isRefresh = true) }
                    )
                }
            }

            else -> {
                itemsIndexed(
                    items = uiState.sections,
                    key = { index, section -> "home_sec_${index}_${section.title}" }
                ) { _, section ->
                    val songsInSection = remember(section) {
                        section.items.filterIsInstance<MediaShelfItem.SongItem>().map { it.song }
                    }
                    val isSongOnlyList = remember(section) {
                        songsInSection.size in 3..5 && songsInSection.size == section.items.size
                    }

                    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        SectionHeader(
                            title = section.title,
                            subtitle = section.subtitle,
                            actionLabel = if (!section.moreBrowseId.isNullOrBlank()) "Lihat semua" else null,
                            onActionClick = section.moreBrowseId?.let { browseId ->
                                { onOpenBrowseSection(section.title, browseId, section.moreParams) }
                            }
                        )

                        if (isSongOnlyList) {
                            Column(
                                modifier = Modifier.padding(horizontal = 20.dp),
                                verticalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                songsInSection.forEach { song ->
                                    SongRowItem(
                                        song = song,
                                        isPlaying = song.id == currentSongId,
                                        isLiked = song.id in likedIds,
                                        onClick = { onPlaySong(song, songsInSection) },
                                        onToggleLike = { onToggleLike(song) },
                                        onPlayNext = { onPlayNext(song) },
                                        onAddToQueue = { onAddToQueue(song) },
                                        onAddToPlaylist = { onAddToPlaylist(song) },
                                        onOpenArtist = { id -> onOpenArtist(Artist(id = id, name = song.artist)) },
                                        onOpenAlbum = { id -> onOpenAlbum(Album(id = id, title = song.album.orEmpty(), artist = song.artist)) }
                                    )
                                }
                            }
                        } else {
                            LazyRow(
                                contentPadding = PaddingValues(horizontal = 20.dp),
                                horizontalArrangement = Arrangement.spacedBy(14.dp)
                            ) {
                                items(
                                    items = section.items,
                                    key = { item -> "${section.title}_${item.stableId}" }
                                ) { item ->
                                    ShelfMediaCard(
                                        item = item,
                                        onSongClick = { song ->
                                            onPlaySong(song, songsInSection.ifEmpty { listOf(song) })
                                        },
                                        onAlbumClick = onOpenAlbum,
                                        onArtistClick = onOpenArtist,
                                        onPlaylistClick = onOpenPlaylist,
                                        onMoodClick = onOpenMood
                                    )
                                }
                            }
                        }
                    }
                }

                if (uiState.continuation != null) {
                    item(key = "home_load_more") {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 20.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Button(
                                onClick = { viewModel.loadMore() },
                                enabled = !uiState.isLoadingMore,
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = NexaColors.GlassStrong,
                                    contentColor = NexaColors.Primary
                                ),
                                shape = RoundedCornerShape(50)
                            ) {
                                if (uiState.isLoadingMore) {
                                    CircularProgressIndicator(
                                        color = NexaColors.Primary,
                                        strokeWidth = 2.dp,
                                        modifier = Modifier.size(18.dp)
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                }
                                Text("Muat rekomendasi lainnya")
                            }
                        }
                    }
                }
            }
        }

        item(key = "home_bottom_spacer") {
            GlassBottomSpacer()
        }
    }
}
