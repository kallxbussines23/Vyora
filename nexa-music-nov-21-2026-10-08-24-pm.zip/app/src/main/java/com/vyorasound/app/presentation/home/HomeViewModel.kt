package com.vyorasound.app.presentation.home

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.vyorasound.app.domain.model.Artist
import com.vyorasound.app.domain.model.HomeSection
import com.vyorasound.app.domain.model.IndonesianDiscovery
import com.vyorasound.app.domain.model.MediaShelfItem
import com.vyorasound.app.domain.model.SearchFilter
import com.vyorasound.app.domain.model.Song
import com.vyorasound.app.domain.repository.LibraryRepository
import com.vyorasound.app.domain.repository.MusicRepository
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class HomeUiState(
    val isLoading: Boolean = true,
    val isRefreshing: Boolean = false,
    val isLoadingMore: Boolean = false,
    val sections: List<HomeSection> = emptyList(),
    val continuation: String? = null,
    val errorMessage: String? = null
)

class HomeViewModel(
    private val musicRepository: MusicRepository,
    private val libraryRepository: LibraryRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow(HomeUiState())
    val uiState: StateFlow<HomeUiState> = _uiState.asStateFlow()

    val recentlyPlayed: StateFlow<List<Song>> = libraryRepository.recentlyPlayed
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    val likedSongIds: StateFlow<Set<String>> = MutableStateFlow<Set<String>>(emptySet()).also { flow ->
        viewModelScope.launch {
            libraryRepository.likedSongs.collect { songs ->
                flow.value = songs.map { it.id }.toSet()
            }
        }
    }

    init {
        loadHome(isRefresh = false)
    }

    fun loadHome(isRefresh: Boolean = true) {
        viewModelScope.launch {
            _uiState.update {
                it.copy(
                    isLoading = !isRefresh && it.sections.isEmpty(),
                    isRefreshing = isRefresh,
                    errorMessage = null
                )
            }

            try {
                coroutineScope {
                    val recentSeed = libraryRepository.recentlyPlayed.first().firstOrNull()
                    val recQuery = if (recentSeed != null) {
                        "${recentSeed.artist} lagu indonesia populer"
                    } else {
                        "Tulus Hindia Bernadya Mahalini lagu populer"
                    }

                    val homeDeferred = async { musicRepository.getHomeFeed() }
                    val exploreDeferred = async { musicRepository.getExploreFeed() }
                    val recDeferred = async { musicRepository.search(recQuery, SearchFilter.SONGS) }
                    val hitsDeferred = async { musicRepository.search("Hits Pop Indonesia Terpopuler", SearchFilter.SONGS) }
                    val viralDeferred = async { musicRepository.search("Lagu Viral Indonesia Terbaru", SearchFilter.SONGS) }
                    val begadangDeferred = async { musicRepository.search("Pamungkas Fourtwnty Nadin Amizah santai malam", SearchFilter.SONGS) }
                    val galauDeferred = async { musicRepository.search("Lagu Galau Indonesia Bernadya Mahalini Juicy Luicy", SearchFilter.SONGS) }
                    val indieDeferred = async { musicRepository.search("Indie Indonesia Hindia Sal Priadi Fiersa Besari Feby Putri", SearchFilter.SONGS) }
                    val throwbackDeferred = async { musicRepository.search("Dewa 19 Sheila On 7 NOAH lagu nostalgia indonesia", SearchFilter.SONGS) }
                    val newReleaseDeferred = async { musicRepository.search("Rilisan Terbaru Album Indonesia", SearchFilter.ALBUMS) }

                    // Fetch prioritized Indonesian artists dynamically from InnerTube
                    val artistQueries = IndonesianDiscovery.featuredArtistsQueries.shuffled().take(8)
                    val artistsDeferred = artistQueries.map { artistName ->
                        async {
                            musicRepository.search(artistName, SearchFilter.ARTISTS)
                                .getOrNull()
                                ?.artists
                                ?.firstOrNull()
                        }
                    }

                    val homeResult = homeDeferred.await()
                    val exploreResult = exploreDeferred.await()
                    val explore = exploreResult.getOrNull()
                    val homeFeed = homeResult.getOrNull()

                    val recSongs = recDeferred.await().getOrNull()?.songs.orEmpty()
                    val hitsSongs = hitsDeferred.await().getOrNull()?.songs.orEmpty()
                    val viralSongs = viralDeferred.await().getOrNull()?.songs.orEmpty()
                    val begadangSongs = begadangDeferred.await().getOrNull()?.songs.orEmpty()
                    val galauSongs = galauDeferred.await().getOrNull()?.songs.orEmpty()
                    val indieSongs = indieDeferred.await().getOrNull()?.songs.orEmpty()
                    val throwbackSongs = throwbackDeferred.await().getOrNull()?.songs.orEmpty()
                    val newAlbums = newReleaseDeferred.await().getOrNull()?.albums.orEmpty()
                    val featuredArtists: List<Artist> = artistsDeferred.awaitAll().filterNotNull().distinctBy { it.browseId }

                    val builtSections = mutableListOf<HomeSection>()

                    // 1. Rekomendasi Untukmu
                    val homeQuickSongs = homeFeed?.sections
                        ?.flatMap { it.items }
                        ?.filterIsInstance<MediaShelfItem.SongItem>()
                        ?.map { it.song }
                        .orEmpty()
                    val recommendedPool = (recSongs + homeQuickSongs).distinctBy { it.id }.take(15)
                    if (recommendedPool.isNotEmpty()) {
                        builtSections.add(
                            HomeSection(
                                title = "Rekomendasi Untukmu",
                                subtitle = "Pilihan Personal VYORA",
                                items = recommendedPool.map { MediaShelfItem.SongItem(it) }
                            )
                        )
                    }

                    // 2. Hits Indonesia
                    val hitsPool = (hitsSongs + explore?.chartSongs.orEmpty()).distinctBy { it.id }.take(15)
                    if (hitsPool.isNotEmpty()) {
                        builtSections.add(
                            HomeSection(
                                title = "Hits Indonesia",
                                subtitle = "Tangga Lagu Nusantara",
                                items = hitsPool.map { MediaShelfItem.SongItem(it) },
                                moreBrowseId = IndonesianDiscovery.buildCategoryBrowseId("Pop Indonesia Hits")
                            )
                        )
                    }

                    // 3. Viral di Indonesia
                    val viralPool = (explore?.trendingSongs.orEmpty() + viralSongs).distinctBy { it.id }.take(15)
                    if (viralPool.isNotEmpty()) {
                        builtSections.add(
                            HomeSection(
                                title = "Viral di Indonesia",
                                subtitle = "Sedang Ramai Diputar",
                                items = viralPool.map { MediaShelfItem.SongItem(it) },
                                moreBrowseId = IndonesianDiscovery.buildCategoryBrowseId("Lagu Viral Indonesia Terbaru")
                            )
                        )
                    }

                    // 4. Teman Begadang
                    if (begadangSongs.isNotEmpty()) {
                        builtSections.add(
                            HomeSection(
                                title = "Teman Begadang",
                                subtitle = "Malam Tenang & Syahdu",
                                items = begadangSongs.take(15).map { MediaShelfItem.SongItem(it) }
                            )
                        )
                    }

                    // 5. Lagu Galau Pilihan
                    if (galauSongs.isNotEmpty()) {
                        builtSections.add(
                            HomeSection(
                                title = "Lagu Galau Pilihan",
                                subtitle = "Bernadya, Mahalini, Juicy Luicy",
                                items = galauSongs.take(15).map { MediaShelfItem.SongItem(it) },
                                moreBrowseId = IndonesianDiscovery.buildCategoryBrowseId("Lagu Galau Indonesia")
                            )
                        )
                    }

                    // 6. Indie Indonesia
                    if (indieSongs.isNotEmpty()) {
                        builtSections.add(
                            HomeSection(
                                title = "Indie Indonesia",
                                subtitle = "Hindia, Nadin Amizah, Fourtwnty",
                                items = indieSongs.take(15).map { MediaShelfItem.SongItem(it) },
                                moreBrowseId = IndonesianDiscovery.buildCategoryBrowseId("Indie Indonesia")
                            )
                        )
                    }

                    // 7. Throwback Indonesia
                    if (throwbackSongs.isNotEmpty()) {
                        builtSections.add(
                            HomeSection(
                                title = "Throwback Indonesia",
                                subtitle = "Dewa 19, Sheila On 7, NOAH",
                                items = throwbackSongs.take(15).map { MediaShelfItem.SongItem(it) },
                                moreBrowseId = IndonesianDiscovery.buildCategoryBrowseId("Lagu Nostalgia Indonesia")
                            )
                        )
                    }

                    // 8. Rilisan Terbaru
                    val releasesPool = (newAlbums + explore?.newReleases.orEmpty()).distinctBy { it.browseId }.take(15)
                    if (releasesPool.isNotEmpty()) {
                        builtSections.add(
                            HomeSection(
                                title = "Rilisan Terbaru",
                                subtitle = "Album & Single Terkini",
                                items = releasesPool.map { MediaShelfItem.AlbumItem(it) }
                            )
                        )
                    }

                    // Artis Indonesia Populer
                    if (featuredArtists.isNotEmpty()) {
                        builtSections.add(
                            HomeSection(
                                title = "Artis Indonesia Populer",
                                subtitle = "Sorotan Musisi Tanah Air",
                                items = featuredArtists.map { MediaShelfItem.ArtistItem(it) }
                            )
                        )
                    }

                    // Tambahan feed asli InnerTube Home jika tersedia
                    homeFeed?.sections?.forEach { sec ->
                        if (builtSections.none { it.title.equals(sec.title, ignoreCase = true) }) {
                            builtSections.add(sec)
                        }
                    }

                    if (builtSections.isEmpty() && homeResult.isFailure) {
                        val err = homeResult.exceptionOrNull()
                        _uiState.update {
                            it.copy(
                                isLoading = false,
                                isRefreshing = false,
                                errorMessage = err?.localizedMessage ?: "Gagal memuat beranda musik."
                            )
                        }
                    } else {
                        _uiState.update {
                            it.copy(
                                isLoading = false,
                                isRefreshing = false,
                                sections = builtSections,
                                continuation = homeFeed?.continuation,
                                errorMessage = null
                            )
                        }
                    }
                }
            } catch (e: Exception) {
                _uiState.update {
                    it.copy(
                        isLoading = false,
                        isRefreshing = false,
                        errorMessage = e.localizedMessage ?: "Terjadi kesalahan jaringan."
                    )
                }
            }
        }
    }

    fun loadMore() {
        val token = _uiState.value.continuation ?: return
        if (_uiState.value.isLoadingMore) return
        viewModelScope.launch {
            _uiState.update { it.copy(isLoadingMore = true) }
            musicRepository.getHomeFeed(continuation = token)
                .onSuccess { nextFeed ->
                    _uiState.update { state ->
                        state.copy(
                            isLoadingMore = false,
                            sections = state.sections + nextFeed.sections,
                            continuation = nextFeed.continuation
                        )
                    }
                }
                .onFailure {
                    _uiState.update { it.copy(isLoadingMore = false) }
                }
        }
    }

    class Factory(
        private val musicRepository: MusicRepository,
        private val libraryRepository: LibraryRepository
    ) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return HomeViewModel(musicRepository, libraryRepository) as T
        }
    }
}
