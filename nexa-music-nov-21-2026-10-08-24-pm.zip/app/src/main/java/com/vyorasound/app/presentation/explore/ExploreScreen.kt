package com.vyorasound.app.presentation.explore

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Explore
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.vyorasound.app.domain.model.Album
import com.vyorasound.app.domain.model.Artist
import com.vyorasound.app.domain.model.MediaShelfItem
import com.vyorasound.app.domain.model.MoodCategory
import com.vyorasound.app.domain.model.Playlist
import com.vyorasound.app.domain.model.Song
import com.vyorasound.app.presentation.components.MoodCategoryCard
import com.vyorasound.app.presentation.components.SectionHeader
import com.vyorasound.app.presentation.components.ShelfMediaCard
import com.vyorasound.app.presentation.components.SongRowItem
import com.vyorasound.app.presentation.theme.EmptyStateCard
import com.vyorasound.app.presentation.theme.ErrorStateCard
import com.vyorasound.app.presentation.theme.GlassBottomSpacer
import com.vyorasound.app.presentation.theme.HomeFeedSkeleton
import com.vyorasound.app.presentation.theme.NexaColors

@Composable
fun ExploreScreen(
    viewModel: ExploreViewModel,
    currentSongId: String?,
    onPlaySong: (Song, List<Song>?) -> Unit,
    onPlayNext: (Song) -> Unit,
    onAddToQueue: (Song) -> Unit,
    onToggleLike: (Song) -> Unit,
    onAddToPlaylist: (Song) -> Unit,
    onOpenAlbum: (Album) -> Unit,
    onOpenArtist: (Artist) -> Unit,
    onOpenPlaylist: (Playlist) -> Unit,
    onOpenMood: (MoodCategory) -> Unit
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val likedIds by viewModel.likedSongIds.collectAsStateWithLifecycle()
    val feed = uiState.feed

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .testTag("explore_screen"),
        contentPadding = PaddingValues(top = 12.dp, bottom = 16.dp),
        verticalArrangement = Arrangement.spacedBy(24.dp)
    ) {
        item(key = "explore_header") {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "TEMUKAN MUSIK",
                        style = MaterialTheme.typography.labelMedium,
                        color = NexaColors.Primary
                    )
                    Text(
                        text = "Jelajahi",
                        style = MaterialTheme.typography.displaySmall,
                        color = NexaColors.TextPrimary
                    )
                }
                IconButton(
                    onClick = { viewModel.loadExplore(isRefresh = true) },
                    modifier = Modifier
                        .size(48.dp)
                        .clip(CircleShape)
                        .background(NexaColors.Glass)
                ) {
                    if (uiState.isRefreshing) {
                        CircularProgressIndicator(
                            color = NexaColors.Primary,
                            strokeWidth = 2.dp,
                            modifier = Modifier.size(20.dp)
                        )
                    } else {
                        Icon(
                            imageVector = Icons.Rounded.Refresh,
                            contentDescription = "Muat ulang Jelajahi",
                            tint = NexaColors.TextPrimary
                        )
                    }
                }
            }
        }

        when {
            uiState.isLoading -> {
                item(key = "explore_skeleton") {
                    HomeFeedSkeleton()
                }
            }

            uiState.errorMessage != null && feed == null -> {
                item(key = "explore_error") {
                    ErrorStateCard(
                        message = uiState.errorMessage ?: "Gagal memuat Jelajahi.",
                        onRetry = { viewModel.loadExplore(isRefresh = true) }
                    )
                }
            }

            feed == null -> {
                item(key = "explore_empty") {
                    EmptyStateCard(
                        icon = Icons.Rounded.Explore,
                        title = "Belum ada konten Jelajahi",
                        subtitle = "Ketuk muat ulang untuk menampilkan lagu trending, tangga lagu, dan genre Indonesia.",
                        actionLabel = "Muat Ulang",
                        onAction = { viewModel.loadExplore(isRefresh = true) }
                    )
                }
            }

            else -> {
                if (feed.categories.isNotEmpty()) {
                    item(key = "explore_categories") {
                        Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                            SectionHeader(
                                title = "Kategori & Genre Musik",
                                subtitle = "Musik Indonesia & Suasana"
                            )
                            val chunked = feed.categories.chunked(2)
                            LazyRow(
                                contentPadding = PaddingValues(horizontal = 20.dp),
                                horizontalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                items(chunked, key = { pair -> pair.first().title }) { pair ->
                                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                        pair.forEach { mood ->
                                            MoodCategoryCard(
                                                mood = mood,
                                                onClick = { onOpenMood(mood) },
                                                modifier = Modifier.width(176.dp)
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                if (feed.newReleases.isNotEmpty()) {
                    item(key = "explore_new_releases") {
                        Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                            SectionHeader(
                                title = "Rilisan Terbaru",
                                subtitle = "Album & Single Baru"
                            )
                            LazyRow(
                                contentPadding = PaddingValues(horizontal = 20.dp),
                                horizontalArrangement = Arrangement.spacedBy(14.dp)
                            ) {
                                items(feed.newReleases, key = { "rel_${it.browseId}" }) { album ->
                                    ShelfMediaCard(
                                        item = MediaShelfItem.AlbumItem(album),
                                        onSongClick = { },
                                        onAlbumClick = onOpenAlbum,
                                        onArtistClick = onOpenArtist,
                                        onPlaylistClick = onOpenPlaylist,
                                        onMoodClick = onOpenMood
                                    )
                                }
                            }
                        }
                    }
                }

                if (feed.popularPlaylists.isNotEmpty()) {
                    item(key = "explore_playlists") {
                        Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                            SectionHeader(
                                title = "Playlist Populer",
                                subtitle = "Kurasi Pilihan"
                            )
                            LazyRow(
                                contentPadding = PaddingValues(horizontal = 20.dp),
                                horizontalArrangement = Arrangement.spacedBy(14.dp)
                            ) {
                                items(feed.popularPlaylists, key = { "pl_${it.browseId}" }) { playlist ->
                                    ShelfMediaCard(
                                        item = MediaShelfItem.PlaylistItem(playlist),
                                        onSongClick = { },
                                        onAlbumClick = onOpenAlbum,
                                        onArtistClick = onOpenArtist,
                                        onPlaylistClick = onOpenPlaylist,
                                        onMoodClick = onOpenMood
                                    )
                                }
                            }
                        }
                    }
                }

                val chartList = feed.chartSongs.ifEmpty { feed.trendingSongs }
                if (chartList.isNotEmpty()) {
                    item(key = "explore_charts_header") {
                        SectionHeader(
                            title = "Tangga Lagu & Trending",
                            subtitle = "Paling Banyak Diputar"
                        )
                    }
                    itemsIndexed(
                        items = chartList.take(25),
                        key = { idx, song -> "chart_${idx}_${song.id}" }
                    ) { index, song ->
                        SongRowItem(
                            song = song,
                            isPlaying = song.id == currentSongId,
                            isLiked = song.id in likedIds,
                            indexBadge = index + 1,
                            onClick = { onPlaySong(song, chartList) },
                            onToggleLike = { onToggleLike(song) },
                            onPlayNext = { onPlayNext(song) },
                            onAddToQueue = { onAddToQueue(song) },
                            onAddToPlaylist = { onAddToPlaylist(song) },
                            onOpenArtist = { id -> onOpenArtist(Artist(id = id, name = song.artist)) },
                            onOpenAlbum = { id -> onOpenAlbum(Album(id = id, title = song.album.orEmpty(), artist = song.artist)) },
                            modifier = Modifier.padding(horizontal = 20.dp)
                        )
                    }
                }

                feed.extraSections.forEachIndexed { secIndex, section ->
                    item(key = "explore_extra_${secIndex}_${section.title}") {
                        Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                            SectionHeader(title = section.title, subtitle = section.subtitle)
                            LazyRow(
                                contentPadding = PaddingValues(horizontal = 20.dp),
                                horizontalArrangement = Arrangement.spacedBy(14.dp)
                            ) {
                                items(section.items, key = { "${secIndex}_${it.stableId}" }) { item ->
                                    ShelfMediaCard(
                                        item = item,
                                        onSongClick = { s -> onPlaySong(s, listOf(s)) },
                                        onAlbumClick = onOpenAlbum,
                                        onArtistClick = onOpenArtist,
                                        onPlaylistClick = onOpenPlaylist,
                                        onMoodClick = onOpenMood
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        item(key = "explore_bottom_spacer") {
            GlassBottomSpacer()
        }
    }
}
