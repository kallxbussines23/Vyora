package com.vyorasound.app.presentation.library

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Album
import androidx.compose.material.icons.rounded.DeleteOutline
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.rounded.History
import androidx.compose.material.icons.rounded.Person
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.PlaylistPlay
import androidx.compose.material.icons.rounded.Shuffle
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.vyorasound.app.domain.model.Album
import com.vyorasound.app.domain.model.Artist
import com.vyorasound.app.domain.model.Playlist
import com.vyorasound.app.domain.model.Song
import com.vyorasound.app.presentation.components.NexaArtwork
import com.vyorasound.app.presentation.components.SongRowItem
import com.vyorasound.app.presentation.theme.EmptyStateCard
import com.vyorasound.app.presentation.theme.GlassBottomSpacer
import com.vyorasound.app.presentation.theme.GlassCard
import com.vyorasound.app.presentation.theme.GlassPill
import com.vyorasound.app.presentation.theme.NexaColors

@Composable
fun LibraryScreen(
    viewModel: LibraryViewModel,
    currentSongId: String?,
    onPlaySong: (Song, List<Song>?) -> Unit,
    onPlayNext: (Song) -> Unit,
    onAddToQueue: (Song) -> Unit,
    onToggleLike: (Song) -> Unit,
    onAddToPlaylist: (Song) -> Unit,
    onOpenAlbum: (Album) -> Unit,
    onOpenArtist: (Artist) -> Unit,
    onOpenPlaylist: (Playlist) -> Unit,
    onNavigateToSearch: () -> Unit,
    isYouTubeSignedIn: Boolean = false,
    onYouTubeAccountClick: (() -> Unit)? = null
) {
    val selectedTab by viewModel.selectedTab.collectAsStateWithLifecycle()
    val likedSongs by viewModel.likedSongs.collectAsStateWithLifecycle()
    val playlists by viewModel.playlists.collectAsStateWithLifecycle()
    val albums by viewModel.albums.collectAsStateWithLifecycle()
    val artists by viewModel.artists.collectAsStateWithLifecycle()
    val recentlyPlayed by viewModel.recentlyPlayed.collectAsStateWithLifecycle()
    val likedIds = remember(likedSongs) { likedSongs.map { it.id }.toSet() }

    var showCreateDialog by remember { mutableStateOf(false) }
    var newPlaylistTitle by remember { mutableStateOf("") }

    if (showCreateDialog) {
        AlertDialog(
            onDismissRequest = { showCreateDialog = false },
            containerColor = NexaColors.SurfaceHigh,
            title = { Text("Buat Playlist", color = NexaColors.TextPrimary) },
            text = {
                OutlinedTextField(
                    value = newPlaylistTitle,
                    onValueChange = { newPlaylistTitle = it },
                    placeholder = { Text("Nama playlist", color = NexaColors.TextSecondary) },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = NexaColors.Primary,
                        unfocusedBorderColor = NexaColors.GlassBorder,
                        focusedTextColor = NexaColors.TextPrimary,
                        unfocusedTextColor = NexaColors.TextPrimary
                    )
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (newPlaylistTitle.isNotBlank()) {
                            viewModel.createPlaylist(newPlaylistTitle)
                            newPlaylistTitle = ""
                            showCreateDialog = false
                        }
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = NexaColors.Primary,
                        contentColor = NexaColors.OnPrimary
                    )
                ) {
                    Text("Buat")
                }
            },
            dismissButton = {
                TextButton(onClick = { showCreateDialog = false }) {
                    Text("Batal", color = NexaColors.TextSecondary)
                }
            }
        )
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .testTag("library_screen")
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = "KOLEKSI VYORA",
                    style = MaterialTheme.typography.labelMedium,
                    color = NexaColors.Primary
                )
                Text(
                    text = "Pustaka Kamu",
                    style = MaterialTheme.typography.displaySmall,
                    color = NexaColors.TextPrimary
                )
            }
            Row(
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (onYouTubeAccountClick != null) {
                    IconButton(
                        onClick = onYouTubeAccountClick,
                        modifier = Modifier
                            .size(48.dp)
                            .clip(CircleShape)
                            .background(
                                if (isYouTubeSignedIn) {
                                    NexaColors.Primary.copy(alpha = 0.2f)
                                } else {
                                    NexaColors.GlassStrong
                                }
                            )
                            .testTag("library_youtube_account_button")
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Person,
                            contentDescription = if (isYouTubeSignedIn) {
                                "Akun YouTube terhubung"
                            } else {
                                "Hubungkan akun YouTube opsional"
                            },
                            tint = if (isYouTubeSignedIn) NexaColors.Primary else NexaColors.TextSecondary
                        )
                    }
                }
                IconButton(
                    onClick = { showCreateDialog = true },
                    modifier = Modifier
                        .size(48.dp)
                        .clip(CircleShape)
                        .background(NexaColors.GlassStrong)
                        .testTag("create_playlist_button")
                ) {
                    Icon(
                        imageVector = Icons.Rounded.Add,
                        contentDescription = "Create playlist",
                        tint = NexaColors.Primary
                    )
                }
            }
        }

        LazyRow(
            contentPadding = PaddingValues(horizontal = 20.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            modifier = Modifier.padding(bottom = 12.dp)
        ) {
            items(LibraryTab.entries, key = { it.name }) { tab ->
                val count = when (tab) {
                    LibraryTab.LIKED -> likedSongs.size
                    LibraryTab.PLAYLISTS -> playlists.size
                    LibraryTab.ALBUMS -> albums.size
                    LibraryTab.ARTISTS -> artists.size
                    LibraryTab.RECENT -> recentlyPlayed.size
                }
                GlassPill(
                    selected = selectedTab == tab,
                    onClick = { viewModel.selectTab(tab) },
                    modifier = Modifier.testTag("library_tab_${tab.name.lowercase()}")
                ) {
                    Text(
                        text = if (count > 0) "${tab.label} ($count)" else tab.label,
                        style = MaterialTheme.typography.labelLarge,
                        color = if (selectedTab == tab) NexaColors.Primary else NexaColors.TextSecondary
                    )
                }
            }
        }

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(horizontal = 20.dp, vertical = 4.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            when (selectedTab) {
                LibraryTab.LIKED -> {
                    if (likedSongs.isEmpty()) {
                        item(key = "empty_liked") {
                            EmptyStateCard(
                                icon = Icons.Rounded.Favorite,
                                title = "Belum ada lagu disukai",
                                subtitle = "Ketuk ikon hati pada lagu favoritmu untuk menyimpannya di sini.",
                                actionLabel = "Cari musik",
                                onAction = onNavigateToSearch
                            )
                        }
                    } else {
                        item(key = "liked_actions") {
                            PlaybackActionBar(
                                onPlayAll = { onPlaySong(likedSongs.first(), likedSongs) },
                                onShuffleAll = {
                                    val shuffled = likedSongs.shuffled()
                                    onPlaySong(shuffled.first(), shuffled)
                                }
                            )
                        }
                        items(likedSongs, key = { "liked_${it.id}" }) { song ->
                            SongRowItem(
                                song = song,
                                isPlaying = song.id == currentSongId,
                                isLiked = true,
                                onClick = { onPlaySong(song, likedSongs) },
                                onToggleLike = { onToggleLike(song) },
                                onPlayNext = { onPlayNext(song) },
                                onAddToQueue = { onAddToQueue(song) },
                                onAddToPlaylist = { onAddToPlaylist(song) },
                                onOpenArtist = { id -> onOpenArtist(Artist(id = id, name = song.artist)) },
                                onOpenAlbum = { id -> onOpenAlbum(Album(id = id, title = song.album.orEmpty(), artist = song.artist)) }
                            )
                        }
                    }
                }

                LibraryTab.PLAYLISTS -> {
                    if (playlists.isEmpty()) {
                        item(key = "empty_playlists") {
                            EmptyStateCard(
                                icon = Icons.Rounded.PlaylistPlay,
                                title = "Belum ada playlist tersimpan",
                                subtitle = "Buat playlist sendiri dengan tombol + atau simpan playlist dari Jelajahi.",
                                actionLabel = "Buat playlist",
                                onAction = { showCreateDialog = true }
                            )
                        }
                    } else {
                        items(playlists, key = { "lib_pl_${it.browseId}" }) { playlist ->
                            GlassCard(
                                shape = RoundedCornerShape(18.dp),
                                backgroundAlpha = 0.45f,
                                onClick = { onOpenPlaylist(playlist) }
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(12.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    if (playlist.thumbnailUrl.isNotBlank()) {
                                        NexaArtwork(
                                            url = playlist.thumbnailUrl,
                                            contentDescription = playlist.title,
                                            shape = RoundedCornerShape(14.dp),
                                            modifier = Modifier.size(56.dp)
                                        )
                                    } else {
                                        Box(
                                            modifier = Modifier
                                                .size(56.dp)
                                                .clip(RoundedCornerShape(14.dp))
                                                .background(NexaColors.Primary.copy(alpha = 0.16f)),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Icon(
                                                imageVector = Icons.Rounded.PlaylistPlay,
                                                contentDescription = null,
                                                tint = NexaColors.Primary,
                                                modifier = Modifier.size(28.dp)
                                            )
                                        }
                                    }
                                    Spacer(modifier = Modifier.width(14.dp))
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = playlist.title,
                                            style = MaterialTheme.typography.titleMedium,
                                            color = NexaColors.TextPrimary,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                        Text(
                                            text = listOfNotNull(
                                                playlist.author.takeIf { it.isNotBlank() },
                                                playlist.trackCountText.takeIf { it.isNotBlank() }
                                            ).joinToString(" • "),
                                            style = MaterialTheme.typography.bodySmall,
                                            color = NexaColors.TextSecondary,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                    }
                                    if (playlist.isUserCreated) {
                                        IconButton(
                                            onClick = { viewModel.deletePlaylist(playlist.id) },
                                            modifier = Modifier.size(48.dp)
                                        ) {
                                            Icon(
                                                imageVector = Icons.Rounded.DeleteOutline,
                                                contentDescription = "Delete playlist",
                                                tint = NexaColors.TextSecondary
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                LibraryTab.ALBUMS -> {
                    if (albums.isEmpty()) {
                        item(key = "empty_albums") {
                            EmptyStateCard(
                                icon = Icons.Rounded.Album,
                                title = "Belum ada album tersimpan",
                                subtitle = "Buka halaman album dan ketuk Simpan untuk menambahkannya ke pustaka.",
                                actionLabel = "Temukan album",
                                onAction = onNavigateToSearch
                            )
                        }
                    } else {
                        items(albums, key = { "lib_alb_${it.browseId}" }) { album ->
                            GlassCard(
                                shape = RoundedCornerShape(18.dp),
                                backgroundAlpha = 0.45f,
                                onClick = { onOpenAlbum(album) }
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(12.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    NexaArtwork(
                                        url = album.thumbnailUrl,
                                        contentDescription = album.title,
                                        shape = RoundedCornerShape(14.dp),
                                        modifier = Modifier.size(56.dp)
                                    )
                                    Spacer(modifier = Modifier.width(14.dp))
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = album.title,
                                            style = MaterialTheme.typography.titleMedium,
                                            color = NexaColors.TextPrimary,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                        Text(
                                            text = listOfNotNull(album.artist.takeIf { it.isNotBlank() }, album.year)
                                                .joinToString(" • "),
                                            style = MaterialTheme.typography.bodySmall,
                                            color = NexaColors.TextSecondary,
                                            maxLines = 1
                                        )
                                    }
                                }
                            }
                        }
                    }
                }

                LibraryTab.ARTISTS -> {
                    if (artists.isEmpty()) {
                        item(key = "empty_artists") {
                            EmptyStateCard(
                                icon = Icons.Rounded.Person,
                                title = "Belum ada artis diikuti",
                                subtitle = "Simpan artis dari halaman profil mereka untuk akses cepat.",
                                actionLabel = "Cari artis",
                                onAction = onNavigateToSearch
                            )
                        }
                    } else {
                        items(artists, key = { "lib_art_${it.browseId}" }) { artist ->
                            GlassCard(
                                shape = RoundedCornerShape(18.dp),
                                backgroundAlpha = 0.45f,
                                onClick = { onOpenArtist(artist) }
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(12.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    NexaArtwork(
                                        url = artist.thumbnailUrl,
                                        contentDescription = artist.name,
                                        shape = CircleShape,
                                        modifier = Modifier.size(56.dp)
                                    )
                                    Spacer(modifier = Modifier.width(14.dp))
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = artist.name,
                                            style = MaterialTheme.typography.titleMedium,
                                            color = NexaColors.TextPrimary,
                                            maxLines = 1
                                        )
                                        if (artist.subtitle.isNotBlank()) {
                                            Text(
                                                text = artist.subtitle,
                                                style = MaterialTheme.typography.bodySmall,
                                                color = NexaColors.TextSecondary,
                                                maxLines = 1
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                LibraryTab.RECENT -> {
                    if (recentlyPlayed.isEmpty()) {
                        item(key = "empty_recent") {
                            EmptyStateCard(
                                icon = Icons.Rounded.History,
                                title = "Belum ada riwayat putar",
                                subtitle = "Lagu yang kamu dengarkan akan otomatis muncul di sini."
                            )
                        }
                    } else {
                        item(key = "recent_actions") {
                            PlaybackActionBar(
                                onPlayAll = { onPlaySong(recentlyPlayed.first(), recentlyPlayed) },
                                onShuffleAll = {
                                    val shuffled = recentlyPlayed.shuffled()
                                    onPlaySong(shuffled.first(), shuffled)
                                }
                            )
                        }
                        items(recentlyPlayed, key = { "rec_${it.id}" }) { song ->
                            SongRowItem(
                                song = song,
                                isPlaying = song.id == currentSongId,
                                isLiked = song.id in likedIds,
                                onClick = { onPlaySong(song, recentlyPlayed) },
                                onToggleLike = { onToggleLike(song) },
                                onPlayNext = { onPlayNext(song) },
                                onAddToQueue = { onAddToQueue(song) },
                                onAddToPlaylist = { onAddToPlaylist(song) },
                                onOpenArtist = { id -> onOpenArtist(Artist(id = id, name = song.artist)) },
                                onOpenAlbum = { id -> onOpenAlbum(Album(id = id, title = song.album.orEmpty(), artist = song.artist)) }
                            )
                        }
                    }
                }
            }

            item(key = "library_bottom_spacer") {
                GlassBottomSpacer()
            }
        }
    }
}

@Composable
private fun PlaybackActionBar(
    onPlayAll: () -> Unit,
    onShuffleAll: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Button(
            onClick = onPlayAll,
            colors = ButtonDefaults.buttonColors(
                containerColor = NexaColors.Primary,
                contentColor = NexaColors.OnPrimary
            ),
            shape = RoundedCornerShape(50),
            modifier = Modifier
                .weight(1f)
                .height(48.dp)
        ) {
            Icon(Icons.Rounded.PlayArrow, contentDescription = null, modifier = Modifier.size(20.dp))
            Spacer(modifier = Modifier.width(6.dp))
            Text("Putar Semua")
        }
        OutlinedButton(
            onClick = onShuffleAll,
            shape = RoundedCornerShape(50),
            colors = ButtonDefaults.outlinedButtonColors(contentColor = NexaColors.Primary),
            modifier = Modifier
                .weight(1f)
                .height(48.dp)
        ) {
            Icon(Icons.Rounded.Shuffle, contentDescription = null, modifier = Modifier.size(18.dp))
            Spacer(modifier = Modifier.width(6.dp))
            Text("Acak")
        }
    }
}
