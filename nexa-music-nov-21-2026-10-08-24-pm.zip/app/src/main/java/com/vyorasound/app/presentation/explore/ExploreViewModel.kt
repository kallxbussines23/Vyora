package com.vyorasound.app.presentation.explore

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.vyorasound.app.domain.model.ExploreFeed
import com.vyorasound.app.domain.model.IndonesianDiscovery
import com.vyorasound.app.domain.model.SearchFilter
import com.vyorasound.app.domain.repository.LibraryRepository
import com.vyorasound.app.domain.repository.MusicRepository
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class ExploreUiState(
    val isLoading: Boolean = true,
    val isRefreshing: Boolean = false,
    val feed: ExploreFeed? = null,
    val errorMessage: String? = null
)

class ExploreViewModel(
    private val musicRepository: MusicRepository,
    libraryRepository: LibraryRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow(ExploreUiState())
    val uiState: StateFlow<ExploreUiState> = _uiState.asStateFlow()

    val likedSongIds: StateFlow<Set<String>> = MutableStateFlow<Set<String>>(emptySet()).also { flow ->
        viewModelScope.launch {
            libraryRepository.likedSongs.collect { songs ->
                flow.value = songs.map { it.id }.toSet()
            }
        }
    }

    init {
        loadExplore(isRefresh = false)
    }

    fun loadExplore(isRefresh: Boolean = true) {
        viewModelScope.launch {
            _uiState.update {
                it.copy(
                    isLoading = !isRefresh && it.feed == null,
                    isRefreshing = isRefresh,
                    errorMessage = null
                )
            }
            try {
                coroutineScope {
                    val exploreDeferred = async { musicRepository.getExploreFeed() }
                    val indoPlaylistsDeferred = async {
                        musicRepository.search("Playlist Lagu Indonesia Terpopuler", SearchFilter.PLAYLISTS)
                    }
                    val indoTrendingDeferred = async {
                        musicRepository.search("Top 50 Indonesia Viral Hits", SearchFilter.SONGS)
                    }

                    val exploreRes = exploreDeferred.await()
                    val base = exploreRes.getOrNull()
                    val indoPlaylists = indoPlaylistsDeferred.await().getOrNull()?.playlists.orEmpty()
                    val indoTrending = indoTrendingDeferred.await().getOrNull()?.songs.orEmpty()

                    if (base == null && indoTrending.isEmpty() && indoPlaylists.isEmpty()) {
                        val err = exploreRes.exceptionOrNull()
                        _uiState.update {
                            it.copy(
                                isLoading = false,
                                isRefreshing = false,
                                errorMessage = err?.localizedMessage ?: "Gagal memuat halaman Jelajahi."
                            )
                        }
                    } else {
                        val mergedCategories = (IndonesianDiscovery.categories + base?.categories.orEmpty())
                            .distinctBy { it.title.lowercase() }
                        val mergedPlaylists = (indoPlaylists + base?.popularPlaylists.orEmpty())
                            .distinctBy { it.browseId }
                        val mergedCharts = (base?.chartSongs.orEmpty() + indoTrending + base?.trendingSongs.orEmpty())
                            .distinctBy { it.id }

                        _uiState.update {
                            it.copy(
                                isLoading = false,
                                isRefreshing = false,
                                feed = ExploreFeed(
                                    trendingSongs = (base?.trendingSongs.orEmpty() + indoTrending).distinctBy { s -> s.id },
                                    newReleases = base?.newReleases.orEmpty(),
                                    popularPlaylists = mergedPlaylists,
                                    categories = mergedCategories,
                                    chartSongs = mergedCharts,
                                    extraSections = base?.extraSections.orEmpty()
                                ),
                                errorMessage = null
                            )
                        }
                    }
                }
            } catch (e: Exception) {
                _uiState.update {
                    it.copy(
                        isLoading = false,
                        isRefreshing = false,
                        errorMessage = e.localizedMessage ?: "Gagal memuat halaman Jelajahi."
                    )
                }
            }
        }
    }

    class Factory(
        private val musicRepository: MusicRepository,
        private val libraryRepository: LibraryRepository
    ) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return ExploreViewModel(musicRepository, libraryRepository) as T
        }
    }
}
