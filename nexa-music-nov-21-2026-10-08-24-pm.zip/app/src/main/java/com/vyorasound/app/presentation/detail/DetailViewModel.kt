package com.vyorasound.app.presentation.detail

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.vyorasound.app.domain.model.Album
import com.vyorasound.app.domain.model.AlbumDetail
import com.vyorasound.app.domain.model.Artist
import com.vyorasound.app.domain.model.ArtistDetail
import com.vyorasound.app.domain.model.HomeSection
import com.vyorasound.app.domain.model.Playlist
import com.vyorasound.app.domain.model.PlaylistDetail
import com.vyorasound.app.domain.repository.LibraryRepository
import com.vyorasound.app.domain.repository.MusicRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

sealed interface DetailPayload {
    data class ArtistContent(val detail: ArtistDetail) : DetailPayload
    data class AlbumContent(val detail: AlbumDetail) : DetailPayload
    data class PlaylistContent(val detail: PlaylistDetail, val isUserCreated: Boolean) : DetailPayload
    data class CategoryContent(val title: String, val sections: List<HomeSection>) : DetailPayload
}

data class DetailUiState(
    val isLoading: Boolean = true,
    val isLoadingMore: Boolean = false,
    val payload: DetailPayload? = null,
    val errorMessage: String? = null
)

class DetailViewModel(
    private val type: String,
    private val id: String,
    private val titleHint: String?,
    private val params: String?,
    private val musicRepository: MusicRepository,
    private val libraryRepository: LibraryRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow(DetailUiState())
    val uiState: StateFlow<DetailUiState> = _uiState.asStateFlow()

    val likedSongIds: StateFlow<Set<String>> = MutableStateFlow<Set<String>>(emptySet()).also { flow ->
        viewModelScope.launch {
            libraryRepository.likedSongs.collect { list -> flow.value = list.map { it.id }.toSet() }
        }
    }

    val isSaved: StateFlow<Boolean> = MutableStateFlow(false).also { flow ->
        viewModelScope.launch {
            when (type) {
                "artist" -> libraryRepository.savedArtists.collect { list ->
                    flow.value = list.any { it.browseId == id || it.id == id }
                }
                "album" -> libraryRepository.savedAlbums.collect { list ->
                    flow.value = list.any { it.browseId == id || it.id == id }
                }
                "playlist" -> libraryRepository.savedPlaylists.collect { list ->
                    flow.value = list.any { it.browseId == id || it.id == id }
                }
            }
        }
    }

    init {
        loadDetail()
    }

    fun loadDetail() {
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true, errorMessage = null) }
            when (type) {
                "artist" -> {
                    musicRepository.getArtistDetail(id)
                        .onSuccess { detail ->
                            _uiState.update { it.copy(isLoading = false, payload = DetailPayload.ArtistContent(detail)) }
                        }
                        .onFailure { err ->
                            _uiState.update { it.copy(isLoading = false, errorMessage = err.localizedMessage ?: "Failed to load artist.") }
                        }
                }
                "album" -> {
                    musicRepository.getAlbumDetail(id)
                        .onSuccess { detail ->
                            _uiState.update { it.copy(isLoading = false, payload = DetailPayload.AlbumContent(detail)) }
                        }
                        .onFailure { err ->
                            _uiState.update { it.copy(isLoading = false, errorMessage = err.localizedMessage ?: "Failed to load album.") }
                        }
                }
                "playlist" -> {
                    if (id.startsWith("local_")) {
                        libraryRepository.savedPlaylists.collect { playlists ->
                            val local = playlists.firstOrNull { it.id == id || it.browseId == id }
                            if (local != null) {
                                _uiState.update {
                                    it.copy(
                                        isLoading = false,
                                        payload = DetailPayload.PlaylistContent(
                                            detail = PlaylistDetail(
                                                id = local.id,
                                                title = local.title,
                                                author = local.author,
                                                trackCountText = local.trackCountText,
                                                thumbnailUrl = local.thumbnailUrl.ifBlank {
                                                    local.songs.firstOrNull()?.thumbnailUrl.orEmpty()
                                                },
                                                songs = local.songs
                                            ),
                                            isUserCreated = true
                                        )
                                    )
                                }
                            } else {
                                _uiState.update {
                                    it.copy(isLoading = false, errorMessage = "Playlist not found.")
                                }
                            }
                        }
                    } else {
                        musicRepository.getPlaylistDetail(id)
                            .onSuccess { detail ->
                                _uiState.update {
                                    it.copy(isLoading = false, payload = DetailPayload.PlaylistContent(detail, false))
                                }
                            }
                            .onFailure { err ->
                                _uiState.update {
                                    it.copy(isLoading = false, errorMessage = err.localizedMessage ?: "Failed to load playlist.")
                                }
                            }
                    }
                }
                else -> {
                    musicRepository.getBrowseCategory(id, params)
                        .onSuccess { sections ->
                            _uiState.update {
                                it.copy(
                                    isLoading = false,
                                    payload = DetailPayload.CategoryContent(titleHint ?: "Browse", sections)
                                )
                            }
                        }
                        .onFailure { err ->
                            _uiState.update {
                                it.copy(isLoading = false, errorMessage = err.localizedMessage ?: "Failed to load category.")
                            }
                        }
                }
            }
        }
    }

    fun loadMorePlaylistTracks() {
        val current = (_uiState.value.payload as? DetailPayload.PlaylistContent) ?: return
        val token = current.detail.continuation ?: return
        if (_uiState.value.isLoadingMore) return
        viewModelScope.launch {
            _uiState.update { it.copy(isLoadingMore = true) }
            musicRepository.getPlaylistDetail(id, continuation = token)
                .onSuccess { next ->
                    _uiState.update {
                        it.copy(
                            isLoadingMore = false,
                            payload = current.copy(
                                detail = current.detail.copy(
                                    songs = (current.detail.songs + next.songs).distinctBy { s -> s.id },
                                    continuation = next.continuation
                                )
                            )
                        )
                    }
                }
                .onFailure {
                    _uiState.update { it.copy(isLoadingMore = false) }
                }
        }
    }

    fun toggleSave() {
        val payload = _uiState.value.payload ?: return
        viewModelScope.launch {
            when (payload) {
                is DetailPayload.ArtistContent -> {
                    libraryRepository.toggleSaveArtist(
                        Artist(
                            id = payload.detail.id,
                            name = payload.detail.name,
                            subtitle = payload.detail.subscriberCount,
                            thumbnailUrl = payload.detail.thumbnailUrl,
                            browseId = payload.detail.id
                        )
                    )
                }
                is DetailPayload.AlbumContent -> {
                    libraryRepository.toggleSaveAlbum(
                        Album(
                            id = payload.detail.id,
                            title = payload.detail.title,
                            artist = payload.detail.artist,
                            artistId = payload.detail.artistId,
                            year = payload.detail.year,
                            thumbnailUrl = payload.detail.thumbnailUrl,
                            browseId = payload.detail.id
                        )
                    )
                }
                is DetailPayload.PlaylistContent -> {
                    if (!payload.isUserCreated) {
                        libraryRepository.toggleSavePlaylist(
                            Playlist(
                                id = payload.detail.id,
                                title = payload.detail.title,
                                author = payload.detail.author,
                                trackCountText = payload.detail.trackCountText,
                                thumbnailUrl = payload.detail.thumbnailUrl,
                                browseId = id,
                                isUserCreated = false
                            )
                        )
                    }
                }
                is DetailPayload.CategoryContent -> Unit
            }
        }
    }

    fun removeSongFromLocalPlaylist(songId: String) {
        if (!id.startsWith("local_")) return
        viewModelScope.launch {
            libraryRepository.removeSongFromPlaylist(id, songId)
        }
    }

    class Factory(
        private val type: String,
        private val id: String,
        private val titleHint: String?,
        private val params: String?,
        private val musicRepository: MusicRepository,
        private val libraryRepository: LibraryRepository
    ) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return DetailViewModel(type, id, titleHint, params, musicRepository, libraryRepository) as T
        }
    }
}
