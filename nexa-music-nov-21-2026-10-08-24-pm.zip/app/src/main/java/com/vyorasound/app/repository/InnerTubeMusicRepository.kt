package com.vyorasound.app.repository

import android.util.LruCache
import com.vyorasound.app.data.dto.BrowseRequestDto
import com.vyorasound.app.data.dto.NextRequestDto
import com.vyorasound.app.data.dto.PlaybackContextDto
import com.vyorasound.app.data.dto.PlayerRequestDto
import com.vyorasound.app.data.dto.SearchRequestDto
import com.vyorasound.app.data.dto.SearchSuggestionsRequestDto
import com.vyorasound.app.data.dto.toContextDto
import com.vyorasound.app.data.parser.InnerTubeJsonParser
import com.vyorasound.app.domain.model.AlbumDetail
import com.vyorasound.app.domain.model.ArtistDetail
import com.vyorasound.app.domain.model.ExploreFeed
import com.vyorasound.app.domain.model.HomeFeed
import com.vyorasound.app.domain.model.HomeSection
import com.vyorasound.app.domain.model.PlaybackStream
import com.vyorasound.app.domain.model.PlaylistDetail
import com.vyorasound.app.domain.model.SearchFilter
import com.vyorasound.app.domain.model.SearchResults
import com.vyorasound.app.domain.model.SearchSuggestionItem
import com.vyorasound.app.domain.model.Song
import com.vyorasound.app.domain.model.WatchNextData
import com.vyorasound.app.domain.repository.MusicRepository
import com.vyorasound.app.network.InnerTubeApiService
import com.vyorasound.app.network.InnerTubeClientConfig
import com.vyorasound.app.network.NetworkModule
import com.vyorasound.app.network.NoOpYouTubeAuthProvider
import com.vyorasound.app.network.YouTubeAuthProvider
import com.vyorasound.app.player.PlaybackDiagnostics
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.IOException
import java.util.concurrent.ConcurrentHashMap

data class StreamProbeResult(
    val isPlayable: Boolean,
    val httpStatus: Int? = null,
    val errorDetail: String? = null
)

fun interface StreamProber {
    suspend fun probe(stream: PlaybackStream): StreamProbeResult
}

class OkHttpStreamProber(
    private val httpClient: OkHttpClient = NetworkModule.streamOkHttpClient
) : StreamProber {
    override suspend fun probe(stream: PlaybackStream): StreamProbeResult = withContext(Dispatchers.IO) {
        runCatching {
            val requestBuilder = Request.Builder()
                .url(stream.streamUrl)
                .header("User-Agent", stream.userAgent)
                .get()
            if (!stream.isHls) {
                requestBuilder.header("Range", "bytes=0-1")
            }
            httpClient.newCall(requestBuilder.build()).execute().use { response ->
                val code = response.code
                val ok = code in 200..299
                StreamProbeResult(
                    isPlayable = ok,
                    httpStatus = code,
                    errorDetail = if (ok) null else "HTTP $code ${response.message}"
                )
            }
        }.getOrElse { err ->
            StreamProbeResult(
                isPlayable = false,
                httpStatus = null,
                errorDetail = err.message ?: err.javaClass.simpleName
            )
        }
    }
}

class LoginRequiredPlaybackException(message: String) : IOException(message)

class InnerTubeMusicRepository(
    private val apiService: InnerTubeApiService,
    private val streamProber: StreamProber = OkHttpStreamProber(NetworkModule.streamOkHttpClient),
    private val noLoginFallbackResolver: NoLoginFallbackResolver = PublicApiNoLoginFallbackResolver(),
    private val authProvider: YouTubeAuthProvider = NoOpYouTubeAuthProvider
) : MusicRepository {

    private data class CacheEntry<T>(val value: T, val expiresAtMs: Long)

    // Memory-bounded caches suitable for mid-range Android devices
    private val streamCache = LruCache<String, PlaybackStream>(60)
    private val homeCache = LruCache<String, CacheEntry<HomeFeed>>(8)
    private val exploreCache = LruCache<String, CacheEntry<ExploreFeed>>(2)
    private val artistCache = LruCache<String, CacheEntry<ArtistDetail>>(20)
    private val albumCache = LruCache<String, CacheEntry<AlbumDetail>>(25)
    private val playlistCache = LruCache<String, CacheEntry<PlaylistDetail>>(25)
    private val songTitleRegistry = ConcurrentHashMap<String, String>()

    @Volatile
    private var cachedVisitorData: String? = null

    @Volatile
    private var cachedNativeVisitorData: String? = null

    private val feedTtlMs = 5 * 60 * 1000L
    private val detailTtlMs = 15 * 60 * 1000L

    override fun registerSongTitle(videoId: String, title: String) {
        if (videoId.isNotBlank() && title.isNotBlank()) {
            songTitleRegistry[videoId] = title
        }
    }

    override fun invalidateStreamCache(videoId: String) {
        streamCache.remove(videoId)
        PlaybackDiagnostics.i(
            "CacheInvalidated | title=\"${songTitleRegistry[videoId] ?: "-"}\" | videoId=$videoId"
        )
    }

    override suspend fun getHomeFeed(continuation: String?): Result<HomeFeed> = withContext(Dispatchers.IO) {
        val cacheKey = continuation ?: "HOME_ROOT"
        val cached = homeCache.get(cacheKey)
        if (cached != null && System.currentTimeMillis() < cached.expiresAtMs) {
            return@withContext Result.success(cached.value)
        }
        runCatching {
            val profile = InnerTubeClientConfig.webRemix
            val body = BrowseRequestDto(
                context = profile.toContextDto(cachedVisitorData),
                browseId = if (continuation == null) "FEmusic_home" else null
            )
            val json = executeString(apiService.browse(profile.buildHeaders(cachedVisitorData), body, continuation))
            val parsed = InnerTubeJsonParser.parseHomeFeed(json)
            homeCache.put(cacheKey, CacheEntry(parsed, System.currentTimeMillis() + feedTtlMs))
            parsed
        }
    }

    override suspend fun getExploreFeed(): Result<ExploreFeed> = withContext(Dispatchers.IO) {
        val cached = exploreCache.get("EXPLORE_ROOT")
        if (cached != null && System.currentTimeMillis() < cached.expiresAtMs) {
            return@withContext Result.success(cached.value)
        }
        runCatching {
            val profile = InnerTubeClientConfig.webRemix
            val exploreJson = executeString(
                apiService.browse(
                    profile.buildHeaders(cachedVisitorData),
                    BrowseRequestDto(context = profile.toContextDto(cachedVisitorData), browseId = "FEmusic_explore")
                )
            )
            val baseExplore = InnerTubeJsonParser.parseExploreFeed(exploreJson)

            // Fetch charts in best-effort manner to enrich Charts section
            val chartsSongs = runCatching {
                val chartsJson = executeString(
                    apiService.browse(
                        profile.buildHeaders(cachedVisitorData),
                        BrowseRequestDto(context = profile.toContextDto(cachedVisitorData), browseId = "FEmusic_charts")
                    )
                )
                InnerTubeJsonParser.parseChartsSongs(chartsJson)
            }.getOrDefault(emptyList())

            val result = baseExplore.copy(
                chartSongs = chartsSongs.ifEmpty { baseExplore.trendingSongs }
            )
            exploreCache.put("EXPLORE_ROOT", CacheEntry(result, System.currentTimeMillis() + feedTtlMs))
            result
        }
    }

    override suspend fun getBrowseCategory(browseId: String, params: String?): Result<List<HomeSection>> =
        withContext(Dispatchers.IO) {
            val categoryQuery = com.vyorasound.app.domain.model.IndonesianDiscovery.extractCategoryQuery(browseId)
            if (categoryQuery != null) {
                return@withContext runCatching {
                    coroutineScope {
                        val songsDeferred = async {
                            search(categoryQuery, com.vyorasound.app.domain.model.SearchFilter.SONGS)
                        }
                        val playlistsDeferred = async {
                            search(categoryQuery, com.vyorasound.app.domain.model.SearchFilter.PLAYLISTS)
                        }
                        val albumsDeferred = async {
                            search(categoryQuery, com.vyorasound.app.domain.model.SearchFilter.ALBUMS)
                        }

                        val songsRes = songsDeferred.await().getOrNull()
                        val playlistsRes = playlistsDeferred.await().getOrNull()
                        val albumsRes = albumsDeferred.await().getOrNull()

                        buildList {
                            if (songsRes != null && songsRes.songs.isNotEmpty()) {
                                add(
                                    HomeSection(
                                        title = "Lagu Pilihan",
                                        subtitle = "Musik Indonesia",
                                        items = songsRes.songs.map { com.vyorasound.app.domain.model.MediaShelfItem.SongItem(it) }
                                    )
                                )
                            }
                            if (playlistsRes != null && playlistsRes.playlists.isNotEmpty()) {
                                add(
                                    HomeSection(
                                        title = "Playlist Terkurasi",
                                        subtitle = "Koleksi",
                                        items = playlistsRes.playlists.map { com.vyorasound.app.domain.model.MediaShelfItem.PlaylistItem(it) }
                                    )
                                )
                            }
                            if (albumsRes != null && albumsRes.albums.isNotEmpty()) {
                                add(
                                    HomeSection(
                                        title = "Album Terkait",
                                        subtitle = "Rilisan",
                                        items = albumsRes.albums.map { com.vyorasound.app.domain.model.MediaShelfItem.AlbumItem(it) }
                                    )
                                )
                            }
                        }
                    }
                }
            }

            runCatching {
                val profile = InnerTubeClientConfig.webRemix
                val json = executeString(
                    apiService.browse(
                        profile.buildHeaders(cachedVisitorData),
                        BrowseRequestDto(
                            context = profile.toContextDto(cachedVisitorData),
                            browseId = browseId,
                            params = params
                        )
                    )
                )
                InnerTubeJsonParser.parseBrowseSections(json)
            }
        }

    override suspend fun getSearchSuggestions(query: String): Result<List<SearchSuggestionItem>> =
        withContext(Dispatchers.IO) {
            if (query.isBlank()) return@withContext Result.success(emptyList())
            runCatching {
                val profile = InnerTubeClientConfig.webRemix
                val json = executeString(
                    apiService.getSearchSuggestions(
                        profile.buildHeaders(cachedVisitorData),
                        SearchSuggestionsRequestDto(context = profile.toContextDto(cachedVisitorData), input = query)
                    )
                )
                InnerTubeJsonParser.parseSearchSuggestions(json)
            }
        }

    override suspend fun search(
        query: String,
        filter: SearchFilter,
        continuation: String?
    ): Result<SearchResults> = withContext(Dispatchers.IO) {
        if (query.isBlank() && continuation == null) return@withContext Result.success(SearchResults())
        runCatching {
            val profile = InnerTubeClientConfig.webRemix
            val json = executeString(
                apiService.search(
                    profile.buildHeaders(cachedVisitorData),
                    SearchRequestDto(
                        context = profile.toContextDto(cachedVisitorData),
                        query = if (continuation == null) query else null,
                        params = if (continuation == null) filter.params else null
                    ),
                    continuation = continuation
                )
            )
            InnerTubeJsonParser.parseSearchResults(json)
        }
    }

    override suspend fun getArtistDetail(browseId: String): Result<ArtistDetail> =
        withContext(Dispatchers.IO) {
            val cached = artistCache.get(browseId)
            if (cached != null && System.currentTimeMillis() < cached.expiresAtMs) {
                return@withContext Result.success(cached.value)
            }
            runCatching {
                val profile = InnerTubeClientConfig.webRemix
                val json = executeString(
                    apiService.browse(
                        profile.buildHeaders(cachedVisitorData),
                        BrowseRequestDto(context = profile.toContextDto(cachedVisitorData), browseId = browseId)
                    )
                )
                val parsed = InnerTubeJsonParser.parseArtistDetail(browseId, json)
                artistCache.put(browseId, CacheEntry(parsed, System.currentTimeMillis() + detailTtlMs))
                parsed
            }
        }

    override suspend fun getAlbumDetail(browseId: String): Result<AlbumDetail> =
        withContext(Dispatchers.IO) {
            val cached = albumCache.get(browseId)
            if (cached != null && System.currentTimeMillis() < cached.expiresAtMs) {
                return@withContext Result.success(cached.value)
            }
            runCatching {
                val profile = InnerTubeClientConfig.webRemix
                val json = executeString(
                    apiService.browse(
                        profile.buildHeaders(cachedVisitorData),
                        BrowseRequestDto(context = profile.toContextDto(cachedVisitorData), browseId = browseId)
                    )
                )
                val parsed = InnerTubeJsonParser.parseAlbumDetail(browseId, json)
                albumCache.put(browseId, CacheEntry(parsed, System.currentTimeMillis() + detailTtlMs))
                parsed
            }
        }

    override suspend fun getPlaylistDetail(browseId: String, continuation: String?): Result<PlaylistDetail> =
        withContext(Dispatchers.IO) {
            val normalizedId = if (browseId.startsWith("PL") || browseId.startsWith("OLAK") || browseId.startsWith("RD")) {
                "VL$browseId"
            } else {
                browseId
            }
            if (continuation == null) {
                val cached = playlistCache.get(normalizedId)
                if (cached != null && System.currentTimeMillis() < cached.expiresAtMs) {
                    return@withContext Result.success(cached.value)
                }
            }
            runCatching {
                val profile = InnerTubeClientConfig.webRemix
                val json = executeString(
                    apiService.browse(
                        profile.buildHeaders(cachedVisitorData),
                        BrowseRequestDto(
                            context = profile.toContextDto(cachedVisitorData),
                            browseId = if (continuation == null) normalizedId else null
                        ),
                        continuation = continuation
                    )
                )
                val parsed = InnerTubeJsonParser.parsePlaylistDetail(normalizedId, json)
                if (continuation == null) {
                    playlistCache.put(normalizedId, CacheEntry(parsed, System.currentTimeMillis() + detailTtlMs))
                }
                parsed
            }
        }

    override suspend fun getWatchNext(videoId: String): Result<WatchNextData> =
        withContext(Dispatchers.IO) {
            runCatching {
                val profile = InnerTubeClientConfig.webRemix
                val json = executeString(
                    apiService.next(
                        profile.buildHeaders(cachedVisitorData),
                        NextRequestDto(context = profile.toContextDto(cachedVisitorData), videoId = videoId)
                    )
                )
                InnerTubeJsonParser.parseWatchNext(json)
            }
        }

    override suspend fun getRelatedSongs(relatedBrowseId: String): Result<List<Song>> =
        withContext(Dispatchers.IO) {
            runCatching {
                val sections = getBrowseCategory(relatedBrowseId, null).getOrThrow()
                sections.flatMap { it.items }
                    .filterIsInstance<com.vyorasound.app.domain.model.MediaShelfItem.SongItem>()
                    .map { it.song }
                    .distinctBy { it.id }
            }
        }

    override suspend fun getLyrics(lyricsBrowseId: String): Result<String?> =
        withContext(Dispatchers.IO) {
            runCatching {
                val profile = InnerTubeClientConfig.webRemix
                val json = executeString(
                    apiService.browse(
                        profile.buildHeaders(cachedVisitorData),
                        BrowseRequestDto(context = profile.toContextDto(cachedVisitorData), browseId = lyricsBrowseId)
                    )
                )
                InnerTubeJsonParser.parseLyrics(json)
            }
        }

    override suspend fun getPlaybackStream(videoId: String): Result<PlaybackStream> =
        withContext(Dispatchers.IO) {
            val songTitle = songTitleRegistry[videoId]
            val cached = streamCache.get(videoId)
            if (cached != null && System.currentTimeMillis() < cached.expiresAtMs) {
                PlaybackDiagnostics.i(
                    "StreamCacheHit | title=\"${songTitle ?: "-"}\" | videoId=$videoId | " +
                        "client=${cached.clientName} | mime=${cached.mimeType} | bitrate=${cached.bitrate}"
                )
                return@withContext Result.success(cached)
            }

            ensureVisitorData()
            ensureNativeVisitorData()
            val isAuthenticated = authProvider.refreshSessionState()
            val authHeaders = if (isAuthenticated) authProvider.buildAuthHeaders() else emptyMap()
            val failureReasons = mutableListOf<String>()

            for (profile in InnerTubeClientConfig.playerFallbackOrder(isAuthenticated)) {
                val visitorData = if (profile.isNativeClient) {
                    cachedNativeVisitorData
                } else {
                    cachedVisitorData
                }
                PlaybackDiagnostics.i(
                    "ResolveStart | title=\"${songTitle ?: "-"}\" | videoId=$videoId | " +
                        "client=${profile.clientName} (${profile.clientVersion}) | " +
                        "auth=${isAuthenticated && !profile.isNativeClient} | " +
                        "hasVisitorData=${!visitorData.isNullOrBlank()} | endpoint=${profile.playerEndpointUrl}"
                )

                val requestDto = PlayerRequestDto(
                    context = profile.toContextDto(visitorData),
                    videoId = videoId,
                    playbackContext = if (profile.supportsHtml5Preference) PlaybackContextDto() else null
                )

                val responseResult = runCatching {
                    apiService.playerAtUrl(
                        url = profile.playerEndpointUrl,
                        headers = profile.buildHeaders(visitorData, authHeaders),
                        body = requestDto
                    )
                }

                val response = responseResult.getOrNull()
                if (response == null) {
                    val err = responseResult.exceptionOrNull()
                    val reason = "${profile.clientName}: network error (${err?.message ?: "unknown"})"
                    failureReasons.add(reason)
                    PlaybackDiagnostics.w(
                        "PlayerRequestError | title=\"${songTitle ?: "-"}\" | videoId=$videoId | $reason",
                        err
                    )
                    continue
                }

                val httpStatus = response.code()
                val rawJson = if (response.isSuccessful) {
                    response.body()?.string()
                } else {
                    response.errorBody()?.string()
                }

                if (!response.isSuccessful || rawJson.isNullOrBlank()) {
                    val reason = "${profile.clientName}: HTTP $httpStatus ${response.message()}"
                    failureReasons.add(reason)
                    PlaybackDiagnostics.w(
                        "PlayerHttpError | title=\"${songTitle ?: "-"}\" | videoId=$videoId | $reason"
                    )
                    continue
                }

                InnerTubeJsonParser.extractVisitorData(rawJson)?.let { freshVisitor ->
                    if (profile.isNativeClient) {
                        cachedNativeVisitorData = freshVisitor
                    } else {
                        cachedVisitorData = freshVisitor
                    }
                }

                val audit = runCatching {
                    InnerTubeJsonParser.auditAndSelectPlaybackStreams(
                        videoId = videoId,
                        userAgent = profile.userAgent,
                        jsonString = rawJson,
                        clientName = profile.clientName
                    )
                }.getOrElse { parseErr ->
                    val reason = "${profile.clientName}: JSON parse error (${parseErr.message})"
                    failureReasons.add(reason)
                    PlaybackDiagnostics.e(
                        "PlayerParseError | title=\"${songTitle ?: "-"}\" | videoId=$videoId | $reason",
                        parseErr
                    )
                    continue
                }

                PlaybackDiagnostics.logPlayerAudit(
                    songTitle = songTitle,
                    videoId = videoId,
                    clientName = profile.clientName,
                    playerHttpStatus = httpStatus,
                    audit = audit
                )

                if (audit.rankedPlayableStreams.isEmpty()) {
                    val rootCause = audit.rootCauseHint ?: "No playable audio stream"
                    failureReasons.add("${profile.clientName}: $rootCause")
                    continue
                }

                for (candidateStream in audit.rankedPlayableStreams) {
                    val probe = streamProber.probe(candidateStream)
                    PlaybackDiagnostics.logStreamProbe(
                        songTitle = songTitle,
                        videoId = videoId,
                        stream = candidateStream,
                        httpStatus = probe.httpStatus,
                        errorDetail = probe.errorDetail
                    )
                    if (probe.isPlayable) {
                        streamCache.put(videoId, candidateStream)
                        return@withContext Result.success(candidateStream)
                    } else {
                        failureReasons.add(
                            "${profile.clientName} itag=${candidateStream.itag}: ${probe.errorDetail ?: "unreachable"}"
                        )
                    }
                }
            }

            // Fallback to keyless public audio relays (Piped / Invidious) when direct InnerTube
            // requests are blocked by datacenter/IP LOGIN_REQUIRED checks
            val fallbackStream = noLoginFallbackResolver.resolvePlayableStream(
                videoId = videoId,
                songTitle = songTitle,
                streamProber = streamProber
            )
            if (fallbackStream != null) {
                PlaybackDiagnostics.i(
                    "NoLoginFallbackSUCCESS | title=\"${songTitle ?: "-"}\" | videoId=$videoId | " +
                        "source=${fallbackStream.clientName} | mime=${fallbackStream.mimeType} | bitrate=${fallbackStream.bitrate}"
                )
                streamCache.put(videoId, fallbackStream)
                return@withContext Result.success(fallbackStream)
            }

            val summary = failureReasons.joinToString(" | ").ifBlank {
                "Unable to resolve playable audio source"
            }
            PlaybackDiagnostics.w(
                "ResolveExhausted | title=\"${songTitle ?: "-"}\" | videoId=$videoId | rootCause=$summary"
            )
            if (summary.contains("LOGIN_REQUIRED", ignoreCase = true) && !isAuthenticated) {
                Result.failure(
                    LoginRequiredPlaybackException(
                        "YouTube membatasi pemutaran tanpa login di jaringan ini. Coba lagi atau hubungkan akun YouTube."
                    )
                )
            } else {
                Result.failure(IOException("Tidak dapat memutar lagu ($summary)"))
            }
        }

    override fun getCachedStream(videoId: String): PlaybackStream? {
        val cached = streamCache.get(videoId) ?: return null
        return if (System.currentTimeMillis() < cached.expiresAtMs) cached else null
    }

    fun getPlaybackStreamDetailedBlocking(videoId: String): Result<PlaybackStream> {
        getCachedStream(videoId)?.let { return Result.success(it) }
        return runBlocking { getPlaybackStream(videoId) }
    }

    fun getPlaybackStreamBlocking(videoId: String): PlaybackStream? {
        return getPlaybackStreamDetailedBlocking(videoId).getOrNull()
    }

    private suspend fun ensureVisitorData() {
        if (!cachedVisitorData.isNullOrBlank()) return
        runCatching {
            val profile = InnerTubeClientConfig.webRemix
            val response = apiService.browse(
                profile.buildHeaders(),
                BrowseRequestDto(
                    context = profile.toContextDto(),
                    browseId = "FEmusic_home"
                )
            )
            if (response.isSuccessful) {
                val json = response.body()?.string()
                if (!json.isNullOrBlank()) {
                    InnerTubeJsonParser.extractVisitorData(json)?.let { extracted ->
                        cachedVisitorData = extracted
                        PlaybackDiagnostics.d("WebVisitorDataObtained | len=${extracted.length}")
                    }
                }
            }
        }
    }

    private suspend fun ensureNativeVisitorData() {
        if (!cachedNativeVisitorData.isNullOrBlank()) return
        runCatching {
            val profile = InnerTubeClientConfig.androidVr
            val response = apiService.visitorIdAtUrl(
                url = "https://youtubei.googleapis.com/youtubei/v1/visitor_id?prettyPrint=false",
                headers = profile.buildHeaders(),
                body = com.vyorasound.app.data.dto.VisitorIdRequestDto(context = profile.toContextDto())
            )
            if (response.isSuccessful) {
                val json = response.body()?.string()
                if (!json.isNullOrBlank()) {
                    InnerTubeJsonParser.extractVisitorData(json)?.let { extracted ->
                        cachedNativeVisitorData = extracted
                        PlaybackDiagnostics.d("NativeVisitorDataObtained | len=${extracted.length}")
                    }
                }
            }
        }
    }

    private fun executeString(response: retrofit2.Response<okhttp3.ResponseBody>): String {
        if (!response.isSuccessful) {
            throw IOException("InnerTube HTTP ${response.code()}: ${response.message()}")
        }
        val body = response.body()?.string() ?: throw IOException("Empty InnerTube response body")
        InnerTubeJsonParser.extractVisitorData(body)?.let { visitor ->
            if (cachedVisitorData.isNullOrBlank()) {
                cachedVisitorData = visitor
            }
        }
        return body
    }
}
