package com.vyorasound.app.presentation.player

import android.os.Build
import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.PlaylistAdd
import androidx.compose.material.icons.automirrored.rounded.QueueMusic
import androidx.compose.material.icons.rounded.ArrowDownward
import androidx.compose.material.icons.rounded.ArrowUpward
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.rounded.FavoriteBorder
import androidx.compose.material.icons.rounded.KeyboardArrowDown
import androidx.compose.material.icons.rounded.Lyrics
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Repeat
import androidx.compose.material.icons.rounded.RepeatOne
import androidx.compose.material.icons.rounded.Shuffle
import androidx.compose.material.icons.rounded.SkipNext
import androidx.compose.material.icons.rounded.SkipPrevious
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.vyorasound.app.R
import com.vyorasound.app.domain.model.Artist
import com.vyorasound.app.domain.model.RepeatMode
import com.vyorasound.app.domain.model.Song
import com.vyorasound.app.player.PlayerUiState
import com.vyorasound.app.presentation.components.NexaArtwork
import com.vyorasound.app.presentation.theme.GlassCard
import com.vyorasound.app.presentation.theme.GlassPill
import com.vyorasound.app.presentation.theme.NexaColors
import com.vyorasound.app.utils.TimeUtils

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NowPlayingScreen(
    playerState: PlayerUiState,
    isLiked: Boolean,
    onClose: () -> Unit,
    onTogglePlayPause: () -> Unit,
    onSkipNext: () -> Unit,
    onSkipPrevious: () -> Unit,
    onSeekTo: (Long) -> Unit,
    onToggleShuffle: () -> Unit,
    onCycleRepeat: () -> Unit,
    onToggleLike: (Song) -> Unit,
    onAddToPlaylist: (Song) -> Unit,
    onJumpToQueueIndex: (Int) -> Unit,
    onRemoveFromQueue: (Int) -> Unit,
    onMoveQueueItem: (Int, Int) -> Unit,
    onOpenArtist: (Artist) -> Unit,
    onRetry: () -> Unit,
    onSignInYouTube: (() -> Unit)? = null
) {
    BackHandler(onBack = onClose)

    val song = playerState.currentSong
    var showQueueSheet by remember { mutableStateOf(false) }
    var showLyricsSheet by remember { mutableStateOf(false) }

    val artScale by animateFloatAsState(
        targetValue = if (playerState.isPlaying) 1f else 0.93f,
        animationSpec = spring(stiffness = Spring.StiffnessMediumLow),
        label = "art_scale"
    )

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(NexaColors.Background)
            .testTag("now_playing_screen")
    ) {
        // Blurred Background Artwork
        if (song != null && song.thumbnailUrl.isNotBlank()) {
            val blurMod = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                Modifier.blur(64.dp)
            } else {
                Modifier
            }
            AsyncImage(
                model = song.thumbnailUrl,
                contentDescription = null,
                placeholder = painterResource(R.drawable.img_vyora_ambient_hero),
                error = painterResource(R.drawable.img_vyora_ambient_hero),
                contentScale = ContentScale.Crop,
                modifier = Modifier
                    .fillMaxSize()
                    .then(blurMod)
                    .alpha(0.42f)
            )
        }

        // Rich Obsidian Glass Scrim
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        listOf(
                            NexaColors.Background.copy(alpha = 0.58f),
                            NexaColors.Background.copy(alpha = 0.84f),
                            NexaColors.Background.copy(alpha = 0.97f)
                        )
                    )
                )
        )

        if (song == null) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .statusBarsPadding()
                    .padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Text(
                    text = "Belum ada lagu yang diputar",
                    style = MaterialTheme.typography.headlineSmall,
                    color = NexaColors.TextPrimary
                )
                Spacer(modifier = Modifier.height(16.dp))
                Button(onClick = onClose) {
                    Text("Kembali ke Musik")
                }
            }
            return@Box
        }

        Column(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
                .padding(horizontal = 24.dp, vertical = 12.dp)
                .widthIn(max = 560.dp)
                .align(Alignment.Center),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Top Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = onClose,
                    modifier = Modifier
                        .size(48.dp)
                        .clip(CircleShape)
                        .background(NexaColors.Glass)
                        .testTag("now_playing_close")
                ) {
                    Icon(
                        imageVector = Icons.Rounded.KeyboardArrowDown,
                        contentDescription = "Minimize player",
                        tint = NexaColors.TextPrimary,
                        modifier = Modifier.size(28.dp)
                    )
                }

                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = "SEDANG DIPUTAR",
                        style = MaterialTheme.typography.labelSmall,
                        color = NexaColors.Primary
                    )
                    if (!song.album.isNullOrBlank()) {
                        Text(
                            text = song.album,
                            style = MaterialTheme.typography.bodySmall,
                            color = NexaColors.TextSecondary,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.widthIn(max = 200.dp)
                        )
                    }
                }

                IconButton(
                    onClick = { showQueueSheet = true },
                    modifier = Modifier
                        .size(48.dp)
                        .clip(CircleShape)
                        .background(NexaColors.Glass)
                        .testTag("now_playing_queue_btn")
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Rounded.QueueMusic,
                        contentDescription = "Open queue",
                        tint = NexaColors.TextPrimary
                    )
                }
            }

            Spacer(modifier = Modifier.weight(0.6f))

            // Large Album Artwork in Glass Frame
            GlassCard(
                shape = RoundedCornerShape(30.dp),
                backgroundAlpha = 0.35f,
                modifier = Modifier
                    .fillMaxWidth(0.86f)
                    .aspectRatio(1f)
                    .scale(artScale)
                    .shadow(
                        elevation = 28.dp,
                        shape = RoundedCornerShape(30.dp),
                        spotColor = NexaColors.Primary.copy(alpha = 0.35f)
                    )
            ) {
                NexaArtwork(
                    url = song.thumbnailUrl,
                    contentDescription = song.title,
                    shape = RoundedCornerShape(30.dp),
                    modifier = Modifier.fillMaxSize()
                )
            }

            Spacer(modifier = Modifier.weight(0.7f))

            // Song Title, Artist, Like & Playlist buttons
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = song.title,
                        style = MaterialTheme.typography.headlineMedium,
                        color = NexaColors.TextPrimary,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = song.artist,
                        style = MaterialTheme.typography.titleMedium,
                        color = NexaColors.TextSecondary,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.clickable(enabled = !song.artistId.isNullOrBlank()) {
                            song.artistId?.let { id ->
                                onClose()
                                onOpenArtist(Artist(id = id, name = song.artist))
                            }
                        }
                    )
                }

                IconButton(
                    onClick = { onToggleLike(song) },
                    modifier = Modifier
                        .size(48.dp)
                        .testTag("now_playing_like")
                ) {
                    Icon(
                        imageVector = if (isLiked) Icons.Rounded.Favorite else Icons.Rounded.FavoriteBorder,
                        contentDescription = if (isLiked) "Unlike song" else "Like song",
                        tint = if (isLiked) NexaColors.Primary else NexaColors.TextSecondary,
                        modifier = Modifier.size(26.dp)
                    )
                }

                IconButton(
                    onClick = { onAddToPlaylist(song) },
                    modifier = Modifier.size(48.dp)
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Rounded.PlaylistAdd,
                        contentDescription = "Add to playlist",
                        tint = NexaColors.TextSecondary,
                        modifier = Modifier.size(26.dp)
                    )
                }
            }

            if (playerState.errorMessage != null) {
                Spacer(modifier = Modifier.height(10.dp))
                GlassCard(
                    shape = RoundedCornerShape(16.dp),
                    backgroundAlpha = 0.65f,
                    onClick = if (playerState.requiresOptionalLogin && onSignInYouTube != null) null else onRetry,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 14.dp, vertical = 10.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = playerState.errorMessage,
                                style = MaterialTheme.typography.bodySmall,
                                color = NexaColors.Error,
                                modifier = Modifier.weight(1f)
                            )
                            IconButton(
                                onClick = onRetry,
                                modifier = Modifier
                                    .size(48.dp)
                                    .testTag("now_playing_retry")
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.Refresh,
                                    contentDescription = "Coba lagi",
                                    tint = NexaColors.Primary
                                )
                            }
                        }
                        if (playerState.requiresOptionalLogin && onSignInYouTube != null) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Button(
                                    onClick = onSignInYouTube,
                                    shape = RoundedCornerShape(50),
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = NexaColors.Primary,
                                        contentColor = NexaColors.OnPrimary
                                    ),
                                    modifier = Modifier
                                        .weight(1f)
                                        .height(48.dp)
                                        .testTag("now_playing_login_youtube")
                                ) {
                                    Text("Masuk YouTube", maxLines = 1, overflow = TextOverflow.Ellipsis)
                                }
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Seek Bar
            val durationMs = playerState.durationMs.coerceAtLeast(1L)
            var isDragging by remember { mutableStateOf(false) }
            var dragFraction by remember { mutableFloatStateOf(0f) }
            val liveFraction = (playerState.positionMs.toFloat() / durationMs.toFloat()).coerceIn(0f, 1f)
            val sliderValue = if (isDragging) dragFraction else liveFraction

            Slider(
                value = sliderValue,
                onValueChange = { fraction ->
                    isDragging = true
                    dragFraction = fraction
                },
                onValueChangeFinished = {
                    val targetMs = (dragFraction * durationMs).toLong()
                    onSeekTo(targetMs)
                    isDragging = false
                },
                colors = SliderDefaults.colors(
                    thumbColor = NexaColors.Primary,
                    activeTrackColor = NexaColors.Primary,
                    inactiveTrackColor = NexaColors.GlassStrong
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("now_playing_seekbar")
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                val displayedMs = if (isDragging) (dragFraction * durationMs).toLong() else playerState.positionMs
                Text(
                    text = TimeUtils.formatDuration(displayedMs),
                    style = MaterialTheme.typography.labelMedium,
                    color = NexaColors.TextSecondary
                )
                Text(
                    text = TimeUtils.formatDuration(playerState.durationMs),
                    style = MaterialTheme.typography.labelMedium,
                    color = NexaColors.TextSecondary
                )
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Glassmorphism Controls Deck
            GlassCard(
                shape = RoundedCornerShape(28.dp),
                backgroundAlpha = 0.58f,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 14.dp),
                    horizontalArrangement = Arrangement.SpaceEvenly,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(
                        onClick = onToggleShuffle,
                        modifier = Modifier
                            .size(48.dp)
                            .testTag("now_playing_shuffle")
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Shuffle,
                            contentDescription = "Shuffle",
                            tint = if (playerState.shuffleEnabled) NexaColors.Primary else NexaColors.TextSecondary,
                            modifier = Modifier.size(22.dp)
                        )
                    }

                    IconButton(
                        onClick = onSkipPrevious,
                        modifier = Modifier
                            .size(52.dp)
                            .testTag("now_playing_prev")
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.SkipPrevious,
                            contentDescription = "Previous",
                            tint = NexaColors.TextPrimary,
                            modifier = Modifier.size(34.dp)
                        )
                    }

                    Box(
                        modifier = Modifier
                            .size(68.dp)
                            .clip(CircleShape)
                            .background(
                                Brush.linearGradient(
                                    listOf(NexaColors.Primary, NexaColors.Accent)
                                )
                            )
                            .clickable(onClick = onTogglePlayPause)
                            .testTag("now_playing_play_pause"),
                        contentAlignment = Alignment.Center
                    ) {
                        if (playerState.isBuffering && !playerState.isPlaying) {
                            CircularProgressIndicator(
                                color = NexaColors.OnPrimary,
                                strokeWidth = 2.5.dp,
                                modifier = Modifier.size(28.dp)
                            )
                        } else {
                            Icon(
                                imageVector = if (playerState.isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                                contentDescription = if (playerState.isPlaying) "Pause" else "Play",
                                tint = NexaColors.OnPrimary,
                                modifier = Modifier.size(36.dp)
                            )
                        }
                    }

                    IconButton(
                        onClick = onSkipNext,
                        modifier = Modifier
                            .size(52.dp)
                            .testTag("now_playing_next")
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.SkipNext,
                            contentDescription = "Next",
                            tint = NexaColors.TextPrimary,
                            modifier = Modifier.size(34.dp)
                        )
                    }

                    IconButton(
                        onClick = onCycleRepeat,
                        modifier = Modifier
                            .size(48.dp)
                            .testTag("now_playing_repeat")
                    ) {
                        val icon = if (playerState.repeatMode == RepeatMode.ONE) {
                            Icons.Rounded.RepeatOne
                        } else {
                            Icons.Rounded.Repeat
                        }
                        val tint = if (playerState.repeatMode != RepeatMode.OFF) {
                            NexaColors.Primary
                        } else {
                            NexaColors.TextSecondary
                        }
                        Icon(
                            imageVector = icon,
                            contentDescription = "Repeat mode",
                            tint = tint,
                            modifier = Modifier.size(22.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Quick Bottom Pills: Queue & Lyrics
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp, Alignment.CenterHorizontally)
            ) {
                GlassPill(
                    selected = false,
                    onClick = { showQueueSheet = true }
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Rounded.QueueMusic,
                            contentDescription = null,
                            tint = NexaColors.Primary,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "Antrean (${playerState.queue.size})",
                            style = MaterialTheme.typography.labelLarge,
                            color = NexaColors.TextPrimary
                        )
                    }
                }

                GlassPill(
                    selected = false,
                    onClick = { showLyricsSheet = true }
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Rounded.Lyrics,
                            contentDescription = null,
                            tint = NexaColors.Primary,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "Lirik & Info",
                            style = MaterialTheme.typography.labelLarge,
                            color = NexaColors.TextPrimary
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))
        }
    }

    if (showQueueSheet) {
        ModalBottomSheet(
            onDismissRequest = { showQueueSheet = false },
            containerColor = NexaColors.Surface,
            contentColor = NexaColors.TextPrimary
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp)
                    .padding(bottom = 24.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Antrean Pemutaran",
                        style = MaterialTheme.typography.headlineSmall,
                        color = NexaColors.TextPrimary
                    )
                    Text(
                        text = "${playerState.queue.size} lagu",
                        style = MaterialTheme.typography.labelLarge,
                        color = NexaColors.Primary
                    )
                }

                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    contentPadding = PaddingValues(bottom = 20.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    itemsIndexed(
                        items = playerState.queue,
                        key = { idx, item -> "q_${idx}_${item.id}" }
                    ) { index, item ->
                        val isActive = index == playerState.currentIndex
                        GlassCard(
                            shape = RoundedCornerShape(16.dp),
                            backgroundAlpha = if (isActive) 0.78f else 0.4f,
                            onClick = { onJumpToQueueIndex(index) }
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 10.dp, vertical = 8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                NexaArtwork(
                                    url = item.thumbnailUrl,
                                    contentDescription = item.title,
                                    shape = RoundedCornerShape(10.dp),
                                    modifier = Modifier.size(44.dp)
                                )
                                Spacer(modifier = Modifier.width(10.dp))
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = item.title,
                                        style = MaterialTheme.typography.titleSmall,
                                        color = if (isActive) NexaColors.Primary else NexaColors.TextPrimary,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    Text(
                                        text = item.artist,
                                        style = MaterialTheme.typography.bodySmall,
                                        color = NexaColors.TextSecondary,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                                if (index > 0) {
                                    IconButton(
                                        onClick = { onMoveQueueItem(index, index - 1) },
                                        modifier = Modifier.size(40.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Rounded.ArrowUpward,
                                            contentDescription = "Move up",
                                            tint = NexaColors.TextSecondary,
                                            modifier = Modifier.size(18.dp)
                                        )
                                    }
                                }
                                if (index < playerState.queue.lastIndex) {
                                    IconButton(
                                        onClick = { onMoveQueueItem(index, index + 1) },
                                        modifier = Modifier.size(40.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Rounded.ArrowDownward,
                                            contentDescription = "Move down",
                                            tint = NexaColors.TextSecondary,
                                            modifier = Modifier.size(18.dp)
                                        )
                                    }
                                }
                                if (!isActive) {
                                    IconButton(
                                        onClick = { onRemoveFromQueue(index) },
                                        modifier = Modifier.size(40.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Rounded.Close,
                                            contentDescription = "Remove from queue",
                                            tint = NexaColors.TextSecondary,
                                            modifier = Modifier.size(18.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showLyricsSheet) {
        ModalBottomSheet(
            onDismissRequest = { showLyricsSheet = false },
            containerColor = NexaColors.Surface,
            contentColor = NexaColors.TextPrimary
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 24.dp)
                    .padding(bottom = 32.dp)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(
                    text = "Lirik",
                    style = MaterialTheme.typography.headlineSmall,
                    color = NexaColors.TextPrimary
                )
                when {
                    playerState.isLoadingExtras -> {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 24.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            CircularProgressIndicator(color = NexaColors.Primary)
                        }
                    }
                    !playerState.lyrics.isNullOrBlank() -> {
                        Text(
                            text = playerState.lyrics,
                            style = MaterialTheme.typography.bodyLarge,
                            color = NexaColors.TextPrimary
                        )
                    }
                    else -> {
                        Text(
                            text = "Lirik belum tersedia untuk lagu ini di YouTube Music.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = NexaColors.TextSecondary
                        )
                    }
                }
            }
        }
    }
}
