package com.vyorasound.app.presentation.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.SkipNext
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.vyorasound.app.player.PlayerUiState
import com.vyorasound.app.presentation.theme.GlassCard
import com.vyorasound.app.presentation.theme.NexaColors

@Composable
fun MiniPlayer(
    playerState: PlayerUiState,
    onOpenNowPlaying: () -> Unit,
    onTogglePlayPause: () -> Unit,
    onSkipNext: () -> Unit,
    onRetry: () -> Unit,
    modifier: Modifier = Modifier
) {
    val song = playerState.currentSong
    AnimatedVisibility(
        visible = song != null,
        enter = slideInVertically { it } + fadeIn(),
        exit = slideOutVertically { it } + fadeOut(),
        modifier = modifier
    ) {
        if (song != null) {
            val progress = if (playerState.durationMs > 0L) {
                (playerState.positionMs.toFloat() / playerState.durationMs.toFloat()).coerceIn(0f, 1f)
            } else {
                0f
            }

            GlassCard(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("mini_player"),
                shape = RoundedCornerShape(22.dp),
                backgroundAlpha = 0.86f,
                onClick = onOpenNowPlaying
            ) {
                Column(modifier = Modifier.fillMaxWidth()) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 12.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        NexaArtwork(
                            url = song.thumbnailUrl,
                            contentDescription = song.title,
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier.size(46.dp)
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = song.title,
                                style = MaterialTheme.typography.titleMedium,
                                color = NexaColors.TextPrimary,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                text = playerState.errorMessage ?: song.artist,
                                style = MaterialTheme.typography.bodySmall,
                                color = if (playerState.errorMessage != null) NexaColors.Error else NexaColors.TextSecondary,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }

                        if (playerState.errorMessage != null) {
                            IconButton(
                                onClick = onRetry,
                                modifier = Modifier
                                    .size(48.dp)
                                    .testTag("mini_player_retry")
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.Refresh,
                                    contentDescription = "Coba putar ulang",
                                    tint = NexaColors.Error
                                )
                            }
                        } else {
                            IconButton(
                                onClick = onTogglePlayPause,
                                modifier = Modifier
                                    .size(48.dp)
                                    .testTag("mini_player_play_pause")
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(36.dp)
                                        .clip(CircleShape)
                                        .background(NexaColors.Primary.copy(alpha = 0.22f)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    if (playerState.isBuffering && !playerState.isPlaying) {
                                        CircularProgressIndicator(
                                            color = NexaColors.Primary,
                                            strokeWidth = 2.dp,
                                            modifier = Modifier.size(18.dp)
                                        )
                                    } else {
                                        Icon(
                                            imageVector = if (playerState.isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                                            contentDescription = if (playerState.isPlaying) "Jeda" else "Putar",
                                            tint = NexaColors.Primary,
                                            modifier = Modifier.size(22.dp)
                                        )
                                    }
                                }
                            }
                        }

                        IconButton(
                            onClick = onSkipNext,
                            modifier = Modifier
                                .size(48.dp)
                                .testTag("mini_player_next")
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.SkipNext,
                                contentDescription = "Lagu berikutnya",
                                tint = NexaColors.TextPrimary
                            )
                        }
                    }

                    // Subtle glowing progress indicator along bottom edge
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(2.5.dp)
                            .background(NexaColors.Glass)
                    ) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth(progress)
                                .height(2.5.dp)
                                .background(
                                    Brush.horizontalGradient(
                                        listOf(NexaColors.Accent, NexaColors.Primary)
                                    )
                                )
                        )
                    }
                }
            }
        }
    }
}
